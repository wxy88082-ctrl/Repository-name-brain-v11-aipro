#!/usr/bin/env bash
# BT1 - final patch 版 (TP1修复 + ENABLE_CONFIRM_V2 + StrategyEngineV10 + ENTRY_DELAY_BARS=1)
cd /root/brain
source venv/bin/activate
source .demo.env

echo "[BT1 $(date -u '+%Y-%m-%d %H:%M:%S UTC')] 开始 BTCUSDT/ETHUSDT/BNBUSDT/XRPUSDT/AVAXUSDT" | tee /root/brain/bt_fixed_1.log
echo "[BT1] TP1_FIXED=YES, ENTRY_DELAY_BARS=1, ENABLE_CONFIRM_V2=1, StrategyEngineV10" >> /root/brain/bt_fixed_1.log

env TRADING_MODE=paper \
    BRAIN_WS=/root/brain/backtest_full_ws \
    SYMBOLS=BTCUSDT,ETHUSDT,BNBUSDT,XRPUSDT,AVAXUSDT \
    BACKTEST_START=2024-01-01 \
    BACKTEST_END=2026-04-29 \
    BACKTEST_LIMIT=120000 \
    LOCAL_KLINE_DIR=/root/brain/binance_history \
    PREFER_LOCAL_KLINES=1 \
    ENTRY_DELAY_BARS=1 \
    ENABLE_CONFIRM_V2=1 \
    SCORE_THRESHOLD=60 \
    V11_MIN_EXEC_SCORE=60 \
    V11_ALT_MIN_SCORE=66 \
    ENABLE_TREND_SETUP=0 \
    SETUP_WHITELIST=pullback \
    V11_SETUP_WHITELIST=pullback \
    ENABLE_BREAKOUT_SETUP=0 \
    BLOCK_COUNTER_HTF=1 \
    MIN_ATR_PCT=0.10 \
    FEE_BPS=4.0 \
    SLIPPAGE_BPS=2.0 \
    V11_REQUIRE_EDGE_FOR_EXCHANGE=0 \
    V11_MIN_EDGE_TRADES=0 \
    python3 brain_v11_1_aipro.py --backtest >> /root/brain/bt_fixed_1.log 2>&1

echo "BT1_FIXED_DONE" >> /root/brain/bt_fixed_1.log
echo "[BT1 $(date -u '+%Y-%m-%d %H:%M:%S UTC')] 完成" | tee -a /root/brain/bt_fixed_1.log
