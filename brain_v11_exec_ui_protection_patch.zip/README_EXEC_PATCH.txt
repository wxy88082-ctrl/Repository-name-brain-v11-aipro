Brain V11 execution/UI protection patch

Scope:
- Exchange protection orders: STOP_MARKET + TAKE_PROFIT_MARKET with fallback from algoOrder to standard order.
- Cross margin + leverage=5 setup before opening demo/live order.
- Demo max positions=5, max new entries/cycle=2, target notional sizing.
- Duplicate symbol guards: existing position, open orders, pending, cooldown.
- Real position enrichment: notional, initial margin, leverage, margin type, PnL, ROE, liquidation price, open orders, protection status.
- Dashboard position/overview UI fields.
- Backtest scripts BACKTEST_LIMIT=120000.

Apply:
cd /root/brain
cp brain_v11_1_aipro.py brain_v11_1_aipro.py.bak_exec_patch
cp dashboard.py dashboard.py.bak_exec_patch
cp run_bt_fixed1.sh run_bt_fixed1.sh.bak_exec_patch
cp run_bt_fixed2.sh run_bt_fixed2.sh.bak_exec_patch
patch -p1 < brain_v11_exec_ui_protection_patch.diff
python3 -S update_demo_env_exec_patch.py || python3 update_demo_env_exec_patch.py
python3 -m py_compile brain_v11_1_aipro.py dashboard.py bt_analyze.py
source .demo.env
python3 brain_v11_1_aipro.py --show-config
python3 brain_v11_1_aipro.py --healthcheck
python3 brain_v11_1_aipro.py --scan

Restart only brain_demo / brain_ui. Do not stop bt_fixed1 / bt_fixed2.
