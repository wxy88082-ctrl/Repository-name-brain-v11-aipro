#!/usr/bin/env python3
"""Safely update /root/brain/.demo.env for execution-layer patch.
Preserves existing API keys/secrets and comments as much as possible.
"""
from pathlib import Path
ENV_PATH = Path('/root/brain/.demo.env')
updates = {
    'TRADING_MODE': 'demo',
    'USE_MAINNET_MARKET_DATA': '1',
    'USE_EXCHANGE_PROTECTION': '1',
    'CLOSE_IF_PROTECTION_FAIL': '1',
    'PROTECT_EXISTING_POSITIONS': '1',
    'LEVERAGE': '5',
    'MARGIN_TYPE': 'CROSSED',
    'MAX_POSITIONS': '5',
    'MAX_NEW_ENTRIES_PER_CYCLE': '2',
    'DEMO_ENABLE_TARGET_NOTIONAL': '1',
    'DEMO_TARGET_NOTIONAL_PCT': '0.10',
    'DEMO_MIN_NOTIONAL_USDT': '300',
    'DEMO_MAX_NOTIONAL_USDT': '700',
    'DEMO_MAX_TOTAL_NOTIONAL_PCT': '0.80',
    'RISK_PER_TRADE': '0.005',
    'DAILY_MAX_LOSS_PCT': '0.03',
    'COOLDOWN_MINUTES': '60',
    'ORDER_VERIFY_RETRIES': '7',
    'ORDER_VERIFY_SLEEP': '0.8',
    'PROTECTION_VERIFY_SLEEP': '0.8',
    'EXISTING_LONG_SL_MULT': '0.985',
    'EXISTING_LONG_TP_MULT': '1.025',
    'EXISTING_SHORT_SL_MULT': '1.015',
    'EXISTING_SHORT_TP_MULT': '0.975',
}
if not ENV_PATH.exists():
    raise SystemExit(f'{ENV_PATH} not found')
backup = ENV_PATH.with_suffix(ENV_PATH.suffix + '.bak_exec_patch')
backup.write_text(ENV_PATH.read_text(encoding='utf-8', errors='ignore'), encoding='utf-8')
lines = ENV_PATH.read_text(encoding='utf-8', errors='ignore').splitlines()
seen = set()
out = []
for line in lines:
    stripped = line.strip()
    if not stripped or stripped.startswith('#') or '=' not in stripped:
        out.append(line)
        continue
    key = stripped.split('=', 1)[0].strip().lstrip('export ').strip()
    if key in updates:
        prefix = 'export ' if line.lstrip().startswith('export ') else ''
        out.append(f'{prefix}{key}={updates[key]}')
        seen.add(key)
    else:
        out.append(line)
out.append('')
out.append('# === ChatGPT execution-layer patch defaults ===')
for key, value in updates.items():
    if key not in seen:
        out.append(f'{key}={value}')
ENV_PATH.write_text('\n'.join(out).rstrip() + '\n', encoding='utf-8')
print(f'UPDATED {ENV_PATH}; backup={backup}')
for key in updates:
    print(f'{key}={updates[key]}')
