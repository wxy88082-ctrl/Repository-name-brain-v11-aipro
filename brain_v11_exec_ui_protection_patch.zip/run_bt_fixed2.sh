#!/usr/bin/env bash
# BT2 - final patch 版
sleep 10
cd /root/brain
source venv/bin/activate
source .demo.env

echo "[BT2 $(date -u '+%Y-%m-%d %H:%M:%S UTC')] 开始 SOLUSDT/DOGEUSDT/ADAUSDT/LINKUSDT/NEARUSDT" | tee /root/brain/bt_fixed_2.log
echo "[BT2] TP1_FIXED=YES, ENTRY_DELAY_BARS=1, ENABLE_CONFIRM_V2=1, StrategyEngineV10" >> /root/brain/bt_fixed_2.log

env TRADING_MODE=paper \
    BRAIN_WS=/root/brain/backtest_bt2_ws \
    SYMBOLS=SOLUSDT,DOGEUSDT,ADAUSDT,LINKUSDT,NEARUSDT \
    BACKTEST_START=2024-01-01 \
    BACKTEST_END=2026-04-29 \
    BACKTEST_LIMIT=120000 \
    LOCAL_KLINE_DIR=/root/brain/binance_history \
    PREFER_LOCAL_KLINES=1 \
    ENTRY_DELAY_BARS=1 \
    ENABLE_CONFIRM_V2=1 \
    SCORE_THRESHOLD=60 \
    V11_MIN_EXEC_SCORE=60 \
    V11_ALT_MIN_SCORE=66 \
    ENABLE_TREND_SETUP=0 \
    SETUP_WHITELIST=pullback \
    V11_SETUP_WHITELIST=pullback \
    ENABLE_BREAKOUT_SETUP=0 \
    BLOCK_COUNTER_HTF=1 \
    MIN_ATR_PCT=0.10 \
    FEE_BPS=4.0 \
    SLIPPAGE_BPS=2.0 \
    V11_REQUIRE_EDGE_FOR_EXCHANGE=0 \
    V11_MIN_EDGE_TRADES=0 \
    python3 brain_v11_1_aipro.py --backtest >> /root/brain/bt_fixed_2.log 2>&1

echo "BT2_FIXED_DONE" >> /root/brain/bt_fixed_2.log
echo "[BT2 $(date -u '+%Y-%m-%d %H:%M:%S UTC')] 完成" | tee -a /root/brain/bt_fixed_2.log

# 等BT1完成再合并
echo "[汇总] 等待 BT1..." | tee -a /root/brain/bt_fixed_2.log
for i in $(seq 1 720); do
    grep -q "BT1_FIXED_DONE" /root/brain/bt_fixed_1.log 2>/dev/null && break
    sleep 60
done

mkdir -p /root/brain/backtest_results
python3 /root/brain/bt_analyze.py >> /root/brain/bt_fixed_2.log 2>&1
STATUS=$?
if [ $STATUS -ne 0 ]; then
    echo "[汇总] bt_analyze 报错，请手动查看" | tee -a /root/brain/bt_fixed_2.log
fi
echo "BT_ANALYZE_DONE" >> /root/brain/bt_fixed_2.log
