#!/usr/bin/env python3
"""
全量回测合并分析脚本
- 读取 bt1（BTC/ETH/BNB/XRP/AVAX）和 bt2（SOL/DOGE/ADA/LINK/NEAR）的 backtest_trades.csv
- 输出：总体、按年、按月、按币种、按方向统计
- 输出：最大回撤、最大连亏、walk-forward 结果、lookahead 检查
- 输出：是否建议进入 demo 小仓测试
"""

import csv
import json
import math
import os
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ─── 路径配置 ─────────────────────────────────────────────────────────────────
RESULTS_DIR   = Path("/root/brain/backtest_results")
BT1_CSV       = RESULTS_DIR / "bt1_BTCUSDT_ETHUSDT_BNBUSDT_XRPUSDT_AVAXUSDT.csv"
BT2_CSV       = RESULTS_DIR / "bt2_SOLUSDT_DOGEUSDT_ADAUSDT_LINKUSDT_NEARUSDT.csv"
BT1_METRICS   = RESULTS_DIR / "bt1_metrics.json"
BT2_METRICS   = RESULTS_DIR / "bt2_metrics.json"
BT1_WS        = Path("/root/brain/backtest_full_ws")
BT2_WS        = Path("/root/brain/backtest_bt2_ws")
OUTPUT_JSON   = RESULTS_DIR / "combined_report.json"
OUTPUT_TXT    = RESULTS_DIR / "combined_report.txt"
NOTIFY_FILE   = Path("/root/.openclaw/workspace/pending_notify.txt")

# ─── 工具函数 ─────────────────────────────────────────────────────────────────
def safe_float(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default

def iso_to_dt(s: str) -> Optional[datetime]:
    if not s:
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(s, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    try:
        return datetime.fromtimestamp(int(s) / 1000, tz=timezone.utc)
    except Exception:
        return None

def load_csv(path: Path) -> List[Dict]:
    if not path.exists():
        print(f"[WARN] 文件不存在: {path}")
        return []
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    print(f"[INFO] 加载 {path.name}: {len(rows)} 笔")
    return rows

def load_json(path: Path) -> Dict:
    if not path.exists():
        return {}
    with open(path, encoding="utf-8") as f:
        return json.load(f)

# ─── 核心指标计算 ─────────────────────────────────────────────────────────────
def compute_stats(trades: List[Dict], label: str = "") -> Dict:
    if not trades:
        return {"label": label, "trades": 0, "note": "无交易数据"}

    rs = [safe_float(t.get("r_multiple") or t.get("r_mult") or t.get("pnl") or t.get("pnl_pct", 0)) for t in trades]
    n = len(rs)
    wins = [r for r in rs if r > 0]
    losses = [r for r in rs if r <= 0]
    win_rate = len(wins) / n if n else 0
    avg_win = sum(wins) / len(wins) if wins else 0
    avg_loss = sum(losses) / len(losses) if losses else 0
    expectancy = sum(rs) / n if n else 0
    gross_profit = sum(wins)
    gross_loss = abs(sum(losses))
    pf = gross_profit / gross_loss if gross_loss > 0 else float("inf")

    # 最大回撤（累计R曲线）
    cum = 0.0
    peak = 0.0
    max_dd = 0.0
    for r in rs:
        cum += r
        if cum > peak:
            peak = cum
        dd = peak - cum
        if dd > max_dd:
            max_dd = dd

    # 最大连亏
    max_consec_loss = 0
    cur_loss = 0
    for r in rs:
        if r <= 0:
            cur_loss += 1
            max_consec_loss = max(max_consec_loss, cur_loss)
        else:
            cur_loss = 0

    # 最大连盈
    max_consec_win = 0
    cur_win = 0
    for r in rs:
        if r > 0:
            cur_win += 1
            max_consec_win = max(max_consec_win, cur_win)
        else:
            cur_win = 0

    # Sharpe（简化：按笔数）
    if n > 1:
        mean_r = expectancy
        std_r = math.sqrt(sum((r - mean_r) ** 2 for r in rs) / (n - 1))
        sharpe = mean_r / std_r if std_r > 0 else 0.0
    else:
        sharpe = 0.0

    # 出场原因分布 + TP1/MFE 诊断
    reasons = defaultdict(int)
    tp1_hits = 0
    mfe_buckets = {"mfe_ge_0.5R": 0, "mfe_ge_0.8R": 0, "mfe_ge_1.0R": 0, "mfe_ge_1.5R": 0, "mfe_ge_2.0R": 0}
    mfe_ge_1r_then_stop = 0
    for t in trades:
        reason_raw = str(t.get("reason", "UNKNOWN"))
        r = reason_raw.split("|")[0].strip().upper()
        reasons[r] += 1
        if str(t.get("tp1_hit", "")).lower() in {"true", "1", "yes"} or "TP1_HIT" in reason_raw.upper():
            tp1_hits += 1
        mfe = safe_float(t.get("mfe_r", 0.0), 0.0)
        for threshold, key in [(0.5, "mfe_ge_0.5R"), (0.8, "mfe_ge_0.8R"), (1.0, "mfe_ge_1.0R"), (1.5, "mfe_ge_1.5R"), (2.0, "mfe_ge_2.0R")]:
            if mfe >= threshold:
                mfe_buckets[key] += 1
        if mfe >= 1.0 and r == "STOP":
            mfe_ge_1r_then_stop += 1

    return {
        "label": label,
        "trades": n,
        "win_rate": round(win_rate, 4),
        "expectancy_R": round(expectancy, 4),
        "profit_factor": round(pf, 3),
        "avg_win_R": round(avg_win, 4),
        "avg_loss_R": round(avg_loss, 4),
        "gross_profit_R": round(gross_profit, 3),
        "gross_loss_R": round(gross_loss, 3),
        "max_drawdown_R": round(max_dd, 3),
        "max_consec_loss": max_consec_loss,
        "max_consec_win": max_consec_win,
        "sharpe_per_trade": round(sharpe, 4),
        "exit_reasons": dict(reasons),
        "tp1_hits": tp1_hits,
        "tp2_hits": dict(reasons).get("TP2", 0),
        "stop_hits": dict(reasons).get("STOP", 0),
        "be_hits": dict(reasons).get("BE", 0),
        "mfe_thresholds": mfe_buckets,
        "mfe_ge_1r_then_stop": mfe_ge_1r_then_stop,
    }

# ─── 按维度分组 ───────────────────────────────────────────────────────────────
def group_by(trades: List[Dict], key_fn, label_fn=None) -> Dict[str, Dict]:
    groups = defaultdict(list)
    for t in trades:
        k = key_fn(t)
        groups[k].append(t)
    result = {}
    for k, rows in sorted(groups.items()):
        lbl = label_fn(k) if label_fn else str(k)
        result[str(k)] = compute_stats(rows, lbl)
    return result

# ─── Walk-Forward 检查（读现有 walk-forward 结果）────────────────────────────
def load_wf_results(ws_path: Path) -> Dict:
    wf_path = ws_path / "optimization_results.json"
    if wf_path.exists():
        return load_json(wf_path)
    return {}

# ─── Lookahead 检查 ───────────────────────────────────────────────────────────
def lookahead_check(trades: List[Dict]) -> Dict:
    """
    检查是否存在 lookahead bias：
    1. 同一 symbol 是否有 entry_time >= exit_time 的记录（时序错误）
    2. entry_time 是否全部在 BACKTEST_START 之后
    3. 检查是否有未来日期（exit_time > 2026-04-01）
    """
    issues = []
    future_threshold_ms = datetime(2026, 4, 2, tzinfo=timezone.utc).timestamp() * 1000

    bad_time_order = 0
    future_exits = 0
    entry_before_start = 0
    start_ts = datetime(2023, 1, 1, tzinfo=timezone.utc).timestamp() * 1000

    for t in trades:
        entry_t = safe_float(t.get("entry_time", 0))
        exit_t  = safe_float(t.get("exit_time", 0))

        if entry_t > 0 and exit_t > 0 and entry_t >= exit_t:
            bad_time_order += 1
        if exit_t > future_threshold_ms:
            future_exits += 1
        if entry_t > 0 and entry_t < start_ts:
            entry_before_start += 1

    if bad_time_order:
        issues.append(f"⚠️  {bad_time_order} 笔 entry_time >= exit_time（时序异常）")
    if future_exits:
        issues.append(f"⚠️  {future_exits} 笔 exit_time > 2026-04-01（超出回测范围）")
    if entry_before_start:
        issues.append(f"⚠️  {entry_before_start} 笔 entry_time < 2023-01-01（超出数据范围）")

    return {
        "passed": len(issues) == 0,
        "issues": issues if issues else ["✅ 无 lookahead 异常"],
        "bad_time_order": bad_time_order,
        "future_exits": future_exits,
        "entry_before_start": entry_before_start,
    }

# ─── 建议逻辑 ─────────────────────────────────────────────────────────────────
def make_recommendation(overall: Dict, by_year: Dict, lookahead: Dict) -> Dict:
    """
    严格判断是否建议进入 demo 小仓测试（不是实盘）。
    门槛：
      - 期望R > 0.1
      - PF > 1.2
      - 胜率 > 35%
      - 最大连亏 <= 10
      - 最大回撤 <= 15R
      - 至少 200 笔交易
      - lookahead 通过
      - 至少2个年份有正期望
    """
    reasons_for = []
    reasons_against = []

    exp = overall.get("expectancy_R", 0)
    pf  = overall.get("profit_factor", 0)
    wr  = overall.get("win_rate", 0)
    mcl = overall.get("max_consec_loss", 999)
    mdd = overall.get("max_drawdown_R", 999)
    n   = overall.get("trades", 0)

    if exp > 0.1:
        reasons_for.append(f"✅ 期望R={exp:.3f} > 0.1")
    else:
        reasons_against.append(f"❌ 期望R={exp:.3f} <= 0.1（不足）")

    if pf > 1.2:
        reasons_for.append(f"✅ PF={pf:.2f} > 1.2")
    else:
        reasons_against.append(f"❌ PF={pf:.2f} <= 1.2（不足）")

    if wr > 0.35:
        reasons_for.append(f"✅ 胜率={wr*100:.1f}% > 35%")
    else:
        reasons_against.append(f"❌ 胜率={wr*100:.1f}% <= 35%（不足）")

    if mcl <= 10:
        reasons_for.append(f"✅ 最大连亏={mcl} <= 10")
    else:
        reasons_against.append(f"❌ 最大连亏={mcl} > 10（风险过高）")

    if mdd <= 15:
        reasons_for.append(f"✅ 最大回撤={mdd:.1f}R <= 15R")
    else:
        reasons_against.append(f"❌ 最大回撤={mdd:.1f}R > 15R（风险过高）")

    if n >= 200:
        reasons_for.append(f"✅ 总交易笔数={n} >= 200")
    else:
        reasons_against.append(f"❌ 总交易笔数={n} < 200（样本不足）")

    if lookahead.get("passed"):
        reasons_for.append("✅ lookahead 检查通过")
    else:
        reasons_against.append(f"❌ lookahead 检查未通过：{lookahead.get('issues')}")

    # 检查多年正期望
    positive_years = [yr for yr, stats in by_year.items()
                      if isinstance(stats, dict) and stats.get("expectancy_R", -1) > 0]
    if len(positive_years) >= 2:
        reasons_for.append(f"✅ {len(positive_years)} 个年份正期望：{positive_years}")
    else:
        reasons_against.append(f"❌ 仅 {len(positive_years)} 个年份正期望（需要≥2年）")

    verdict = len(reasons_against) == 0
    if verdict:
        conclusion = "✅ 建议进入 demo 小仓测试（仅限观察模式开1-2笔极小仓，严格止损）"
    elif len(reasons_against) <= 2 and exp > 0:
        conclusion = "⚠️  结果偏正面但有瑕疵，建议先修复以下问题再考虑 demo 小仓"
    else:
        conclusion = "❌ 暂不建议进入 demo 小仓测试，需进一步优化策略"

    return {
        "verdict": verdict,
        "conclusion": conclusion,
        "for": reasons_for,
        "against": reasons_against,
        "NOTE": "⚠️ 即使 verdict=True，也绝不自动开放实盘。仅供人工决策参考。",
    }

# ─── 格式化输出 ───────────────────────────────────────────────────────────────
def fmt_stats(s: Dict, indent: str = "  ") -> str:
    if s.get("trades", 0) == 0:
        return f"{indent}无交易数据"
    lines = [
        f"{indent}交易笔数: {s['trades']}",
        f"{indent}胜率:     {s.get('win_rate', 0)*100:.1f}%",
        f"{indent}期望R:    {s.get('expectancy_R', 0):.4f}",
        f"{indent}PF:       {s.get('profit_factor', 0):.3f}",
        f"{indent}均盈:     {s.get('avg_win_R', 0):.3f}R  均亏: {s.get('avg_loss_R', 0):.3f}R",
        f"{indent}最大回撤: {s.get('max_drawdown_R', 0):.2f}R",
        f"{indent}最大连亏: {s.get('max_consec_loss', 0)} 笔",
        f"{indent}最大连盈: {s.get('max_consec_win', 0)} 笔",
        f"{indent}Sharpe:   {s.get('sharpe_per_trade', 0):.4f}",
    ]
    reasons = s.get("exit_reasons", {})
    if reasons:
        parts = ", ".join(f"{k}:{v}" for k, v in sorted(reasons.items(), key=lambda x: -x[1]))
        lines.append(f"{indent}出场原因: {parts}")
    return "\n".join(lines)

# ─── 主流程 ───────────────────────────────────────────────────────────────────
def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("Brain V11 全量回测合并分析（10个币）")
    print("=" * 60)

    # 1. 加载数据
    bt1 = load_csv(BT1_CSV)
    bt2 = load_csv(BT2_CSV)

    # 如果 CSV 不存在，尝试从 workspace 直接加载
    if not bt1:
        alt = BT1_WS / "backtest_trades.csv"
        bt1 = load_csv(alt)
        if bt1:
            import shutil
            shutil.copy(alt, BT1_CSV)
            print(f"[INFO] 从 workspace 复制: {alt}")

    if not bt2:
        alt = BT2_WS / "backtest_trades.csv"
        bt2 = load_csv(alt)
        if bt2:
            import shutil
            shutil.copy(alt, BT2_CSV)
            print(f"[INFO] 从 workspace 复制: {alt}")

    all_trades = bt1 + bt2
    if not all_trades:
        print("[ERROR] 没有任何交易数据，请确认回测已完成。")
        sys.exit(1)

    print(f"\n总计: BT1={len(bt1)} 笔 + BT2={len(bt2)} 笔 = 合并 {len(all_trades)} 笔\n")

    # 2. 解析时间字段，统一为 entry_time(ms)
    for t in all_trades:
        if not t.get("entry_time") and t.get("time"):
            t["entry_time"] = t["time"]

    # 3. 计算各维度统计
    overall = compute_stats(all_trades, "全体 10 币")

    # 按年
    def year_key(t):
        dt = iso_to_dt(str(t.get("entry_time", "")))
        return dt.year if dt else "unknown"

    # 按月
    def month_key(t):
        dt = iso_to_dt(str(t.get("entry_time", "")))
        return f"{dt.year}-{dt.month:02d}" if dt else "unknown"

    # 按币种
    def symbol_key(t):
        return str(t.get("symbol", "UNKNOWN"))

    # 按方向
    def direction_key(t):
        return str(t.get("direction", "UNKNOWN")).upper()

    by_year      = group_by(all_trades, year_key)
    by_month     = group_by(all_trades, month_key)
    by_symbol    = group_by(all_trades, symbol_key)
    by_direction = group_by(all_trades, direction_key)

    # 4. Walk-Forward 结果
    wf1 = load_wf_results(BT1_WS)
    wf2 = load_wf_results(BT2_WS)

    # 5. Lookahead 检查
    lookahead = lookahead_check(all_trades)

    # 6. 最大回撤详细
    # （已含在 compute_stats 里）

    # 7. 建议
    recommendation = make_recommendation(overall, by_year, lookahead)

    # ─── 格式化文本报告 ──────────────────────────────────────────────────────
    lines = []
    lines.append("=" * 60)
    lines.append("  Brain V11 全量回测合并报告（10 个币）")
    lines.append(f"  生成时间: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
    lines.append("=" * 60)

    lines.append("\n📊 一、总体回测结果")
    lines.append(fmt_stats(overall))

    lines.append("\n📅 二、按年份统计")
    for yr, stats in sorted(by_year.items()):
        lines.append(f"\n  [{yr}]")
        lines.append(fmt_stats(stats, "    "))

    lines.append("\n📆 三、按月份统计（期望R / PF / 笔数）")
    for mo, stats in sorted(by_month.items()):
        exp = stats.get('expectancy_R', 0)
        pf  = stats.get('profit_factor', 0)
        n   = stats.get('trades', 0)
        flag = "🟢" if exp > 0 else "🔴"
        lines.append(f"  {flag} {mo}: 期望R={exp:+.4f}  PF={pf:.2f}  {n}笔")

    lines.append("\n🪙 四、按币种统计")
    for sym, stats in sorted(by_symbol.items()):
        lines.append(f"\n  [{sym}]")
        lines.append(fmt_stats(stats, "    "))

    lines.append("\n↕️  五、按方向统计")
    for direction, stats in sorted(by_direction.items()):
        lines.append(f"\n  [{direction}]")
        lines.append(fmt_stats(stats, "    "))

    lines.append("\n🔄 六、Walk-Forward 结果")
    if wf1 or wf2:
        if wf1:
            lines.append("  BT1 (BTC/ETH/BNB/XRP/AVAX):")
            lines.append(f"    {json.dumps(wf1, ensure_ascii=False)[:300]}")
        if wf2:
            lines.append("  BT2 (SOL/DOGE/ADA/LINK/NEAR):")
            lines.append(f"    {json.dumps(wf2, ensure_ascii=False)[:300]}")
    else:
        lines.append("  ⚠️  本次回测未运行 walk-forward 优化（--backtest 模式不含 WF）")
        lines.append("  建议后续单独运行 --optimize 获取 WF 验证结果")

    lines.append("\n🔍 七、Lookahead 检查")
    for issue in lookahead.get("issues", []):
        lines.append(f"  {issue}")

    lines.append("\n📉 八、风险指标汇总")
    lines.append(f"  最大回撤:   {overall.get('max_drawdown_R', 0):.2f}R")
    lines.append(f"  最大连亏:   {overall.get('max_consec_loss', 0)} 笔")
    lines.append(f"  最大连盈:   {overall.get('max_consec_win', 0)} 笔")
    lines.append(f"  Sharpe:     {overall.get('sharpe_per_trade', 0):.4f}")

    lines.append("\n🏁 九、是否建议进入 demo 小仓测试")
    lines.append(f"\n  结论: {recommendation['conclusion']}")
    lines.append("\n  支持理由:")
    for r in recommendation.get("for", []):
        lines.append(f"    {r}")
    lines.append("\n  反对理由:")
    for r in recommendation.get("against", []):
        lines.append(f"    {r}")
    lines.append(f"\n  ⚠️  {recommendation.get('NOTE', '')}")

    lines.append("\n" + "=" * 60)
    report_text = "\n".join(lines)

    # 写文本报告
    OUTPUT_TXT.write_text(report_text, encoding="utf-8")
    print(report_text)

    # 写 JSON 报告
    report_json = {
        "overall": overall,
        "by_year": by_year,
        "by_month": by_month,
        "by_symbol": by_symbol,
        "by_direction": by_direction,
        "walk_forward_bt1": wf1,
        "walk_forward_bt2": wf2,
        "lookahead_check": lookahead,
        "recommendation": recommendation,
    }
    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(report_json, f, ensure_ascii=False, indent=2)
    print(f"\n✅ JSON 报告: {OUTPUT_JSON}")
    print(f"✅ 文本报告: {OUTPUT_TXT}")

    # 写通知文件（心跳推送）
    short_summary = f"""🎉 Brain V11 全量回测完成（10 个币）

📊 总体结果
{fmt_stats(overall, '  ')}

🏁 建议: {recommendation['conclusion']}

📁 详细报告: {OUTPUT_TXT}
"""
    NOTIFY_FILE.write_text(short_summary, encoding="utf-8")
    print("\n✅ 通知已写入 pending_notify.txt")

if __name__ == "__main__":
    main()
