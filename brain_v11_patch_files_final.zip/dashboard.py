#!/usr/bin/env python3
# Brain V11 Dashboard — Binance-style Pro UI (界面重构版，不改策略/数据源/交易逻辑)
import os, json, csv, html, base64, datetime
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler

DATA_DIR = Path(os.getenv("DASHBOARD_DIR", "/root/brain/brain_demo_data"))
HOST     = os.getenv("DASHBOARD_HOST", "0.0.0.0")
PORT     = int(os.getenv("DASHBOARD_PORT", "8080"))
PASSWORD = os.getenv("DASHBOARD_PASSWORD", "")

if not PASSWORD:
    raise SystemExit("请先设置 DASHBOARD_PASSWORD，不能空密码运行")

# ─── 数据读取 ────────────────────────────────────────────────────────────────

def read_json(name):
    try:
        p = DATA_DIR / name
        return json.loads(p.read_text(errors="ignore")) if p.exists() else None
    except Exception:
        return None

def read_csv_tail(name, limit=30):
    p = DATA_DIR / name
    if not p.exists():
        return []
    try:
        with p.open(errors="ignore") as f:
            return list(csv.DictReader(f))[-limit:]
    except Exception:
        return []

def read_log_tail(name, lines=60):
    p = DATA_DIR / name
    if not p.exists():
        return []
    try:
        txt = p.read_text(errors="ignore")
        return txt.strip().splitlines()[-lines:]
    except Exception:
        return []

def read_jsonl_tail(name, limit=10):
    p = DATA_DIR / name
    if not p.exists():
        return []
    try:
        rows = []
        for line in p.read_text(errors="ignore").strip().splitlines()[-limit:]:
            try: rows.append(json.loads(line))
            except Exception: pass
        return rows
    except Exception:
        return []

def esc(x): return html.escape(str(x) if x is not None else "")

def fmt_num(v, digits=4):
    try:
        f = float(v)
        if abs(f) >= 1000: return f"{f:,.2f}"
        if abs(f) >= 1:    return f"{f:.{digits}f}".rstrip("0").rstrip(".")
        return f"{f:.8f}".rstrip("0").rstrip(".")
    except Exception:
        return str(v)

def pnl_class(v):
    try:
        return "pos" if float(v) >= 0 else "neg"
    except Exception:
        return ""

def score_class(v):
    try:
        s = float(v)
        if s >= 80: return "score-a"
        if s >= 65: return "score-b"
        if s >= 50: return "score-c"
        return "score-d"
    except Exception:
        return "score-d"

def tier_badge(t):
    t = str(t).upper()
    cls = {"A":"tier-a","B":"tier-b","C":"tier-c","D":"tier-d"}.get(t,"tier-d")
    return f'<span class="badge {cls}">{esc(t)}</span>'

def status_badge(s, text=None):
    s = str(s).upper()
    text = text or s
    cls = {
        "RUNNING":"badge-green","OK":"badge-green","EXECUTABLE":"badge-green","READY":"badge-green",
        "STOPPED":"badge-red","ERROR":"badge-red","REJECT":"badge-red","BLOCKED":"badge-red",
        "WARNING":"badge-yellow","PAPER_ONLY":"badge-yellow","OBSERVE":"badge-yellow",
        "DEMO":"badge-blue","PAPER":"badge-blue","LIVE":"badge-gold",
        "NO_TRADE":"badge-gray","NORMAL":"badge-green",
    }.get(s, "badge-gray")
    return f'<span class="badge {cls}">{esc(text)}</span>'

def dir_badge(d):
    d = str(d).upper()
    if d == "LONG":  return '<span class="badge badge-green">▲ LONG</span>'
    if d == "SHORT": return '<span class="badge badge-red">▼ SHORT</span>'
    return '<span class="badge badge-gray">— NO_TRADE</span>'

# ─── 页面模块 ────────────────────────────────────────────────────────────────

def build_overview(health, risk, proc):
    mode     = str((health or {}).get("mode") or (risk or {}).get("mode") or "—").upper()
    status   = str((health or {}).get("status","—")).upper()
    equity   = (health or {}).get("broker",{}).get("equity", "—")
    pos_cnt  = (health or {}).get("broker",{}).get("positions", 0)
    regime   = (proc or {}).get("regime",{})
    bias     = str(regime.get("bias","—")).upper()
    btc_p    = regime.get("btc_price","—")
    atr_pct  = regime.get("atr_pct","—")
    r_score  = regime.get("score","—")
    approved = (risk or {}).get("candidate_counts",{}).get("risk_approved",0)
    total_c  = (risk or {}).get("candidate_counts",{}).get("total",0)
    update_t = (proc or {}).get("time","—")
    if update_t and update_t != "—":
        try:
            dt = datetime.datetime.fromisoformat(update_t.replace("Z","+00:00"))
            dt_cst = dt + datetime.timedelta(hours=8)
            update_t = dt_cst.strftime("%H:%M:%S CST")
        except Exception: pass

    tier_counts = (proc or {}).get("tier_counts",{})
    ta = tier_counts.get("A",0); tb = tier_counts.get("B",0)
    tc = tier_counts.get("C",0); td = tier_counts.get("D",0)

    bias_cls = "pos" if bias=="LONG" else ("neg" if bias=="SHORT" else "muted")
    eq_str   = fmt_num(equity) if equity != "—" else "—"
    btc_str  = fmt_num(btc_p) if btc_p != "—" else "—"
    atr_str  = f"{float(atr_pct):.2f}%" if atr_pct != "—" else "—"

    return f"""
<div class="overview-grid">
  <div class="ov-card">
    <div class="ov-label">机器人状态</div>
    <div class="ov-val">{status_badge(status)}</div>
  </div>
  <div class="ov-card">
    <div class="ov-label">运行模式</div>
    <div class="ov-val">{status_badge(mode)}</div>
  </div>
  <div class="ov-card">
    <div class="ov-label">总资产 (USDT)</div>
    <div class="ov-val big-num">{esc(eq_str)}</div>
  </div>
  <div class="ov-card">
    <div class="ov-label">当前持仓</div>
    <div class="ov-val big-num">{esc(str(pos_cnt))}</div>
  </div>
  <div class="ov-card">
    <div class="ov-label">市场偏向</div>
    <div class="ov-val {bias_cls} big-num">{esc(bias)}</div>
  </div>
  <div class="ov-card">
    <div class="ov-label">BTC 价格</div>
    <div class="ov-val big-num">${esc(btc_str)}</div>
  </div>
  <div class="ov-card">
    <div class="ov-label">市场ATR%</div>
    <div class="ov-val">{esc(atr_str)}</div>
  </div>
  <div class="ov-card">
    <div class="ov-label">Regime Score</div>
    <div class="ov-val big-num">{esc(str(r_score))}</div>
  </div>
  <div class="ov-card">
    <div class="ov-label">候选信号 / 通过</div>
    <div class="ov-val big-num">{esc(str(total_c))} <span class="muted">/ {esc(str(approved))}</span></div>
  </div>
  <div class="ov-card">
    <div class="ov-label">候选等级分布</div>
    <div class="ov-val">
      <span class="badge tier-a">A:{ta}</span>
      <span class="badge tier-b">B:{tb}</span>
      <span class="badge tier-c">C:{tc}</span>
      <span class="badge tier-d">D:{td}</span>
    </div>
  </div>
  <div class="ov-card ov-wide">
    <div class="ov-label">最近更新</div>
    <div class="ov-val muted">{esc(update_t)}</div>
  </div>
</div>"""

def build_positions(health, proc):
    # 当前持仓只能来自 healthcheck.broker.position_detail（demo_fapi / live_fapi / paper_state）。
    # 不能把 process_dashboard.top 里的候选 plan 当作持仓，否则会出现 UI 假持仓。
    broker_pos = (health or {}).get("broker",{}).get("position_detail",{}) or {}
    if not isinstance(broker_pos, dict) or not broker_pos:
        return '<p class="muted" style="padding:12px 0">暂无持仓</p>'

    rows = ""
    for sym, p in broker_pos.items():
        amt = fmt_num(p.get("positionAmt", p.get("qty", "—")))
        # Binance one-way mode returns positionSide="BOTH". Prefer positionAmt
        # to infer the real LONG/SHORT direction for dashboard display.
        raw_dir = p.get("direction") or ""
        try:
            a = float(p.get("positionAmt", p.get("qty", 0)) or 0)
            if a > 0:
                raw_dir = "LONG"
            elif a < 0:
                raw_dir = "SHORT"
        except Exception:
            pass
        if not raw_dir or str(raw_dir).upper() == "BOTH":
            raw_dir = p.get("positionSide") or "—"
        entry  = p.get("entryPrice", p.get("entry", "—"))
        mark   = p.get("markPrice", p.get("latest", "—"))
        pnl    = p.get("unRealizedProfit", p.get("unrealized_pnl", "—"))
        sl     = p.get("stop_loss", "—")
        tp2    = p.get("tp2", "—")
        pnl_c  = pnl_class(pnl) if pnl != "—" else ""
        pnl_str = f'<span class="{pnl_c}">{esc(fmt_num(pnl))}</span>' if pnl != "—" else "—"
        rows += f"""<tr>
          <td class="sym">{esc(sym)}</td>
          <td>{dir_badge(raw_dir)}</td>
          <td>{esc(fmt_num(entry))}</td>
          <td>{esc(fmt_num(mark))}</td>
          <td>{pnl_str}</td>
          <td class="muted">{esc(fmt_num(amt))}</td>
          <td class="neg">{esc(fmt_num(sl))}</td>
          <td class="pos">{esc(fmt_num(tp2))}</td>
          <td>{status_badge("OPEN")}</td>
        </tr>"""
    return f"""<div class="table-wrap"><table>
      <thead><tr>
        <th>币对</th><th>方向</th><th>开仓价</th><th>最新价</th>
        <th>浮盈亏</th><th>数量</th><th>止损</th><th>止盈</th><th>状态</th>
      </tr></thead>
      <tbody>{rows}</tbody>
    </table></div>"""

def build_signals(proc):
    top = (proc or {}).get("top", [])
    if not top:
        return '<p class="muted" style="padding:12px 0">暂无候选信号</p>'
    rows = ""
    for c in top[:15]:
        sym      = c.get("symbol","—")
        score    = c.get("score","—")
        direction= c.get("direction","NO_TRADE")
        entry    = c.get("entry","—")
        sl       = c.get("stop_loss","—")
        setup    = c.get("setup","—")
        tier     = c.get("process_tier","D")
        status   = c.get("v11_gate",{}).get("status","REJECT")
        blockers = c.get("blockers",[]) or c.get("risk_blockers",[]) or []
        reasons  = c.get("reasons",[]) or []
        rsi      = c.get("rsi","—")
        atr_pct  = c.get("atr_pct","—")

        reason_short = " · ".join(str(r) for r in reasons[:2]) if reasons else "—"
        blocker_short= (str(blockers[0]) if blockers else "")
        reason_tip   = esc(" | ".join(str(r) for r in reasons[:5]))
        blocker_tip  = esc(" | ".join(str(b) for b in blockers[:5]))

        stat_badge = status_badge(status, {
            "EXECUTABLE":"可开仓","PAPER_ONLY":"观察中","REJECT":"被拦截"
        }.get(status, status))

        sc_str = fmt_num(score, 1) if score != "—" else "—"
        sc_cls = score_class(score)
        rsi_str = fmt_num(rsi, 1) if rsi != "—" else "—"
        atr_str = f"{float(atr_pct):.2f}%" if atr_pct != "—" else "—"

        rows += f"""<tr>
          <td class="sym">{esc(sym)}</td>
          <td>{tier_badge(tier)}</td>
          <td><span class="{sc_cls} score-pill">{esc(sc_str)}</span></td>
          <td>{dir_badge(direction)}</td>
          <td>{esc(fmt_num(entry))}</td>
          <td class="neg">{esc(fmt_num(sl))}</td>
          <td class="muted" style="font-size:12px">{esc(rsi_str)}</td>
          <td class="muted" style="font-size:12px">{esc(atr_str)}</td>
          <td title="{reason_tip}" class="reason-col">{esc(reason_short[:40])}</td>
          <td title="{blocker_tip}" class="reason-col neg">{esc(blocker_short[:35])}</td>
          <td>{stat_badge}</td>
        </tr>"""
    return f"""<div class="table-wrap"><table>
      <thead><tr>
        <th>币对</th><th>等级</th><th>分数</th><th>方向</th>
        <th>入场价</th><th>止损价</th><th>RSI</th><th>ATR%</th>
        <th>支持理由</th><th>拦截原因</th><th>状态</th>
      </tr></thead>
      <tbody>{rows}</tbody>
    </table></div>"""

def build_ai_decisions(decisions):
    if not decisions:
        return '<p class="muted" style="padding:12px 0">暂无 AI 决策记录</p>'
    rows = ""
    for d in reversed(decisions[-8:]):
        dec  = d.get("decision",{})
        t    = d.get("time","—")
        if t and t != "—":
            try:
                dt = datetime.datetime.fromisoformat(t.replace("Z","+00:00"))
                dt_cst = dt + datetime.timedelta(hours=8)
                t  = dt_cst.strftime("%H:%M:%S")
            except Exception: pass
        action   = dec.get("action","—")
        symbol   = dec.get("symbol","—") or "—"
        direction= dec.get("direction","—") or "—"
        confidence = dec.get("confidence","—")
        reason   = " · ".join(dec.get("reason",[])[:2]) if dec.get("reason") else "—"
        executed = d.get("executed", False)
        mode     = d.get("mode","—")
        act_badge = status_badge("READY" if action=="TRADE" else "NO_TRADE",
                                  "TRADE" if action=="TRADE" else "NO_TRADE")
        exec_badge = status_badge("RUNNING" if executed else "STOPPED",
                                   "已执行" if executed else "未执行")
        conf_str = f"{float(confidence):.0%}" if confidence != "—" else "—"
        rows += f"""<tr>
          <td class="muted" style="font-size:12px">{esc(t)}</td>
          <td>{act_badge}</td>
          <td class="sym">{esc(symbol)}</td>
          <td>{dir_badge(direction)}</td>
          <td class="muted">{esc(conf_str)}</td>
          <td style="font-size:12px">{esc(reason[:50])}</td>
          <td>{exec_badge}</td>
        </tr>"""
    return f"""<div class="table-wrap"><table>
      <thead><tr>
        <th>时间</th><th>决策</th><th>币对</th><th>方向</th>
        <th>置信度</th><th>原因</th><th>执行</th>
      </tr></thead>
      <tbody>{rows}</tbody>
    </table></div>"""

def build_trades(trades):
    if not trades:
        return '<p class="muted" style="padding:12px 0">暂无成交记录</p>'
    rows = ""
    for r in reversed(trades[-15:]):
        t    = (r.get("time","") or "")
        if t:
            try:
                dt_obj = datetime.datetime.fromisoformat(t.replace("Z","+00:00"))
                t = (dt_obj + datetime.timedelta(hours=8)).strftime("%m-%d %H:%M")
            except Exception:
                t = t[:16].replace("T"," ")
        evt  = r.get("event","—")
        sym  = r.get("symbol","—")
        drn  = r.get("direction","—")
        setup= r.get("setup","—")
        price= r.get("price","—")
        qty  = r.get("qty","—")
        pnl  = r.get("pnl","—")
        bal  = r.get("balance","—")
        pnl_c = pnl_class(pnl)
        evt_cls = {"OPEN":"badge-blue","CLOSE":"badge-green","TP1":"badge-green",
                   "TP2":"badge-green","STOP":"badge-red"}.get(str(evt).upper(),"badge-gray")
        rows += f"""<tr>
          <td class="muted" style="font-size:12px">{esc(t)}</td>
          <td><span class="badge {evt_cls}">{esc(evt)}</span></td>
          <td class="sym">{esc(sym)}</td>
          <td>{dir_badge(drn)}</td>
          <td class="muted" style="font-size:12px">{esc(setup)}</td>
          <td>{esc(fmt_num(price))}</td>
          <td>{esc(fmt_num(qty))}</td>
          <td class="{pnl_c}">{esc(fmt_num(pnl))}</td>
          <td>{esc(fmt_num(bal))}</td>
        </tr>"""
    return f"""<div class="table-wrap"><table>
      <thead><tr>
        <th>时间</th><th>事件</th><th>币对</th><th>方向</th>
        <th>策略</th><th>价格</th><th>数量</th><th>盈亏</th><th>余额</th>
      </tr></thead>
      <tbody>{rows}</tbody>
    </table></div>"""

def build_risk(health, risk, audit):
    cfg = (health or {}).get("config",{})
    files= (health or {}).get("files",{})
    circuit = (risk or {}).get("circuit_blockers",[]) or []
    portfolio = (risk or {}).get("portfolio",{}) or {}

    def cfg_row(label, val, warn_fn=None):
        warn = warn_fn(val) if warn_fn else False
        cls = "neg" if warn else ""
        return f'<div class="kv-row"><span class="kv-label">{esc(label)}</span><span class="kv-val {cls}">{esc(str(val))}</span></div>'

    risk_pct = cfg.get("risk_per_trade",0)
    daily_loss = cfg.get("daily_max_loss_pct",0)
    score_th = cfg.get("score_threshold",0)
    min_rr   = cfg.get("min_rr",0)
    max_pos  = cfg.get("max_positions",0)

    file_rows = ""
    for k, finfo in (files or {}).items():
        exists = finfo.get("exists",False)
        size   = finfo.get("size",0)
        badge  = status_badge("RUNNING" if exists else "STOPPED", "存在" if exists else "缺失")
        file_rows += f'<div class="kv-row"><span class="kv-label">{esc(k)}</span><span>{badge} <span class="muted" style="font-size:11px">{size}B</span></span></div>'

    circuit_html = ""
    if circuit:
        circuit_html = '<div class="alert-row neg">⚠ 熔断: ' + esc(", ".join(str(x) for x in circuit)) + '</div>'
    else:
        circuit_html = '<div class="alert-row pos">✓ 熔断器正常，无阻断</div>'

    open_ev  = (audit or {}).get("open_events", 0)
    exit_ev  = (audit or {}).get("exit_events", 0)
    slip_avg = (audit or {}).get("avg_open_slippage_bps", 0)

    return f"""
<div class="risk-grid">
  <div class="risk-block">
    <div class="block-title">风控参数</div>
    {cfg_row("单笔风险", f"{float(risk_pct)*100:.2f}%")}
    {cfg_row("日亏损熔断", f"{float(daily_loss)*100:.1f}%")}
    {cfg_row("最低信号分", score_th)}
    {cfg_row("最低R:R比", min_rr)}
    {cfg_row("最大同时持仓", max_pos)}
    {cfg_row("每轮最多开仓", cfg.get("max_new_entries_per_cycle", "N/A"))}
    {cfg_row("单笔风险", f"{float(cfg.get('risk_per_trade', 0))*100:.2f}%")}
  </div>
  <div class="risk-block">
    <div class="block-title">D+F 策略参数</div>
    {cfg_row("交易模式", cfg.get("trading_mode", "N/A"))}
    {cfg_row("Setup白名单", cfg.get("SETUP_WHITELIST", cfg.get("setup_whitelist", "N/A")))}
    {cfg_row("同向确认V2", "✅ 开启" if cfg.get("ENABLE_CONFIRM_V2") else "❌ 关闭")}
    {cfg_row("Trend入场", "✅ 开启" if cfg.get("ENABLE_TREND_SETUP") else "❌ 关闭")}
    {cfg_row("MIN_ATR%", cfg.get("min_atr_pct", "N/A"))}
    {cfg_row("回测质量门", "✅ 要求" if cfg.get("REQUIRE_BACKTEST_QUALITY_GATE") else "❌ 关闭(测试)")}
  </div>
  <div class="risk-block">
    <div class="block-title">执行审计</div>
    {cfg_row("开仓次数", open_ev)}
    {cfg_row("平仓次数", exit_ev)}
    {cfg_row("平均滑点", f"{slip_avg:.2f} bps")}
  </div>
  <div class="risk-block">
    <div class="block-title">文件状态</div>
    {file_rows}
  </div>
  <div class="risk-block risk-full">
    <div class="block-title">系统熔断</div>
    {circuit_html}
  </div>
</div>"""

def build_log(lines):
    if not lines:
        return '<p class="muted" style="padding:8px 0">暂无日志</p>'
    colored = []
    for ln in lines:
        if "ERROR" in ln or "CRITICAL" in ln:
            colored.append(f'<span class="log-err">{esc(ln)}</span>')
        elif "WARNING" in ln or "WARN" in ln:
            colored.append(f'<span class="log-warn">{esc(ln)}</span>')
        elif "开仓" in ln or "OPEN" in ln or "TP" in ln:
            colored.append(f'<span class="log-trade">{esc(ln)}</span>')
        elif "INFO" in ln:
            colored.append(f'<span class="log-info">{esc(ln)}</span>')
        else:
            colored.append(esc(ln))
    return "<pre class='log-pre'>" + "\n".join(colored) + "</pre>"

# ─── HTTP Handler ─────────────────────────────────────────────────────────────

class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args): pass  # 静音访问日志

    def auth_ok(self):
        hdr = self.headers.get("Authorization","")
        expected = "Basic " + base64.b64encode(f"admin:{PASSWORD}".encode()).decode()
        return hdr == expected

    def do_GET(self):
        if not self.auth_ok():
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="Brain Dashboard"')
            self.end_headers()
            self.wfile.write(b"Auth required")
            return

        # ── /dl/<filename> 文件下载端点 ──────────────────────────────
        from urllib.parse import urlparse, unquote
        parsed_path = urlparse(self.path).path
        if parsed_path.startswith("/dl/"):
            fname = unquote(parsed_path[4:])
            # 只允许下载 audit_*.zip 文件，防止目录穿越
            import re as _re
            if not _re.match(r'^audit_[a-f0-9]+\.zip$', fname):
                self.send_response(403)
                self.end_headers()
                self.wfile.write(b"Forbidden")
                return
            dl_path = DATA_DIR / fname
            if not dl_path.exists():
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"Not found")
                return
            data = dl_path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition", f'attachment; filename="{fname}"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        health    = read_json("healthcheck.json")
        risk      = read_json("v11_risk_dashboard.json")
        proc      = read_json("process_dashboard.json")
        audit     = read_json("execution_audit.json")
        decisions = read_jsonl_tail("ai_decisions.jsonl", 10)
        trades    = read_csv_tail("trades.csv", 30)
        log_lines = read_log_tail("brain_v11.log", 80)

        mode = str((health or {}).get("mode") or (risk or {}).get("mode") or "DEMO").upper()
        status = str((health or {}).get("status","OK")).upper()
        status_cls = "status-ok" if status=="OK" else "status-err"
        now_str = (datetime.datetime.utcnow() + datetime.timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S CST")

        page = f"""<!doctype html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<meta http-equiv="refresh" content="30">
<title>Brain V11 | {esc(mode)} Dashboard</title>
<style>
:root{{
  --bg:#0b0e17; --bg2:#111827; --bg3:#1a2235; --bg4:#222e45;
  --border:#2a3650; --gold:#f0b90b; --gold2:#d4a017;
  --text:#e2e8f0; --muted:#64748b; --dim:#94a3b8;
  --green:#22c55e; --red:#ef4444; --blue:#3b82f6; --yellow:#eab308;
  --radius:12px; --radius-sm:8px;
}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;font-size:14px;line-height:1.5}}
a{{color:var(--gold);text-decoration:none}}

/* ── Top bar ── */
.topbar{{background:var(--bg2);border-bottom:1px solid var(--border);padding:0 16px;display:flex;align-items:center;justify-content:space-between;height:56px;position:sticky;top:0;z-index:100}}
.topbar-logo{{display:flex;align-items:center;gap:10px;font-weight:700;font-size:17px;color:var(--gold)}}
.topbar-logo svg{{width:28px;height:28px}}
.topbar-right{{display:flex;align-items:center;gap:10px;font-size:12px;color:var(--dim)}}
.status-dot{{width:8px;height:8px;border-radius:50%;display:inline-block;margin-right:4px}}
.status-ok .status-dot{{background:var(--green);box-shadow:0 0 6px var(--green)}}
.status-err .status-dot{{background:var(--red);box-shadow:0 0 6px var(--red)}}

/* ── Layout ── */
.main{{max-width:1400px;margin:0 auto;padding:16px}}
.section{{margin-bottom:20px}}
.section-title{{font-size:13px;font-weight:600;color:var(--gold);text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px;display:flex;align-items:center;gap:8px}}
.section-title::after{{content:'';flex:1;height:1px;background:var(--border)}}
.card{{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);padding:16px;margin-bottom:14px}}
.card-sm{{padding:12px}}

/* ── Overview grid ── */
.overview-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-bottom:4px}}
.ov-card{{background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px 14px}}
.ov-wide{{grid-column:span 2}}
.ov-label{{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}}
.ov-val{{font-size:15px;font-weight:600}}
.big-num{{font-size:20px;font-weight:700;color:var(--text)}}

/* ── Two-col layout ── */
.two-col{{display:grid;grid-template-columns:1fr 1fr;gap:14px}}
@media(max-width:700px){{.two-col{{grid-template-columns:1fr}}}}

/* ── Tables ── */
.table-wrap{{overflow-x:auto;-webkit-overflow-scrolling:touch}}
table{{width:100%;border-collapse:collapse;min-width:600px}}
th{{background:var(--bg3);color:var(--dim);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;padding:9px 10px;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap}}
td{{padding:9px 10px;border-bottom:1px solid #1e2840;vertical-align:middle;font-size:13px}}
tr:last-child td{{border-bottom:none}}
tr:hover td{{background:rgba(240,185,11,.04)}}
.sym{{font-weight:700;color:var(--text);font-size:13px}}
.reason-col{{max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;color:var(--dim)}}

/* ── Badges ── */
.badge{{display:inline-block;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:600;white-space:nowrap}}
.badge-green{{background:rgba(34,197,94,.15);color:#4ade80;border:1px solid rgba(34,197,94,.25)}}
.badge-red{{background:rgba(239,68,68,.15);color:#f87171;border:1px solid rgba(239,68,68,.25)}}
.badge-yellow{{background:rgba(234,179,8,.15);color:#facc15;border:1px solid rgba(234,179,8,.25)}}
.badge-blue{{background:rgba(59,130,246,.15);color:#60a5fa;border:1px solid rgba(59,130,246,.25)}}
.badge-gold{{background:rgba(240,185,11,.15);color:var(--gold);border:1px solid rgba(240,185,11,.35)}}
.badge-gray{{background:rgba(100,116,139,.15);color:#94a3b8;border:1px solid rgba(100,116,139,.2)}}
.tier-a{{background:rgba(240,185,11,.18);color:var(--gold);border:1px solid rgba(240,185,11,.35)}}
.tier-b{{background:rgba(34,197,94,.15);color:#4ade80;border:1px solid rgba(34,197,94,.25)}}
.tier-c{{background:rgba(234,179,8,.12);color:#fde047;border:1px solid rgba(234,179,8,.2)}}
.tier-d{{background:rgba(239,68,68,.1);color:#fca5a5;border:1px solid rgba(239,68,68,.15)}}

/* ── Score pills ── */
.score-pill{{display:inline-block;padding:2px 8px;border-radius:6px;font-weight:700;font-size:13px}}
.score-a{{color:#4ade80;background:rgba(34,197,94,.12)}}
.score-b{{color:var(--gold);background:rgba(240,185,11,.1)}}
.score-c{{color:#fde047;background:rgba(234,179,8,.1)}}
.score-d{{color:#f87171;background:rgba(239,68,68,.1)}}

/* ── Colors ── */
.pos{{color:var(--green)}}
.neg{{color:var(--red)}}
.muted{{color:var(--muted)}}
.gold{{color:var(--gold)}}

/* ── Risk grid ── */
.risk-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}}
.risk-full{{grid-column:1/-1}}
.risk-block{{background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px}}
.block-title{{font-size:11px;font-weight:600;color:var(--dim);text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px;padding-bottom:6px;border-bottom:1px solid var(--border)}}
.kv-row{{display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.04);font-size:12px}}
.kv-row:last-child{{border-bottom:none}}
.kv-label{{color:var(--dim)}}
.kv-val{{font-weight:600;color:var(--text)}}
.alert-row{{padding:8px 12px;border-radius:var(--radius-sm);font-size:12px;font-weight:500}}
.alert-row.pos{{background:rgba(34,197,94,.08);color:#4ade80;border:1px solid rgba(34,197,94,.2)}}
.alert-row.neg{{background:rgba(239,68,68,.08);color:#f87171;border:1px solid rgba(239,68,68,.2)}}

/* ── Log ── */
.log-pre{{background:#080c14;border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px;font-size:11px;font-family:'JetBrains Mono','Fira Code',monospace;white-space:pre-wrap;word-break:break-all;max-height:320px;overflow-y:auto;color:#94a3b8;line-height:1.6}}
.log-err{{color:#f87171}}
.log-warn{{color:#facc15}}
.log-trade{{color:#4ade80}}
.log-info{{color:#94a3b8}}

/* ── Collapse ── */
details>summary{{cursor:pointer;list-style:none;display:flex;align-items:center;gap:6px;padding:4px 0;user-select:none;font-size:13px;color:var(--dim)}}
details>summary::before{{content:'▶';font-size:10px;transition:transform .2s}}
details[open]>summary::before{{transform:rotate(90deg)}}
details>summary::-webkit-details-marker{{display:none}}

/* ── Footer ── */
.footer{{text-align:center;color:var(--muted);font-size:11px;padding:20px 0 30px}}

/* ── Mobile ── */
@media(max-width:480px){{
  .main{{padding:10px}}
  .topbar{{padding:0 12px}}
  .overview-grid{{grid-template-columns:repeat(2,1fr)}}
  .ov-wide{{grid-column:span 2}}
  .big-num{{font-size:17px}}
  .card{{padding:12px}}
  th,td{{padding:7px 8px}}
}}
</style>
</head>
<body>

<!-- ── Top Bar ── -->
<div class="topbar">
  <div class="topbar-logo">
    <svg viewBox="0 0 32 32" fill="none">
      <rect width="32" height="32" rx="8" fill="#F0B90B"/>
      <path d="M16 6l3.5 3.5-3.5 3.5-3.5-3.5L16 6z" fill="#000"/>
      <path d="M6 16l3.5-3.5L13 16l-3.5 3.5L6 16z" fill="#000"/>
      <path d="M26 16l-3.5-3.5L19 16l3.5 3.5L26 16z" fill="#000"/>
      <path d="M16 26l-3.5-3.5L16 19l3.5 3.5L16 26z" fill="#000"/>
      <path d="M16 12.5l3.5 3.5-3.5 3.5-3.5-3.5 3.5-3.5z" fill="#000"/>
    </svg>
    Brain V11 &nbsp;<span style="color:var(--dim);font-weight:400;font-size:13px">Dashboard</span>
  </div>
  <div class="topbar-right">
    <span class="{status_cls}"><span class="status-dot"></span>{esc(status)}</span>
    <span class="badge badge-{'gold' if mode=='LIVE' else 'blue'}">{esc(mode)}</span>
    <span style="color:var(--muted)">{esc(now_str)}</span>
    <span class="muted">⟳ 30s</span>
  </div>
</div>

<div class="main">

<!-- ── Overview ── -->
<div class="section">
  <div class="section-title">📊 总览</div>
  <div class="card">
    {build_overview(health, risk, proc)}
  </div>
</div>

<!-- ── Positions ── -->
<div class="section">
  <div class="section-title">💼 当前持仓</div>
  <div class="card card-sm">
    {build_positions(health, proc)}
  </div>
</div>

<!-- ── Signals ── -->
<div class="section">
  <div class="section-title">🎯 候选信号</div>
  <div class="card card-sm">
    {build_signals(proc)}
  </div>
</div>

<!-- ── AI Decisions ── -->
<div class="section">
  <div class="section-title">🤖 AI 决策记录</div>
  <div class="card card-sm">
    {build_ai_decisions(decisions)}
  </div>
</div>

<!-- ── Trades ── -->
<div class="section">
  <div class="section-title">📋 最近成交</div>
  <div class="card card-sm">
    {build_trades(trades)}
  </div>
</div>

<!-- ── Risk ── -->
<div class="section">
  <div class="section-title">🛡️ 风险控制</div>
  <div class="card card-sm">
    {build_risk(health, risk, audit)}
  </div>
</div>

<!-- ── Log (collapsed) ── -->
<div class="section">
  <div class="section-title">📜 运行日志</div>
  <div class="card card-sm">
    <details>
      <summary>展开日志（最近 80 行）</summary>
      <div style="margin-top:10px">
        {build_log(log_lines)}
      </div>
    </details>
  </div>
</div>

</div><!-- /main -->

<div class="footer">Brain V11 · 只读监控面板 · 不执行任何交易 · 数据目录: {esc(str(DATA_DIR))}</div>

</body>
</html>"""

        self.send_response(200)
        self.send_header("Content-Type","text/html; charset=utf-8")
        self.send_header("Cache-Control","no-cache")
        self.end_headers()
        self.wfile.write(page.encode("utf-8"))


print(f"Dashboard running on http://{HOST}:{PORT}, data={DATA_DIR}")
HTTPServer((HOST, PORT), Handler).serve_forever()
