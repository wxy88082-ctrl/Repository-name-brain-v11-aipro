#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Brain V11 Hotfix V6
修复范围：
1) demo-fapi / Binance requests 卡死、CLOSE-WAIT、主循环不写日志
2) Dashboard 最近成交 / 持仓历史过长，默认折叠展示
3) 平仓盈亏去重，避免 userTrades + income 双来源重复累加
4) 增加 V6 小样本回测 smoke 与 A/B/C/D/E 诊断脚本

用法：
  cd /root/brain
  python3 brain_v11_hotfix_v6_api_history_ui_backtest.py

安全原则：
- 不切换实盘
- 不平仓
- 不撤保护单
- 不删除历史文件；所有修改都会备份
"""
from __future__ import annotations

import json
import os
import re
import shutil
import stat
import subprocess
import sys
import textwrap
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

ROOT = Path.cwd()
DATA_DIR = ROOT / "brain_demo_data"
STAMP = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
BACKUP_DIR = ROOT / "backups" / f"v6_hotfix_{STAMP}"

MAIN_FILE = ROOT / "brain_v11_1_aipro.py"
DASH_FILE = ROOT / "dashboard.py"
BT_FILE = ROOT / "bt_analyze.py"
ENV_FILE = ROOT / ".demo.env"


def log(msg: str) -> None:
    print(f"[V6] {msg}", flush=True)


def backup(path: Path) -> None:
    if not path.exists():
        return
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    rel = path.relative_to(ROOT) if path.is_relative_to(ROOT) else Path(path.name)
    dst = BACKUP_DIR / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dst)
    log(f"backup: {path} -> {dst}")


def write_text(path: Path, text: str, mode: int | None = None) -> None:
    backup(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    if mode is not None:
        path.chmod(mode)
    log(f"write: {path}")


def upsert_env(path: Path, kv: Dict[str, str]) -> None:
    backup(path)
    lines: List[str] = []
    if path.exists():
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    seen = set()
    out: List[str] = []
    for line in lines:
        m = re.match(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=", line)
        if m and m.group(1) in kv:
            key = m.group(1)
            out.append(f"export {key}={kv[key]}")
            seen.add(key)
        else:
            out.append(line)
    if out and out[-1].strip():
        out.append("")
    out.append("# >>> V6 hotfix env: api timeout / dashboard / offline backtest")
    for k, v in kv.items():
        if k not in seen:
            out.append(f"export {k}={v}")
    out.append("# <<< V6 hotfix env")
    path.write_text("\n".join(out) + "\n", encoding="utf-8")
    log(f"env upsert: {len(kv)} keys")


def find_insertion_after_future_imports(src: str) -> int:
    """Return character index after shebang/encoding/docstring/from __future__ imports."""
    lines = src.splitlines(True)
    i = 0
    if i < len(lines) and lines[i].startswith("#!"):
        i += 1
    if i < len(lines) and "coding" in lines[i]:
        i += 1
    # module docstring
    if i < len(lines) and re.match(r"\s*([rubfRUBF]*)(['\"]{3})", lines[i]):
        quote = re.match(r"\s*([rubfRUBF]*)(['\"]{3})", lines[i]).group(2)
        i += 1
        while i < len(lines):
            if quote in lines[i]:
                i += 1
                break
            i += 1
    # blank lines and future imports
    changed = True
    while changed:
        changed = False
        while i < len(lines) and not lines[i].strip():
            i += 1
            changed = True
        while i < len(lines) and lines[i].lstrip().startswith("from __future__ import"):
            i += 1
            changed = True
    return sum(len(x) for x in lines[:i])


V6_API_GUARD_SNIPPET = r'''

# >>> V6_API_TIMEOUT_GUARD
# Brain V11 V6: 给 requests / Binance SDK 底层请求加硬超时，避免 demo-fapi 卡死、CLOSE-WAIT 堆积。
def _brain_v11_v6_install_api_timeout_guard():
    import os as _os, time as _time, json as _json, socket as _socket
    from pathlib import Path as _Path

    if _os.environ.get("BRAIN_V11_V6_API_GUARD_INSTALLED") == "1":
        return
    _os.environ["BRAIN_V11_V6_API_GUARD_INSTALLED"] = "1"

    def _float_env(name, default):
        try:
            return float(_os.environ.get(name, default))
        except Exception:
            return float(default)

    _connect_timeout = _float_env("BINANCE_API_CONNECT_TIMEOUT_SEC", 4)
    _read_timeout = _float_env("BINANCE_API_READ_TIMEOUT_SEC", 8)
    _default_timeout = (_connect_timeout, _read_timeout)
    _disable_keepalive = _os.environ.get("REQUESTS_DISABLE_KEEPALIVE", "1") not in ("0", "false", "False", "no", "NO")
    _data_dir = _Path(_os.environ.get("BRAIN_DATA_DIR", "brain_demo_data"))
    _api_log = _data_dir / "api_events_v6.log"

    def _write_api_event(event, **kw):
        try:
            _data_dir.mkdir(parents=True, exist_ok=True)
            rec = {"ts": _time.time(), "event": event}
            rec.update(kw)
            with _api_log.open("a", encoding="utf-8") as f:
                f.write(_json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass

    try:
        _socket.setdefaulttimeout(max(_connect_timeout + _read_timeout, 10))
    except Exception:
        pass

    try:
        import requests as _requests
        if getattr(_requests.sessions.Session.request, "_brain_v11_v6_wrapped", False):
            return
        _orig_request = _requests.sessions.Session.request

        def _v6_request(self, method, url, **kwargs):
            kwargs.setdefault("timeout", _default_timeout)
            if _disable_keepalive:
                headers = kwargs.setdefault("headers", {})
                try:
                    headers.setdefault("Connection", "close")
                except Exception:
                    kwargs["headers"] = {"Connection": "close"}
            t0 = _time.time()
            try:
                resp = _orig_request(self, method, url, **kwargs)
                elapsed = _time.time() - t0
                if elapsed > max(_read_timeout, 5):
                    _write_api_event("slow_request", method=str(method), url=str(url)[:180], elapsed=round(elapsed, 3), status=getattr(resp, "status_code", None))
                return resp
            except Exception as e:
                elapsed = _time.time() - t0
                _write_api_event("request_error", method=str(method), url=str(url)[:180], elapsed=round(elapsed, 3), error=repr(e))
                raise

        _v6_request._brain_v11_v6_wrapped = True
        _requests.sessions.Session.request = _v6_request
        _write_api_event("api_timeout_guard_installed", timeout=list(_default_timeout), keepalive_disabled=_disable_keepalive)
    except Exception as e:
        _write_api_event("api_timeout_guard_install_failed", error=repr(e))

try:
    _brain_v11_v6_install_api_timeout_guard()
except Exception:
    pass
# <<< V6_API_TIMEOUT_GUARD

'''


def patch_main_api_guard() -> None:
    if not MAIN_FILE.exists():
        log(f"skip api guard: {MAIN_FILE} not found")
        return
    src = MAIN_FILE.read_text(encoding="utf-8", errors="ignore")
    if "V6_API_TIMEOUT_GUARD" in src:
        log("api guard already installed")
        return
    backup(MAIN_FILE)
    idx = find_insertion_after_future_imports(src)
    new_src = src[:idx] + V6_API_GUARD_SNIPPET + src[idx:]
    MAIN_FILE.write_text(new_src, encoding="utf-8")
    log("patched brain_v11_1_aipro.py: V6 api timeout guard")


V6_DASHBOARD_SNIPPET = r'''

<!-- >>> V6_DASHBOARD_COLLAPSE_SCRIPT -->
<style>
.v6-hidden-row { display: none !important; }
.v6-toggle-btn { margin: 10px 0; padding: 6px 12px; border-radius: 10px; border: 1px solid rgba(255,255,255,.18); background: rgba(255,255,255,.08); color: inherit; cursor: pointer; }
.v6-short-time { white-space: nowrap; }
</style>
<script>
(function(){
  function shortTimeText(t){
    if(!t) return t;
    var s = String(t).trim();
    var m = s.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
    if(m){
      var d = new Date(s);
      if(!isNaN(d.getTime())){
        var mm = String(d.getMonth()+1).padStart(2,'0');
        var dd = String(d.getDate()).padStart(2,'0');
        var hh = String(d.getHours()).padStart(2,'0');
        var mi = String(d.getMinutes()).padStart(2,'0');
        return mm + '-' + dd + ' ' + hh + ':' + mi;
      }
      return m[2] + '-' + m[3] + ' ' + m[4] + ':' + m[5];
    }
    return s;
  }
  function normalizeTimes(root){
    var cells = root.querySelectorAll('td, th, .time, .timestamp');
    cells.forEach(function(c){
      var txt = (c.textContent || '').trim();
      if(/^\d{4}-\d{2}-\d{2}T/.test(txt)){
        c.textContent = shortTimeText(txt);
        c.classList.add('v6-short-time');
      }
    });
  }
  function findCards(){
    var titles = Array.from(document.querySelectorAll('h1,h2,h3,h4,.section-title,.card-title,.title'));
    return titles.filter(function(el){ return /最近成交|持仓历史|平仓盈亏/.test(el.textContent || ''); })
      .map(function(el){ return el.closest('.card,section,.panel,.box') || el.parentElement; })
      .filter(Boolean);
  }
  function collapseCard(card){
    if(card.getAttribute('data-v6-collapsed')) return;
    card.setAttribute('data-v6-collapsed','1');
    normalizeTimes(card);
    var rows = Array.from(card.querySelectorAll('tbody tr'));
    if(rows.length === 0) rows = Array.from(card.querySelectorAll('.row, li'));
    if(rows.length <= 5) return;
    rows.forEach(function(r, i){ if(i >= 5) r.classList.add('v6-hidden-row'); });
    var btn = document.createElement('button');
    btn.className = 'v6-toggle-btn';
    btn.textContent = '展开全部 ' + rows.length + ' 条';
    var expanded = false;
    btn.onclick = function(){
      expanded = !expanded;
      rows.forEach(function(r, i){ if(i >= 5) r.classList.toggle('v6-hidden-row', !expanded); });
      btn.textContent = expanded ? '收起' : ('展开全部 ' + rows.length + ' 条');
    };
    card.appendChild(btn);
  }
  document.addEventListener('DOMContentLoaded', function(){
    normalizeTimes(document);
    findCards().forEach(collapseCard);
  });
})();
</script>
<!-- <<< V6_DASHBOARD_COLLAPSE_SCRIPT -->
'''


def patch_dashboard_collapse() -> None:
    if not DASH_FILE.exists():
        log(f"skip dashboard: {DASH_FILE} not found")
        return
    src = DASH_FILE.read_text(encoding="utf-8", errors="ignore")
    if "V6_DASHBOARD_COLLAPSE_SCRIPT" in src:
        log("dashboard collapse script already installed")
        return
    backup(DASH_FILE)
    # Insert before the first literal </body> if dashboard renders HTML from a template/string.
    if "</body>" in src:
        src2 = src.replace("</body>", V6_DASHBOARD_SNIPPET + "\n</body>", 1)
        DASH_FILE.write_text(src2, encoding="utf-8")
        log("patched dashboard.py: inserted collapse/time script before </body>")
        return
    # Fallback: append a helper constant that can be manually used by dashboard templates.
    addition = "\n\n# >>> V6_DASHBOARD_COLLAPSE_SNIPPET_CONST\nV6_DASHBOARD_COLLAPSE_SNIPPET = " + repr(V6_DASHBOARD_SNIPPET) + "\n# <<< V6_DASHBOARD_COLLAPSE_SNIPPET_CONST\n"
    DASH_FILE.write_text(src + addition, encoding="utf-8")
    log("dashboard.py has no literal </body>; appended V6_DASHBOARD_COLLAPSE_SNIPPET constant")


def num(x: Any, default: float = 0.0) -> float:
    try:
        if x is None or x == "":
            return default
        return float(x)
    except Exception:
        return default


def get_any(d: Dict[str, Any], keys: Iterable[str], default: Any = None) -> Any:
    for k in keys:
        if isinstance(d, dict) and k in d and d[k] not in (None, ""):
            return d[k]
    return default


def dedupe_trade_history() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    trade_p = DATA_DIR / "exchange_trade_history.json"
    income_p = DATA_DIR / "exchange_income_history.json"
    if not trade_p.exists() and not income_p.exists():
        log("skip history dedupe: no exchange history files yet")
        return

    for p in [trade_p, income_p]:
        if p.exists():
            backup(p)

    def load_list(p: Path) -> List[Dict[str, Any]]:
        if not p.exists():
            return []
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return [x for x in data if isinstance(x, dict)]
            if isinstance(data, dict):
                for k in ("items", "data", "trades", "income", "rows"):
                    if isinstance(data.get(k), list):
                        return [x for x in data[k] if isinstance(x, dict)]
        except Exception as e:
            log(f"read history failed {p}: {e}")
        return []

    trades = load_list(trade_p)
    incomes = load_list(income_p)

    # 1) Deduplicate raw trades by strongest available key.
    seen = set()
    dedup_trades: List[Dict[str, Any]] = []
    for r in sorted(trades, key=lambda x: str(get_any(x, ["time", "ts", "timestamp", "T"], ""))):
        symbol = str(get_any(r, ["symbol", "s"], ""))
        order_id = str(get_any(r, ["orderId", "order_id", "orderID"], ""))
        trade_id = str(get_any(r, ["id", "tradeId", "trade_id"], ""))
        event = str(get_any(r, ["event", "type", "incomeType"], ""))
        t = str(get_any(r, ["time", "ts", "timestamp", "T"], ""))
        key = (symbol, order_id, trade_id, event, t)
        if key in seen:
            continue
        seen.add(key)
        dedup_trades.append(r)

    # 2) Build closed pnl summary from REALIZED_PNL income only; this is the authoritative realized-PnL source.
    seen_income = set()
    closed: List[Dict[str, Any]] = []
    for r in sorted(incomes, key=lambda x: str(get_any(x, ["time", "ts", "timestamp", "T"], ""))):
        income_type = str(get_any(r, ["incomeType", "type", "event"], ""))
        if income_type and income_type.upper() != "REALIZED_PNL":
            continue
        symbol = str(get_any(r, ["symbol", "asset", "s"], ""))
        order_id = str(get_any(r, ["orderId", "order_id", "orderID"], ""))
        tran_id = str(get_any(r, ["tranId", "tran_id", "id", "incomeId"], ""))
        t = str(get_any(r, ["time", "ts", "timestamp", "T"], ""))
        pnl = num(get_any(r, ["income", "realizedPnl", "realized_pnl", "pnl"], 0.0))
        key = (symbol, order_id, tran_id, t, round(pnl, 12))
        if key in seen_income:
            continue
        seen_income.add(key)
        row = dict(r)
        row["event"] = "EXCHANGE_CLOSE"
        row["realized_pnl"] = pnl
        row["source"] = "income_REALIZED_PNL_v6"
        closed.append(row)

    # 3) Write files. Keep raw backups in backups/; overwrite trade history with de-duped raw events.
    if trade_p.exists():
        trade_p.write_text(json.dumps(dedup_trades, ensure_ascii=False, indent=2), encoding="utf-8")
    (DATA_DIR / "exchange_trade_history_deduped_v6.json").write_text(json.dumps(dedup_trades, ensure_ascii=False, indent=2), encoding="utf-8")
    (DATA_DIR / "exchange_closed_pnl_v6.json").write_text(json.dumps(closed, ensure_ascii=False, indent=2), encoding="utf-8")
    total = sum(num(get_any(r, ["realized_pnl", "income"], 0.0)) for r in closed)
    summary = {
        "ts": time.time(),
        "trades_raw": len(trades),
        "trades_deduped": len(dedup_trades),
        "income_raw": len(incomes),
        "closed_pnl_rows": len(closed),
        "closed_pnl_total": total,
        "note": "V6: closed pnl total uses exchange_income_history REALIZED_PNL only; userTrades are display only.",
    }
    (DATA_DIR / "exchange_trade_history_state.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"history dedupe done: trades {len(trades)} -> {len(dedup_trades)}, closed_pnl={len(closed)}, total={total:.8f}")


def create_watchdog() -> None:
    watchdog = ROOT / "brain_v11_v6_api_watchdog.py"
    content = r'''#!/usr/bin/env python3
# Brain V11 V6 watchdog: only reports/kills stale process when explicitly run with --kill-stale.
import os, sys, time, subprocess, signal
from pathlib import Path
ROOT = Path(__file__).resolve().parent
LOG = ROOT / 'brain_demo_data' / 'brain_v11.log'
STALE_SEC = int(os.environ.get('V6_LOG_STALE_SEC','600'))
kill = '--kill-stale' in sys.argv
age = None
if LOG.exists():
    age = time.time() - LOG.stat().st_mtime
print({'log_exists': LOG.exists(), 'log_age_sec': round(age,1) if age is not None else None, 'kill_stale': kill})
if age is not None and age > STALE_SEC:
    ps = subprocess.run("ps -eo pid,stat,etime,cmd | grep -E 'brain_v11_1_aipro.py|start_demo' | grep -v grep", shell=True, text=True, capture_output=True)
    print(ps.stdout)
    if kill:
        for line in ps.stdout.splitlines():
            parts=line.strip().split(None,3)
            if parts and parts[0].isdigit():
                pid=int(parts[0])
                try:
                    os.kill(pid, signal.SIGTERM)
                    print('SIGTERM', pid)
                except Exception as e:
                    print('kill_failed', pid, e)
'''
    write_text(watchdog, content, 0o755)


def create_backtest_scripts() -> None:
    smoke = ROOT / "run_bt_v6_smoke.sh"
    smoke_content = r'''#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"
source .demo.env 2>/dev/null || true
export TRADING_MODE=paper
export BACKTEST_OFFLINE_ONLY=1
export NO_API_FALLBACK=1
export BACKTEST_START=${BACKTEST_START:-2025-01-01}
export BACKTEST_END=${BACKTEST_END:-2025-02-01}
export BACKTEST_LIMIT=${BACKTEST_LIMIT:-20000}
export BACKTEST_SYMBOLS=${BACKTEST_SYMBOLS:-BTCUSDT,ETHUSDT,BNBUSDT}
export V6_BT_MODE=smoke
mkdir -p backtest_v6_smoke
LOG=backtest_v6_smoke/run_$(date -u +%Y%m%d_%H%M%S).log
echo "V6 smoke backtest started: $BACKTEST_SYMBOLS $BACKTEST_START -> $BACKTEST_END" | tee "$LOG"
# Try common entrypoints without assuming exact CLI.
(timeout 900 python3 bt_analyze.py --symbols "$BACKTEST_SYMBOLS" --start "$BACKTEST_START" --end "$BACKTEST_END" --limit "$BACKTEST_LIMIT" 2>&1 || \
 timeout 900 python3 brain_v11_1_aipro.py --backtest --symbols "$BACKTEST_SYMBOLS" --start "$BACKTEST_START" --end "$BACKTEST_END" --limit "$BACKTEST_LIMIT" 2>&1 || \
 timeout 900 python3 bt_analyze.py 2>&1) | tee -a "$LOG"
echo "V6 smoke backtest finished. log=$LOG" | tee -a "$LOG"
'''
    diag = ROOT / "run_bt_v6_diag.sh"
    diag_content = r'''#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"
source .demo.env 2>/dev/null || true
mkdir -p backtest_v6_diag
BASE_LOG=backtest_v6_diag/diag_$(date -u +%Y%m%d_%H%M%S)
export TRADING_MODE=paper
export BACKTEST_OFFLINE_ONLY=1
export NO_API_FALLBACK=1
export BACKTEST_START=${BACKTEST_START:-2025-01-01}
export BACKTEST_END=${BACKTEST_END:-2025-02-01}
export BACKTEST_LIMIT=${BACKTEST_LIMIT:-20000}
export BACKTEST_SYMBOLS=${BACKTEST_SYMBOLS:-BTCUSDT,ETHUSDT,BNBUSDT}
run_case(){
  name="$1"; shift
  echo "=== V6 DIAG $name ===" | tee -a "${BASE_LOG}_summary.log"
  (export "$@"; timeout 900 python3 bt_analyze.py 2>&1 || timeout 900 python3 brain_v11_1_aipro.py --backtest 2>&1) | tee "${BASE_LOG}_${name}.log"
}
run_case A_CURRENT V6_BT_CASE=A
run_case B_NO_CONFIRM V6_BT_CASE=B ENABLE_CONFIRM_V2=0
run_case C_LOW_ATR V6_BT_CASE=C MIN_ATR_PCT=0.03
run_case D_ALL_SETUP V6_BT_CASE=D SETUP_WHITELIST=pullback,trend,breakout ENABLE_TREND_SETUP=1
run_case E_LOOSE V6_BT_CASE=E ENABLE_CONFIRM_V2=0 MIN_ATR_PCT=0.03 SCORE_THRESHOLD=50 SETUP_WHITELIST=pullback,trend,breakout ENABLE_TREND_SETUP=1
python3 bt_filter_diagnostic_summary.py backtest_v6_diag 2>/dev/null | tee -a "${BASE_LOG}_summary.log" || true
echo "V6 diag finished. summary=${BASE_LOG}_summary.log"
'''
    write_text(smoke, smoke_content, 0o755)
    write_text(diag, diag_content, 0o755)

    summary_py = ROOT / "bt_filter_diagnostic_summary.py"
    if not summary_py.exists():
        summary_content = r'''#!/usr/bin/env python3
import os, re, sys, json
from pathlib import Path
root = Path(sys.argv[1]) if len(sys.argv)>1 else Path('backtest_v6_diag')
rows=[]
for p in sorted(root.glob('*.log')):
    txt=p.read_text(errors='ignore')
    row={'file':str(p)}
    for key in ['raw_market_bars','raw_setups_total','after_setup_whitelist','after_trend_disabled','after_min_atr','after_score_threshold','after_confirm_v2','after_cost_filter','after_rr_filter','final_trades','trades']:
        m=re.search(rf'{key}\D+(\d+)', txt, re.I)
        if m: row[key]=int(m.group(1))
    rows.append(row)
print(json.dumps(rows, ensure_ascii=False, indent=2))
'''
        write_text(summary_py, summary_content, 0o755)


def patch_start_demo_env() -> None:
    p = ROOT / "start_demo.sh"
    if not p.exists():
        return
    src = p.read_text(encoding="utf-8", errors="ignore")
    if "V6 api timeout env" in src:
        log("start_demo.sh already has V6 env")
        return
    backup(p)
    insert = """
# >>> V6 api timeout env
export PYTHONUNBUFFERED=1
export BINANCE_API_CONNECT_TIMEOUT_SEC=${BINANCE_API_CONNECT_TIMEOUT_SEC:-4}
export BINANCE_API_READ_TIMEOUT_SEC=${BINANCE_API_READ_TIMEOUT_SEC:-8}
export REQUESTS_DISABLE_KEEPALIVE=${REQUESTS_DISABLE_KEEPALIVE:-1}
export BRAIN_DATA_DIR=${BRAIN_DATA_DIR:-brain_demo_data}
# <<< V6 api timeout env
"""
    lines = src.splitlines(True)
    idx = 1 if lines and lines[0].startswith("#!") else 0
    src2 = "".join(lines[:idx]) + insert + "".join(lines[idx:])
    p.write_text(src2, encoding="utf-8")
    log("patched start_demo.sh: V6 timeout env")


def py_compile(paths: Iterable[Path]) -> bool:
    ok = True
    for p in paths:
        if not p.exists():
            continue
        res = subprocess.run([sys.executable, "-m", "py_compile", str(p)], cwd=str(ROOT), text=True, capture_output=True)
        if res.returncode == 0:
            log(f"py_compile PASS: {p.name}")
        else:
            ok = False
            log(f"py_compile FAIL: {p.name}\n{res.stderr}")
    return ok


def main() -> int:
    log(f"root={ROOT}")
    log(f"backup_dir={BACKUP_DIR}")

    env = {
        "BINANCE_API_CONNECT_TIMEOUT_SEC": "4",
        "BINANCE_API_READ_TIMEOUT_SEC": "8",
        "BINANCE_API_TIMEOUT_SEC": "8",
        "REQUESTS_DISABLE_KEEPALIVE": "1",
        "DEMO_FAPI_MAX_BOOT_SECONDS": "45",
        "API_STALE_OK": "1",
        "DASHBOARD_COLLAPSE_LONG_TABLES": "1",
        "TRADE_HISTORY_DEDUP_V6": "1",
        "TRADE_HISTORY_COLLAPSE_DEFAULT": "5",
        "BACKTEST_OFFLINE_ONLY": "1",
        "NO_API_FALLBACK": "1",
        "BACKTEST_END": "2026-03-31",
    }
    upsert_env(ENV_FILE, env)
    patch_main_api_guard()
    patch_dashboard_collapse()
    patch_start_demo_env()
    dedupe_trade_history()
    create_watchdog()
    create_backtest_scripts()

    ok = py_compile([MAIN_FILE, DASH_FILE, BT_FILE, ROOT / "brain_v11_v6_api_watchdog.py", ROOT / "bt_filter_diagnostic_summary.py"])

    log("done")
    log("next: restart brain_demo and brain_ui, then check brain_demo_data/api_events_v6.log and dashboard")
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
