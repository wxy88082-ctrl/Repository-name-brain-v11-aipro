# V7 Backtest Fix Patch Notes

## 已完成修复

### Bug 1: SETUP_WHITELIST 大小写不匹配 (brain_v11_1_aipro.py 第6960行)
**症状**: after_setup_whitelist 永远为 0，所有 pullback 信号被 SETUP_NOT_ALLOWED 拦截
**根因**: parse_csv_symbols() 调用 .upper() → {'PULLBACK'}，但 setup 值是小写 'pullback'
**修复**: 
  - 改前: allowed_setups = set(parse_csv_symbols(env_str("SETUP_WHITELIST", ...)))
  - 改后: allowed_setups = {s.lower() for s in parse_csv_symbols(env_str("SETUP_WHITELIST", ...))}
**验证**: after_setup_whitelist 从 0 → 534 ✅

### V7 Schema 新增字段 (bt_analyze.py)
- exit_reason, mfe_r, mae_r, entry_time_ms, exit_time_ms
- bt_analyze.py 升级为 V7 可信回测分析器
- run_bt_v7_smoke.sh / run_bt_v7_diag.sh 新增

## 待审查问题

### final_trades=0 原因分析
过滤链路在 setup_whitelist 之后的统计如下（BTCUSDT 2023-10 ~ 2024-01）:
- after_setup_whitelist: 511 (pullback 信号通过白名单)
- after_score_threshold: 0 (全被拦截)
  - 拦截原因: NO_TRADE_BLOCKERS=319, COST_FILTER=185, SCORE_TOO_LOW=6
  - 注意: NO_TRADE_BLOCKERS / COST_FILTER 实际上在 direction 检查（NOT score 检查）中被拦截
  - 这些信号在 analyze_symbol_from_candles 内部已经返回 direction=NO_TRADE
  - 主要原因: RR不足、止损距离无效、成本占R过高

### 可能的深层问题（待 Codex 审查）
1. 回测诊断中 score 检查在 direction 检查之前，导致统计误导性
2. StrategyEngineV10 的 RR 计算是否存在过于严格或逻辑错误
3. COST_FILTER 触发频率是否合理（185/511 = 36%）
4. backtest_trades.csv 里有没有 entry_time_ms 字段生成逻辑
