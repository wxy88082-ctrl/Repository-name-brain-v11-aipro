#!/usr/bin/env python3
"""
诊断引擎 v3 — 全周期回测（2023-01 ~ 2026-04）
- 禁用 breakout（只保留 pullback）
- TP1 修复：达到1R平30%，剩余移止损到保本
- 同一根K线SL优先（保守原则）
- 延迟入场v2：K[N+1].close确认，K[N+2].open入场（无未来函数）
- 纯只读分析，不修改任何运行参数
"""
import csv, json, zipfile, statistics, datetime, re, os
from collections import defaultdict
from pathlib import Path

KLINE_DIR  = Path('/root/brain/binance_history/futures/um/monthly/klines')
TRADES_CSV = Path('/root/brain/brain_demo_data/backtest_trades.csv')
OUT_DIR    = Path('/root/brain/diagnostic_v3_output')
OUT_DIR.mkdir(exist_ok=True)

SYMBOLS    = ["BTCUSDT","ETHUSDT","SOLUSDT","BNBUSDT","XRPUSDT",
              "DOGEUSDT","ADAUSDT","AVAXUSDT","LINKUSDT","NEARUSDT"]
INTERVALS  = ["15m","1h","4h"]

# ── 工具 ──────────────────────────────────────────────────────────────────────
def sf(v, d=0.0):
    try: return float(v)
    except: return d

def parse_dt(s):
    try: return datetime.datetime.fromisoformat(
        str(s).strip().replace('Z','+00:00')).replace(tzinfo=None)
    except: return None

def stats_from_trades(tlist):
    if not tlist:
        return dict(trades=0,win_rate=0,expectancy_R=0,total_R=0,profit_factor=0,
                    avg_win_R=0,avg_loss_R=0,max_drawdown_R=0,max_loss_streak=0,
                    tp1_count=0,tp2_count=0,stop_count=0,be_count=0)
    r_vals=[t['r_total'] for t in tlist]
    wins=[v for v in r_vals if v>0]; losses=[v for v in r_vals if v<=0]
    total_R=sum(r_vals); exp_R=total_R/len(r_vals); wr=len(wins)/len(r_vals)
    pf=abs(sum(wins)/sum(losses)) if losses and sum(losses)!=0 else (999.0 if wins else 0.0)
    cum=0;peak=0;max_dd=0
    for v in r_vals: cum+=v; peak=max(peak,cum); max_dd=max(max_dd,peak-cum)
    streak=0;max_s=0
    for v in r_vals:
        streak=(streak+1) if v<=0 else 0; max_s=max(max_s,streak)
    return dict(trades=len(r_vals),win_rate=round(wr,4),
                expectancy_R=round(exp_R,4),total_R=round(total_R,4),
                profit_factor=round(pf,4),
                avg_win_R=round(statistics.mean(wins),4) if wins else 0,
                avg_loss_R=round(statistics.mean(losses),4) if losses else 0,
                max_drawdown_R=round(max_dd,4),max_loss_streak=max_s,
                tp1_count=sum(1 for t in tlist if t.get('tp1_hit')),
                tp2_count=sum(1 for t in tlist if t.get('tp2_hit')),
                stop_count=sum(1 for t in tlist if t.get('stop_hit')),
                be_count=sum(1 for t in tlist if t.get('be_hit')))

def wcsv(name, fields, data):
    p=OUT_DIR/name
    with open(p,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore')
        w.writeheader(); w.writerows(data)
    print(f"  ✓ {name} ({len(data)}行)")

# ── 读取原始回测交易（只保留 pullback）─────────────────────────────────────────
print("读取原始回测交易...")
raw_rows=[]
with open(TRADES_CSV, newline='', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        setup=r.get('setup','')
        if setup != 'pullback': continue   # 禁用 breakout
        entry_dt=parse_dt(r.get('entry_time',''))
        if not entry_dt: continue
        raw_rows.append(dict(
            symbol=r.get('symbol',''), direction=r.get('direction',''),
            setup=setup, entry_dt=entry_dt,
            entry=sf(r.get('entry')), exit_p=sf(r.get('exit')),
            stop_loss=sf(r.get('stop_loss')), tp1=sf(r.get('tp1')),
            tp2=sf(r.get('tp2')), orig_r=sf(r.get('r_multiple')),
            bars=int(sf(r.get('bars'),1)), score=sf(r.get('score')),
            reason=r.get('reason',''),
        ))
print(f"  pullback交易: {len(raw_rows)}笔")

# strict rows
strict_rows=[r for r in raw_rows if r['score']>=86
             and '波动分位极端' not in r['reason']
             and '插针' not in r['reason']
             and '资金费率过热' not in r['reason']
             and 'ATR% 过低' not in r['reason']]
print(f"  严格过滤后: {len(strict_rows)}笔")

# ── K线缓存 ───────────────────────────────────────────────────────────────────
print("加载K线数据...")
kline_cache={}

def load_klines(symbol, interval='15m'):
    key=f"{symbol}_{interval}"
    if key in kline_cache: return kline_cache[key]
    candles=[]
    sym_dir=KLINE_DIR/symbol/interval
    if not sym_dir.exists(): kline_cache[key]=[]; return []
    for zf_path in sorted(sym_dir.glob('*.zip')):
        try:
            with zipfile.ZipFile(zf_path) as zf:
                for name in zf.namelist():
                    if not name.endswith('.csv'): continue
                    with zf.open(name) as cf:
                        for line in cf.read().decode('utf-8','ignore').splitlines():
                            p=line.split(',')
                            if len(p)<6: continue
                            try:
                                ts=int(float(p[0]))
                                if ts<1e12: continue
                                candles.append(dict(ts=ts,
                                    open=float(p[1]),high=float(p[2]),
                                    low=float(p[3]),close=float(p[4]),
                                    vol=float(p[5])))
                            except: pass
        except: pass
    seen={}
    for c in candles: seen[c['ts']]=c
    candles=sorted(seen.values(),key=lambda x:x['ts'])
    kline_cache[key]=candles
    print(f"    {symbol}/{interval}: {len(candles)}根 "
          f"({datetime.datetime.utcfromtimestamp(candles[0]['ts']//1000).strftime('%Y-%m') if candles else 'empty'}"
          f" ~ "
          f"{datetime.datetime.utcfromtimestamp(candles[-1]['ts']//1000).strftime('%Y-%m') if candles else 'empty'})")
    return candles

for sym in SYMBOLS:
    load_klines(sym,'15m')

# ── 核心模拟函数 ───────────────────────────────────────────────────────────────
TP1_FRAC=0.30; TP2_FRAC=0.70

def simulate_trade(r, entry_price, stop_price, candles_after):
    entry=entry_price; sl=stop_price
    tp1_p=r['tp1']; tp2_p=r['tp2']
    direction=r['direction']
    stop_dist=abs(entry-sl)
    if stop_dist<1e-12: return None
    if direction=='LONG':
        if tp1_p<=entry: tp1_p=entry+stop_dist
        if tp2_p<=tp1_p: tp2_p=entry+stop_dist*2
    else:
        if tp1_p>=entry: tp1_p=entry-stop_dist
        if tp2_p>=tp1_p: tp2_p=entry-stop_dist*2

    tp1_hit=False; tp2_hit=False; stop_hit=False; be_hit=False
    be_sl=None; r_tp1=0.0; r_tp2=0.0; r_total=None

    for i,c in enumerate(candles_after):
        hi=c['high']; lo=c['low']
        if direction=='LONG':
            sl_trig = lo<=sl; tp1_trig = hi>=tp1_p and not tp1_hit
            be_trig  = (be_sl is not None) and lo<=be_sl
            tp2_trig = hi>=tp2_p and tp1_hit
        else:
            sl_trig = hi>=sl; tp1_trig = lo<=tp1_p and not tp1_hit
            be_trig  = (be_sl is not None) and hi>=be_sl
            tp2_trig = lo<=tp2_p and tp1_hit

        if not tp1_hit:
            if sl_trig:                   # SL优先
                stop_hit=True; r_total=-1.0; break
            if tp1_trig:
                tp1_hit=True; r_tp1=TP1_FRAC*1.0; be_sl=entry
        else:
            if be_trig:
                be_hit=True; r_total=r_tp1+0.0; break
            if tp2_trig:
                tp2_hit=True; r_total=r_tp1+TP2_FRAC*2.0; break

    if r_total is None:
        lc=candles_after[-1]
        ep=lc['close']
        ep_r=((ep-entry)/stop_dist) if direction=='LONG' else ((entry-ep)/stop_dist)
        if tp1_hit:
            r_total=r_tp1+ep_r*TP2_FRAC
        else:
            r_total=ep_r
        if r_total<0: stop_hit=True

    return dict(r_total=round(r_total,4),
                tp1_hit=tp1_hit,tp2_hit=tp2_hit,stop_hit=stop_hit,be_hit=be_hit)

def get_klines_from(symbol, entry_dt, n=80):
    klines=load_klines(symbol,'15m')
    if not klines: return []
    entry_ms=int(entry_dt.timestamp()*1000)
    idx=None
    for i,c in enumerate(klines):
        if c['ts']>=entry_ms: idx=i; break
    if idx is None: return []
    return klines[idx:idx+n]

# ── 场景运行器 ────────────────────────────────────────────────────────────────
def run_scenario(label, trade_rows, delay_bars=0, require_confirm_v2=False, stop_mult=1.0):
    results=[]; skipped=0
    for r in trade_rows:
        klns=get_klines_from(r['symbol'],r['entry_dt'],80)
        if len(klns)<delay_bars+3: skipped+=1; continue

        entry_bar_idx=delay_bars
        if require_confirm_v2:
            if len(klns)<3: skipped+=1; continue
            cc=klns[1]
            if r['direction']=='LONG' and cc['close']<=cc['open']: skipped+=1; continue
            if r['direction']=='SHORT' and cc['close']>=cc['open']: skipped+=1; continue
            entry_bar_idx=2

        new_entry=klns[entry_bar_idx]['open']
        orig_dist=abs(r['entry']-r['stop_loss'])
        new_dist=orig_dist*stop_mult
        if new_dist<1e-12: skipped+=1; continue

        new_sl=(new_entry-new_dist) if r['direction']=='LONG' else (new_entry+new_dist)
        new_tp1=(new_entry+new_dist) if r['direction']=='LONG' else (new_entry-new_dist)
        new_tp2=(new_entry+new_dist*2) if r['direction']=='LONG' else (new_entry-new_dist*2)
        r2={**r,'entry':new_entry,'stop_loss':new_sl,'tp1':new_tp1,'tp2':new_tp2}

        res=simulate_trade(r2,new_entry,new_sl,klns[entry_bar_idx:])
        if res is None: skipped+=1; continue

        res.update(symbol=r['symbol'],direction=r['direction'],setup=r['setup'],
                   score=r['score'],entry_dt=r['entry_dt'],scenario=label)
        results.append(res)

    s=stats_from_trades(results)
    print(f"  {label:<45}: n={s['trades']:4d}  exp={s['expectancy_R']:+.4f}R  "
          f"pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}  "
          f"tp1={s['tp1_count']} tp2={s['tp2_count']} stop={s['stop_count']} be={s['be_count']}"
          f"  (skip={skipped})")
    return results, s

# ══════════════════════════════════════════════════════════════════════════════
# 主回测（pullback-only，TP1修复，无未来函数）
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "="*70)
print("主回测：pullback-only，TP1修复，SL优先")
print("="*70)

res_A, sA = run_scenario("A_原始入场",         raw_rows)
res_B, sB = run_scenario("B_延迟1根K",         raw_rows, delay_bars=1)
res_D, sD = run_scenario("D_延迟1根+确认v2",   raw_rows, delay_bars=1, require_confirm_v2=True)
res_F, sF = run_scenario("F_严格pullback",      strict_rows)
res_DF,sDF= run_scenario("D+F_最优组合",        strict_rows, delay_bars=1, require_confirm_v2=True)

scenarios={'A_原始入场':sA,'B_延迟1根K':sB,'D_延迟1根+确认v2':sD,
           'F_严格pullback':sF,'D+F_最优组合':sDF}

# ── 汇总CSV
summary_fields=['scenario','trades','win_rate','expectancy_R','total_R','profit_factor',
                'avg_win_R','avg_loss_R','max_drawdown_R','max_loss_streak',
                'tp1_count','tp2_count','stop_count','be_count']
wcsv('overall_summary.csv', summary_fields,
     [{'scenario':k,**v} for k,v in scenarios.items()])

# ── 逐笔交易（D+F场景）
trade_fields=['scenario','symbol','direction','setup','score',
              'r_total','tp1_hit','tp2_hit','stop_hit','be_hit']
all_trades=[]
for res,lbl in [(res_A,'A'),(res_B,'B'),(res_D,'D'),(res_F,'F'),(res_DF,'D+F')]:
    for t in res:
        all_trades.append({**t,
            'scenario':lbl,
            'entry_dt':t['entry_dt'].strftime('%Y-%m-%d %H:%M') if isinstance(t['entry_dt'],datetime.datetime) else str(t['entry_dt'])
        })
wcsv('trades_all_scenarios.csv',
     ['scenario','symbol','direction','setup','score','entry_dt','r_total',
      'tp1_hit','tp2_hit','stop_hit','be_hit'], all_trades)

# ── 按年份统计（D+F场景）
print("\n=== 按年份统计（D+F最优组合）===")
by_year=defaultdict(list)
for t in res_DF:
    if isinstance(t['entry_dt'],datetime.datetime):
        by_year[t['entry_dt'].year].append(t)
year_rows=[]
for yr in sorted(by_year.keys()):
    s=stats_from_trades(by_year[yr])
    s['year']=yr; year_rows.append(s)
    print(f"  {yr}: n={s['trades']:4d}  exp={s['expectancy_R']:+.4f}R  "
          f"pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}  dd={s['max_drawdown_R']:.1f}R")
wcsv('by_year_DF.csv',['year']+summary_fields[1:],year_rows)

# 同样做A/B/D
for res,lbl in [(res_A,'A'),(res_B,'B'),(res_D,'D')]:
    print(f"\n  --- {lbl} ---")
    by_yr=defaultdict(list)
    for t in res:
        if isinstance(t['entry_dt'],datetime.datetime):
            by_yr[t['entry_dt'].year].append(t)
    yr_rows_x=[]
    for yr in sorted(by_yr.keys()):
        s=stats_from_trades(by_yr[yr]); s['year']=yr; s['scenario']=lbl
        yr_rows_x.append(s)
        print(f"    {yr}: n={s['trades']:4d}  exp={s['expectancy_R']:+.4f}R  pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}")

# ── 按月份统计（D+F）
print("\n=== 按月份统计（D+F）===")
by_month=defaultdict(list)
for t in res_DF:
    if isinstance(t['entry_dt'],datetime.datetime):
        by_month[t['entry_dt'].strftime('%Y-%m')].append(t)
month_rows=[]
for ym in sorted(by_month.keys()):
    s=stats_from_trades(by_month[ym]); s['month']=ym; month_rows.append(s)
    sign='📈' if s['expectancy_R']>0 else '📉'
    print(f"  {ym} {sign} n={s['trades']:3d}  exp={s['expectancy_R']:+.4f}R  pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}")
wcsv('by_month_DF.csv',['month']+summary_fields[1:],month_rows)

# ── 按币种统计（D+F）
print("\n=== 按币种统计（D+F）===")
by_sym=defaultdict(list)
for t in res_DF: by_sym[t['symbol']].append(t)
sym_rows=[]
for sym in sorted(by_sym.keys()):
    s=stats_from_trades(by_sym[sym]); s['symbol']=sym; sym_rows.append(s)
    print(f"  {sym:<12} n={s['trades']:4d}  exp={s['expectancy_R']:+.4f}R  pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}")
wcsv('by_symbol_DF.csv',['symbol']+summary_fields[1:],sym_rows)

# ── 按方向统计（D+F）
print("\n=== 按方向统计（D+F）===")
by_dir=defaultdict(list)
for t in res_DF: by_dir[t['direction']].append(t)
dir_rows=[]
for d in sorted(by_dir.keys()):
    s=stats_from_trades(by_dir[d]); s['direction']=d; dir_rows.append(s)
    print(f"  {d}: n={s['trades']:4d}  exp={s['expectancy_R']:+.4f}R  pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}")
wcsv('by_direction_DF.csv',['direction']+summary_fields[1:],dir_rows)

# ── Equity Curve（D+F）
dated_DF=sorted(res_DF,key=lambda x:x['entry_dt'])
eq_rows=[]; cum=0.0
for i,t in enumerate(dated_DF):
    cum+=t['r_total']
    eq_rows.append({'bar':i+1,
                    'entry_dt':t['entry_dt'].strftime('%Y-%m-%d %H:%M') if isinstance(t['entry_dt'],datetime.datetime) else '',
                    'r_this':t['r_total'],'cum_R':round(cum,4),'symbol':t['symbol']})
wcsv('equity_curve_DF.csv',['bar','entry_dt','r_this','cum_R','symbol'],eq_rows)

# ══════════════════════════════════════════════════════════════════════════════
# Walk-Forward（全5个场景）
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "="*70)
print("Walk-Forward（全周期）")
print("="*70)

all_dated=sorted(raw_rows,key=lambda x:x['entry_dt'])
all_strict_dated=sorted(strict_rows,key=lambda x:x['entry_dt'])
first_dt=all_dated[0]['entry_dt']; last_dt=all_dated[-1]['entry_dt']

def dt_range(rs,s,e): return [r for r in rs if s<=r['entry_dt']<e]

wf_all=[]
for scen_label,scen_rows,delay_b,confirm_v2 in [
    ('A_原始',        raw_rows,    0, False),
    ('B_延迟1根K',    raw_rows,    1, False),
    ('D_确认v2',      raw_rows,    1, True),
    ('D+F_最优',      strict_rows, 1, True),
]:
    print(f"\n--- {scen_label} ---")
    for TRAIN,TEST in [(60,30),(45,15),(30,15)]:
        wins=[]; cursor=first_dt
        while True:
            ts=cursor+datetime.timedelta(days=TRAIN)
            te=ts+datetime.timedelta(days=TEST)
            if te>last_dt+datetime.timedelta(days=1): break
            te_rs=dt_range(scen_rows,ts,te)
            if not te_rs: cursor+=datetime.timedelta(days=TEST); continue
            _,tst=run_scenario(f"wf_{scen_label}",te_rs,delay_bars=delay_b,require_confirm_v2=confirm_v2)
            w=dict(scenario=scen_label,config=f"{TRAIN}d/{TEST}d",
                   window=len(wins)+1,
                   train_start=cursor.strftime('%Y-%m-%d'),
                   train_end=(ts-datetime.timedelta(1)).strftime('%Y-%m-%d'),
                   test_start=ts.strftime('%Y-%m-%d'),
                   test_end=(te-datetime.timedelta(1)).strftime('%Y-%m-%d'),
                   test_n=len(te_rs),
                   test_exp=tst['expectancy_R'],test_pf=tst['profit_factor'],
                   test_dd=tst['max_drawdown_R'],test_wr=tst['win_rate'],
                   test_tp1=tst['tp1_count'],test_tp2=tst['tp2_count'],test_stop=tst['stop_count'])
            w['pass']=(len(te_rs)>=20 and tst['profit_factor']>1.15
                       and tst['expectancy_R']>0.05 and tst['max_drawdown_R']<8.0)
            wins.append(w); cursor+=datetime.timedelta(days=TEST)
        pn=sum(1 for w in wins[-1*(len(wins)-len(wf_all) if wf_all else len(wins)):] if w['pass'] and w['config']==f"{TRAIN}d/{TEST}d")
        wf_all.extend([w for w in wins if w['config']==f"{TRAIN}d/{TEST}d" and w not in wf_all])
        wins_this=[w for w in wins if w['config']==f"{TRAIN}d/{TEST}d"]
        pn=sum(1 for w in wins_this if w['pass'])
        print(f"  {TRAIN}d/{TEST}d: {len(wins_this)}窗口 通过={pn}({pn/max(len(wins_this),1):.0%})")
        for w in wins_this[-6:]:
            f2='✓' if w['pass'] else '✗'
            print(f"    W{w['window']} [{w['test_start']}~{w['test_end']}] "
                  f"n={w['test_n']:3d} exp={w['test_exp']:+.3f}R pf={w['test_pf']:.2f} "
                  f"dd={w['test_dd']:.1f}R {f2}")

wf_fields=['scenario','config','window','train_start','train_end','test_start','test_end',
           'test_n','test_exp','test_pf','test_dd','test_wr','test_tp1','test_tp2','test_stop','pass']
# deduplicate
seen_keys=set(); wf_dedup=[]
for w in wf_all:
    k=(w['scenario'],w['config'],w['window'])
    if k not in seen_keys: seen_keys.add(k); wf_dedup.append(w)
wcsv('walk_forward_v3.csv', wf_fields, wf_dedup)

with open(OUT_DIR/'walk_forward_v3.json','w',encoding='utf-8') as f:
    json.dump({'windows':wf_dedup},f,ensure_ascii=False,indent=2,default=str)

# ══════════════════════════════════════════════════════════════════════════════
# 最终诊断汇总
# ══════════════════════════════════════════════════════════════════════════════
positive_months_DF=[m for m in month_rows if m['expectancy_R']>0]
wf_DF_pass=sum(1 for w in wf_dedup if w['scenario']=='D+F_最优' and w['pass'])
wf_DF_total=sum(1 for w in wf_dedup if w['scenario']=='D+F_最优')

diag={
    'generated_at': datetime.datetime.utcnow().isoformat(),
    'data_range': f"{first_dt.date()} ~ {last_dt.date()}",
    'total_pullback_trades': len(raw_rows),
    'strict_pullback_trades': len(strict_rows),
    'same_bar_rule': 'SL_FIRST',
    'breakout': 'DISABLED',
    'lookahead': 'NONE (D v2: K[N+1].close confirm, K[N+2].open entry)',
    'scenarios': {k:{kk:vv for kk,vv in v.items()} for k,v in scenarios.items()},
    'yearly_DF': year_rows,
    'wf_pass_rates': {
        s: f"{sum(1 for w in wf_dedup if w['scenario']==s and w['pass'])}"
           f"/{sum(1 for w in wf_dedup if w['scenario']==s)}"
        for s in ['A_原始','B_延迟1根K','D_确认v2','D+F_最优']
    },
    'positive_months_DF_count': len(positive_months_DF),
    'total_months_DF': len(month_rows),
    'conclusions': {
        'DF_still_positive': sDF['expectancy_R']>0,
        'DF_exp': sDF['expectancy_R'],
        'DF_pf':  sDF['profit_factor'],
        'DF_max_dd': sDF['max_drawdown_R'],
        'recommend_demo_test':
            sDF['expectancy_R']>0 and wf_DF_pass/max(wf_DF_total,1)>=0.5,
        'reason': ''
    }
}
cond=diag['conclusions']
if cond['DF_still_positive'] and wf_DF_pass/max(wf_DF_total,1)>=0.5:
    cond['reason']=(f"D+F方案期望R={cond['DF_exp']:+.4f}，PF={cond['DF_pf']:.3f}，"
                    f"walk-forward通过率{wf_DF_pass}/{wf_DF_total}，"
                    f"正期望月份{len(positive_months_DF)}/{len(month_rows)}——"
                    "可考虑最小仓位demo测试，但需设置严格止损保护")
else:
    cond['reason']="数据覆盖仍不足或多数市场条件下负期望，继续保持观察模式"

with open(OUT_DIR/'diagnostic_v3_summary.json','w',encoding='utf-8') as f:
    json.dump(diag,f,ensure_ascii=False,indent=2,default=str)

# 中文MD报告
md=f"""# 全周期策略诊断报告 v3
生成时间: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}
数据范围: {first_dt.date()} ~ {last_dt.date()}
同根K线规则: SL优先 | breakout: 已禁用 | 未来函数: 无

## 总体结果

| 场景 | 笔数 | 胜率 | 期望R | PF | MaxDD | TP1 | TP2 | STOP | BE |
|------|------|------|-------|----|-------|-----|-----|------|----|
"""
for k,s in scenarios.items():
    md+=(f"| {k} | {s['trades']} | {s['win_rate']:.1%} | {s['expectancy_R']:+.4f}R | "
         f"{s['profit_factor']:.3f} | {s['max_drawdown_R']:.1f}R | "
         f"{s['tp1_count']} | {s['tp2_count']} | {s['stop_count']} | {s['be_count']} |\n")

md+="\n## D+F最优组合 年度明细\n\n| 年份 | 笔数 | 胜率 | 期望R | PF | MaxDD |\n|------|------|------|-------|----|---------|\n"
for r in year_rows:
    sign='📈' if r['expectancy_R']>0 else '📉'
    md+=f"| {r['year']} {sign} | {r['trades']} | {r['win_rate']:.1%} | {r['expectancy_R']:+.4f}R | {r['profit_factor']:.3f} | {r['max_drawdown_R']:.1f}R |\n"

md+=f"\n## Walk-Forward 通过率\n\n"
for s in ['A_原始','B_延迟1根K','D_确认v2','D+F_最优']:
    p=sum(1 for w in wf_dedup if w['scenario']==s and w['pass'])
    t=sum(1 for w in wf_dedup if w['scenario']==s)
    md+=f"- {s}: {p}/{t} ({p/max(t,1):.0%})\n"

md+=f"""
## 结论

1. **D+F仍然正期望？** {'✅ 是，exp={sDF["expectancy_R"]:+.4f}R，PF={sDF["profit_factor"]:.3f}'.format(**{}) }
2. **是否建议demo小仓测试？** {'✅ 是' if cond['recommend_demo_test'] else '⚠️ 暂不建议'}
3. **理由：** {cond['reason']}

> 观察模式参数保持不变（不部署，不实盘，不恢复开仓）
"""
with open(OUT_DIR/'diagnostic_v3_summary.md','w',encoding='utf-8') as f:
    f.write(md)

print(f"\n所有文件写入: {OUT_DIR}")
for p in sorted(OUT_DIR.glob('*')):
    print(f"  {p.name} ({p.stat().st_size//1024}KB)")
print("\nDIAGNOSTIC_V3_DONE")
