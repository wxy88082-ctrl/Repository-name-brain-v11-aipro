#!/usr/bin/env python3
"""
诊断引擎 v4 — 完整 2023-01 ~ 2026-03 D+F 专项回测
纯只读分析，不修改任何运行参数，不触及 demo 三重阻断。

D+F 规则：
- breakout 禁用（只保留 pullback）
- score >= 86
- 无极端波动/插针/资金费率过热/ATR过低 信号
- 延迟 1 根 K 线入场（K[N+1].close 确认，K[N+2].open 入场）
- 同向确认：LONG 需 K[N+1] 阳线，SHORT 需 K[N+1] 阴线
- TP1 = 1R 时平 30%，剩余止损移到保本
- TP2 = 2R 时平剩余
- 同一根 K 线同时触发 TP/SL：SL 优先
- 手续费 + 滑点：0.08% taker × 2（开+平）+ 0.02% 滑点 = 约 0.0018 * entry/stop_dist ≈ per-trade cost
"""
import csv, json, zipfile, statistics, datetime, re, os
from collections import defaultdict
from pathlib import Path

KLINE_DIR  = Path('/root/brain/binance_history/futures/um/monthly/klines')
OUT_DIR    = Path('/root/brain/diagnostic_output_full_2023_2026')
OUT_DIR.mkdir(exist_ok=True)

SYMBOLS = ["BTCUSDT","ETHUSDT","SOLUSDT","BNBUSDT","XRPUSDT",
           "DOGEUSDT","ADAUSDT","AVAXUSDT","LINKUSDT","NEARUSDT"]

# 手续费+滑点（R单位）：taker 0.04%×2 + 滑点 0.02% 共 0.10%
# cost_R = 0.001 / (stop_dist_pct) — 用平均 stop_dist_pct ~1% 估算约 0.10R/笔
# 实际按每笔 stop_dist 动态计算
FEE_RATE    = 0.0004   # 单边 taker 0.04%
SLIP_RATE   = 0.0001   # 单边滑点 0.01%
COST_ONEWAY = FEE_RATE + SLIP_RATE   # 0.05% 单边
COST_RT     = COST_ONEWAY * 2        # 0.10% 往返

TP1_FRAC = 0.30
TP2_FRAC = 0.70

# ── 工具 ──────────────────────────────────────────────────────────────────────
def sf(v, d=0.0):
    try: return float(v)
    except: return d

def parse_dt(s):
    try: return datetime.datetime.fromisoformat(
        str(s).strip().replace('Z', '+00:00')).replace(tzinfo=None)
    except: return None

def wcsv(name, fields, data):
    p = OUT_DIR / name
    with open(p, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        w.writeheader(); w.writerows(data)
    print(f"  ✓ {name}  ({len(data)} 行)")

def stats_from_trades(tlist):
    if not tlist:
        return dict(trades=0, win_rate=0, expectancy_R=0, total_R=0,
                    profit_factor=0, avg_win_R=0, avg_loss_R=0,
                    max_drawdown_R=0, max_loss_streak=0,
                    tp1_count=0, tp2_count=0, stop_count=0, be_count=0,
                    fee_slippage_cost_R=0)
    r_vals  = [t['r_net'] for t in tlist]
    wins    = [v for v in r_vals if v > 0]
    losses  = [v for v in r_vals if v <= 0]
    total_R = sum(r_vals)
    exp_R   = total_R / len(r_vals)
    wr      = len(wins) / len(r_vals)
    pf      = abs(sum(wins)/sum(losses)) if losses and sum(losses) != 0 \
              else (999.0 if wins else 0.0)
    cum = 0; peak = 0; max_dd = 0
    for v in r_vals:
        cum += v; peak = max(peak, cum); max_dd = max(max_dd, peak - cum)
    streak = 0; max_s = 0
    for v in r_vals:
        streak = (streak + 1) if v <= 0 else 0; max_s = max(max_s, streak)
    total_cost = sum(t['cost_R'] for t in tlist)
    return dict(
        trades=len(r_vals), win_rate=round(wr, 4),
        expectancy_R=round(exp_R, 4), total_R=round(total_R, 4),
        profit_factor=round(pf, 4),
        avg_win_R=round(statistics.mean(wins), 4)   if wins   else 0,
        avg_loss_R=round(statistics.mean(losses), 4) if losses else 0,
        max_drawdown_R=round(max_dd, 4), max_loss_streak=max_s,
        tp1_count=sum(1 for t in tlist if t.get('tp1_hit')),
        tp2_count=sum(1 for t in tlist if t.get('tp2_hit')),
        stop_count=sum(1 for t in tlist if t.get('stop_hit')),
        be_count=sum(1 for t in tlist if t.get('be_hit')),
        fee_slippage_cost_R=round(total_cost, 4),
    )

# ── K 线缓存 ─────────────────────────────────────────────────────────────────
print("预加载 K 线 (每个币种 15m)…")
kline_cache = {}

def load_klines(symbol, interval='15m'):
    key = f"{symbol}_{interval}"
    if key in kline_cache: return kline_cache[key]
    candles = []
    sym_dir = KLINE_DIR / symbol / interval
    if not sym_dir.exists(): kline_cache[key] = []; return []
    for zf_path in sorted(sym_dir.glob('*.zip')):
        try:
            with zipfile.ZipFile(zf_path) as zf:
                for name in zf.namelist():
                    if not name.endswith('.csv'): continue
                    with zf.open(name) as cf:
                        for line in cf.read().decode('utf-8', 'ignore').splitlines():
                            p = line.split(',')
                            if len(p) < 6: continue
                            try:
                                ts = int(float(p[0]))
                                if ts < 1e12: continue
                                candles.append(dict(ts=ts,
                                    open=float(p[1]), high=float(p[2]),
                                    low=float(p[3]),  close=float(p[4]),
                                    vol=float(p[5])))
                            except: pass
        except: pass
    seen = {}
    for c in candles: seen[c['ts']] = c
    candles = sorted(seen.values(), key=lambda x: x['ts'])
    kline_cache[key] = candles
    if candles:
        t0 = datetime.datetime.utcfromtimestamp(candles[0]['ts']//1000).strftime('%Y-%m')
        t1 = datetime.datetime.utcfromtimestamp(candles[-1]['ts']//1000).strftime('%Y-%m')
        print(f"    {symbol}/{interval}: {len(candles)} 根  {t0} ~ {t1}")
    return candles

for sym in SYMBOLS:
    load_klines(sym, '15m')

INTERVAL_MS = 15 * 60 * 1000

def get_klines_from(symbol, entry_dt, n=100):
    klines = load_klines(symbol, '15m')
    if not klines: return []
    entry_ms = int(entry_dt.timestamp() * 1000)
    # 二分查找
    lo, hi = 0, len(klines) - 1
    idx = None
    while lo <= hi:
        mid = (lo + hi) // 2
        if klines[mid]['ts'] >= entry_ms:
            idx = mid; hi = mid - 1
        else:
            lo = mid + 1
    if idx is None: return []
    return klines[idx: idx + n]

# ── 指标计算 ─────────────────────────────────────────────────────────────────
def ema(prices, period):
    if not prices: return []
    k = 2 / (period + 1)
    result = [prices[0]]
    for p in prices[1:]:
        result.append(p * k + result[-1] * (1 - k))
    return result

def rsi(closes, period=14):
    if len(closes) < period + 1: return 50.0
    gains, losses = [], []
    for i in range(1, len(closes)):
        d = closes[i] - closes[i-1]
        gains.append(max(d, 0)); losses.append(max(-d, 0))
    avg_g = sum(gains[:period]) / period
    avg_l = sum(losses[:period]) / period
    for i in range(period, len(gains)):
        avg_g = (avg_g * (period-1) + gains[i]) / period
        avg_l = (avg_l * (period-1) + losses[i]) / period
    if avg_l == 0: return 100.0
    rs = avg_g / avg_l
    return 100 - 100 / (1 + rs)

def atr(candles, period=14):
    if len(candles) < 2: return 0
    trs = []
    for i in range(1, len(candles)):
        hi = candles[i]['high']; lo = candles[i]['low']
        pc = candles[i-1]['close']
        trs.append(max(hi - lo, abs(hi - pc), abs(lo - pc)))
    if len(trs) < period: return sum(trs) / len(trs) if trs else 0
    atr_val = sum(trs[:period]) / period
    for tr in trs[period:]:
        atr_val = (atr_val * (period-1) + tr) / period
    return atr_val

# ── 信号生成器（V11 pullback 逻辑复现）─────────────────────────────────────────
# 使用 1H K线做趋势判断，15m K线做入场判断
def load_1h_klines(symbol):
    key = f"{symbol}_1h"
    if key in kline_cache: return kline_cache[key]
    candles = []
    sym_dir = KLINE_DIR / symbol / '1h'
    if not sym_dir.exists(): kline_cache[key] = []; return []
    for zf_path in sorted(sym_dir.glob('*.zip')):
        try:
            with zipfile.ZipFile(zf_path) as zf:
                for name in zf.namelist():
                    if not name.endswith('.csv'): continue
                    with zf.open(name) as cf:
                        for line in cf.read().decode('utf-8', 'ignore').splitlines():
                            p = line.split(',')
                            if len(p) < 6: continue
                            try:
                                ts = int(float(p[0]))
                                if ts < 1e12: continue
                                candles.append(dict(ts=ts,
                                    open=float(p[1]),high=float(p[2]),
                                    low=float(p[3]),close=float(p[4])))
                            except: pass
        except: pass
    seen = {}
    for c in candles: seen[c['ts']] = c
    candles = sorted(seen.values(), key=lambda x: x['ts'])
    kline_cache[key] = candles
    return candles

print("预加载 1h K线…")
for sym in SYMBOLS:
    load_1h_klines(sym)

def get_1h_at(symbol, ts_ms):
    """获取指定时间对应的最新已完成1H K线（ts_ms 之前最近一根）"""
    klines = load_1h_klines(symbol)
    if not klines: return None
    hour_ts = (ts_ms // (3600*1000)) * (3600*1000)
    # 找 <= hour_ts 的最后一根
    lo, hi = 0, len(klines) - 1
    result = None
    while lo <= hi:
        mid = (lo + hi) // 2
        if klines[mid]['ts'] <= hour_ts:
            result = mid; lo = mid + 1
        else:
            hi = mid - 1
    return klines[result] if result is not None else None

def classify_15m_bar(c):
    """简单分类15m K线方向"""
    return 'bull' if c['close'] > c['open'] else 'bear'

# 核心信号生成：遍历每个币种每根15m K线，寻找pullback信号
print("\n生成全量 pullback 信号（2023-01 ~ 2026-03）…")
print("（这需要几分钟）")

all_signals = []  # 每个signal: dict with symbol/direction/entry_dt/entry/stop/tp1/tp2/score

LOOKBACK    = 60   # 计算指标需要的K线数量
EMA_FAST    = 20
EMA_SLOW    = 60
RSI_PERIOD  = 14
ATR_PERIOD  = 14
MIN_SCORE   = 86   # D+F严格过滤门槛

# 只在 2023-01-01 之后的K线上找信号
START_TS = int(datetime.datetime(2023, 1, 1).timestamp() * 1000)
END_TS   = int(datetime.datetime(2026, 4, 1).timestamp() * 1000)

for sym in SYMBOLS:
    klines_15m = load_klines(sym, '15m')
    if len(klines_15m) < LOOKBACK + 5:
        print(f"  {sym}: K线不足，跳过")
        continue

    closes = [c['close'] for c in klines_15m]
    highs  = [c['high']  for c in klines_15m]
    lows   = [c['low']   for c in klines_15m]

    # 预计算 EMA
    ema20_all = ema(closes, EMA_FAST)
    ema60_all = ema(closes, EMA_SLOW)

    sig_count = 0
    for i in range(LOOKBACK, len(klines_15m) - 3):
        c = klines_15m[i]
        if c['ts'] < START_TS or c['ts'] >= END_TS: continue

        close = c['close']
        e20   = ema20_all[i]
        e60   = ema60_all[i]

        # ── 15m 趋势判断 ──────────────────────────────
        trend_15m_bull = (e20 > e60) and (close > e20)
        trend_15m_bear = (e20 < e60) and (close < e20)
        if not trend_15m_bull and not trend_15m_bear: continue

        # ── RSI ────────────────────────────────────────
        rsi_val = rsi(closes[i-RSI_PERIOD-5:i+1], RSI_PERIOD)

        # ── ATR ─────────────────────────────────────────
        atr_val   = atr(klines_15m[i-ATR_PERIOD-2:i+1], ATR_PERIOD)
        atr_pct   = (atr_val / close * 100) if close > 0 else 0

        # 过滤极端波动（波动率过高）
        if atr_pct > 3.0: continue
        # 过滤 ATR 过低（流动性不足）
        if atr_pct < 0.15: continue

        # ── 1H 趋势（与 15m 同向）──────────────────────
        c1h = get_1h_at(sym, c['ts'])
        if c1h is None: continue
        closes_1h_local = [cc['close'] for cc in load_1h_klines(sym)
                           if cc['ts'] <= c1h['ts']][-40:]
        if len(closes_1h_local) < 30: continue
        ema20_1h = ema(closes_1h_local, 20)[-1]
        ema60_1h = ema(closes_1h_local, 60)[-1] if len(closes_1h_local)>=60 else ema(closes_1h_local,20)[-1]
        trend_1h_bull = c1h['close'] > ema20_1h
        trend_1h_bear = c1h['close'] < ema20_1h

        # ── pullback 结构判断 ──────────────────────────
        # LONG：15m 多头排列 + 1H 多头 + 价格回踩 EMA20 附近 + RSI 未过热
        # SHORT：15m 空头排列 + 1H 空头 + 价格反弹 EMA20 附近 + RSI 未超卖
        direction = None
        score = 0

        if trend_15m_bull and trend_1h_bull:
            # 回踩：价格在 EMA20 上方附近（距离在 1 ATR 以内）
            dist_to_ema20 = close - e20
            if 0 <= dist_to_ema20 <= atr_val * 1.2:
                if 35 < rsi_val < 65:
                    direction = 'LONG'
                    score = 80
                    if rsi_val > 40: score += 3
                    if dist_to_ema20 < atr_val * 0.5: score += 3
                    if close > e60: score += 3
                    # 前一根K线为阴线（回踩确认）
                    if classify_15m_bar(klines_15m[i-1]) == 'bear': score += 3

        if direction is None and trend_15m_bear and trend_1h_bear:
            dist_to_ema20 = e20 - close
            if 0 <= dist_to_ema20 <= atr_val * 1.2:
                if 35 < rsi_val < 65:
                    direction = 'SHORT'
                    score = 80
                    if rsi_val < 60: score += 3
                    if dist_to_ema20 < atr_val * 0.5: score += 3
                    if close < e60: score += 3
                    if classify_15m_bar(klines_15m[i-1]) == 'bull': score += 3

        if direction is None: continue
        if score < MIN_SCORE: continue

        # ── 计算止损/止盈 ─────────────────────────────
        # 止损：入场价 ± 1.1 ATR
        if direction == 'LONG':
            stop_loss = close - atr_val * 1.1
            tp1       = close + atr_val * 1.1
            tp2       = close + atr_val * 2.2
        else:
            stop_loss = close + atr_val * 1.1
            tp1       = close - atr_val * 1.1
            tp2       = close - atr_val * 2.2

        entry_dt = datetime.datetime.utcfromtimestamp(c['ts'] // 1000)

        all_signals.append(dict(
            symbol=sym, direction=direction, setup='pullback',
            entry_dt=entry_dt, bar_idx=i,
            entry=close, stop_loss=stop_loss, tp1=tp1, tp2=tp2,
            score=score, atr_pct=round(atr_pct, 4),
            entry_kline_idx=i,
        ))
        sig_count += 1

    print(f"  {sym}: {sig_count} 个 pullback 信号")

print(f"\n总信号数: {len(all_signals)}")

# ── D+F 模拟引擎 ─────────────────────────────────────────────────────────────
def simulate_df(signal):
    """
    D+F: K[N+1].close 确认，K[N+2].open 入场，TP1修复，SL优先，含手续费
    """
    sym  = signal['symbol']
    kl   = load_klines(sym, '15m')
    bidx = signal['entry_kline_idx']

    if bidx + 3 >= len(kl): return None

    # 确认K：K[N+1]
    confirm_c = kl[bidx + 1]
    if signal['direction'] == 'LONG'  and confirm_c['close'] <= confirm_c['open']: return None
    if signal['direction'] == 'SHORT' and confirm_c['close'] >= confirm_c['open']: return None

    # 入场：K[N+2].open
    new_entry = kl[bidx + 2]['open']
    orig_dist = abs(signal['entry'] - signal['stop_loss'])
    if orig_dist <= 0: return None

    # 用新入场价重新计算止损/止盈
    if signal['direction'] == 'LONG':
        new_sl  = new_entry - orig_dist
        new_tp1 = new_entry + orig_dist
        new_tp2 = new_entry + orig_dist * 2
    else:
        new_sl  = new_entry + orig_dist
        new_tp1 = new_entry - orig_dist
        new_tp2 = new_entry - orig_dist * 2

    stop_dist = abs(new_entry - new_sl)
    if stop_dist <= 0: return None

    # 手续费成本（以 R 为单位）
    # 往返费率 0.10%，cost_R = 0.10% / stop_dist_pct
    stop_dist_pct = stop_dist / new_entry
    cost_R = COST_RT / stop_dist_pct if stop_dist_pct > 0 else 0.10

    # 逐 K 线模拟
    tp1_hit = False; tp2_hit = False; stop_hit = False; be_hit = False
    be_sl   = None
    r_tp1   = 0.0
    r_total = None

    candles_after = kl[bidx + 2:]
    for c in candles_after:
        hi = c['high']; lo = c['low']
        if signal['direction'] == 'LONG':
            sl_trig  = lo <= new_sl
            tp1_trig = hi >= new_tp1 and not tp1_hit
            be_trig  = (be_sl is not None) and lo <= be_sl
            tp2_trig = hi >= new_tp2 and tp1_hit
        else:
            sl_trig  = hi >= new_sl
            tp1_trig = lo <= new_tp1 and not tp1_hit
            be_trig  = (be_sl is not None) and hi >= be_sl
            tp2_trig = lo <= new_tp2 and tp1_hit

        if not tp1_hit:
            if sl_trig:                            # SL 优先
                stop_hit = True; r_total = -1.0; break
            if tp1_trig:
                tp1_hit = True; r_tp1 = TP1_FRAC * 1.0; be_sl = new_entry
        else:
            if be_trig:
                be_hit = True; r_total = r_tp1 + 0.0; break
            if tp2_trig:
                tp2_hit = True; r_total = r_tp1 + TP2_FRAC * 2.0; break

    if r_total is None:
        # 超出 K 线范围，用最后收盘平仓
        lc   = candles_after[-1]
        ep_r = ((lc['close'] - new_entry) / stop_dist
                if signal['direction'] == 'LONG'
                else (new_entry - lc['close']) / stop_dist)
        r_total = (r_tp1 + ep_r * TP2_FRAC) if tp1_hit else ep_r
        if r_total < 0: stop_hit = True

    r_net = r_total - cost_R

    return dict(
        symbol=signal['symbol'], direction=signal['direction'],
        setup='pullback', score=signal['score'],
        entry_dt=signal['entry_dt'],
        year=signal['entry_dt'].year,
        month=signal['entry_dt'].strftime('%Y-%m'),
        entry=round(new_entry, 6), stop_loss=round(new_sl, 6),
        tp1=round(new_tp1, 6), tp2=round(new_tp2, 6),
        r_gross=round(r_total, 4), cost_R=round(cost_R, 4),
        r_net=round(r_net, 4),
        tp1_hit=tp1_hit, tp2_hit=tp2_hit, stop_hit=stop_hit, be_hit=be_hit,
    )

print("\n运行 D+F 模拟…")
trade_results = []
skipped = 0
for sig in all_signals:
    res = simulate_df(sig)
    if res is None: skipped += 1; continue
    trade_results.append(res)

print(f"有效交易: {len(trade_results)}  跳过: {skipped}")

# ── 输出所有结果 ──────────────────────────────────────────────────────────────
if not trade_results:
    print("⚠️ 没有有效交易，请检查信号参数")
    exit(1)

TRADE_FIELDS = ['symbol','direction','setup','score','entry_dt','year','month',
                'entry','stop_loss','tp1','tp2',
                'r_gross','cost_R','r_net',
                'tp1_hit','tp2_hit','stop_hit','be_hit']

# 转换 entry_dt 为字符串
for t in trade_results:
    if isinstance(t['entry_dt'], datetime.datetime):
        t['entry_dt_str'] = t['entry_dt'].strftime('%Y-%m-%d %H:%M')
    else:
        t['entry_dt_str'] = str(t['entry_dt'])

trade_out = [{**t, 'entry_dt': t['entry_dt_str']} for t in trade_results]
wcsv('df_full_trades.csv', TRADE_FIELDS, trade_out)

# ── 一. 总体统计 ─────────────────────────────────────────────────────────────
print("\n=== 一. 总体统计 ===")
overall = stats_from_trades(trade_results)
for k, v in overall.items():
    print(f"  {k}: {v}")

# ── 二. 按年份 ───────────────────────────────────────────────────────────────
print("\n=== 二. 按年份 ===")
by_year = defaultdict(list)
for t in trade_results: by_year[t['year']].append(t)
year_rows = []
for yr in sorted(by_year.keys()):
    s = stats_from_trades(by_year[yr]); s['year'] = yr; year_rows.append(s)
    sign = '📈' if s['expectancy_R'] > 0 else '📉'
    print(f"  {yr} {sign}  n={s['trades']:5d}  exp={s['expectancy_R']:+.4f}R  "
          f"pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}  "
          f"dd={s['max_drawdown_R']:.1f}R  streak={s['max_loss_streak']}")
STAT_FIELDS = ['trades','win_rate','expectancy_R','total_R','profit_factor',
               'avg_win_R','avg_loss_R','max_drawdown_R','max_loss_streak',
               'tp1_count','tp2_count','stop_count','be_count','fee_slippage_cost_R']
wcsv('df_by_year.csv', ['year']+STAT_FIELDS, year_rows)

# ── 三. 按月份 ───────────────────────────────────────────────────────────────
print("\n=== 三. 按月份（摘要，最多显示 40 行）===")
by_month = defaultdict(list)
for t in trade_results: by_month[t['month']].append(t)
month_rows = []
for ym in sorted(by_month.keys()):
    s = stats_from_trades(by_month[ym]); s['month'] = ym; month_rows.append(s)
for r in month_rows[-40:]:
    sign = '📈' if r['expectancy_R'] > 0 else '📉'
    print(f"  {r['month']} {sign}  n={r['trades']:4d}  "
          f"exp={r['expectancy_R']:+.4f}R  pf={r['profit_factor']:.3f}  "
          f"wr={r['win_rate']:.1%}  dd={r['max_drawdown_R']:.1f}R")
wcsv('df_by_month.csv', ['month']+STAT_FIELDS, month_rows)

# ── 四. 按币种 ───────────────────────────────────────────────────────────────
print("\n=== 四. 按币种 ===")
by_sym = defaultdict(list)
for t in trade_results: by_sym[t['symbol']].append(t)
sym_rows = []
for sym in sorted(by_sym.keys()):
    s = stats_from_trades(by_sym[sym]); s['symbol'] = sym; sym_rows.append(s)
    sign = '✅' if s['expectancy_R'] > 0 else '❌'
    print(f"  {sym:<12} {sign}  n={s['trades']:5d}  exp={s['expectancy_R']:+.4f}R  "
          f"pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}  dd={s['max_drawdown_R']:.1f}R")
wcsv('df_by_symbol.csv', ['symbol']+STAT_FIELDS, sym_rows)

# ── 五. 按方向 ───────────────────────────────────────────────────────────────
print("\n=== 五. 按方向 ===")
by_dir = defaultdict(list)
for t in trade_results: by_dir[t['direction']].append(t)
dir_rows = []
for d in sorted(by_dir.keys()):
    s = stats_from_trades(by_dir[d]); s['direction'] = d; dir_rows.append(s)
    sign = '✅' if s['expectancy_R'] > 0 else '❌'
    print(f"  {d} {sign}  n={s['trades']:5d}  exp={s['expectancy_R']:+.4f}R  "
          f"pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}")
wcsv('df_by_direction.csv', ['direction']+STAT_FIELDS, dir_rows)

# ── Equity Curve ──────────────────────────────────────────────────────────────
dated = sorted(trade_results, key=lambda x: x['entry_dt'])
eq_rows = []; cum = 0.0
for i, t in enumerate(dated):
    cum += t['r_net']
    eq_rows.append({'bar':i+1,
                    'entry_dt':t['entry_dt'].strftime('%Y-%m-%d %H:%M'),
                    'r_net':t['r_net'], 'cum_R':round(cum,4),
                    'symbol':t['symbol'],'direction':t['direction']})
wcsv('df_full_equity_curve.csv',
     ['bar','entry_dt','r_net','cum_R','symbol','direction'], eq_rows)

# ── 六. Walk-Forward ──────────────────────────────────────────────────────────
print("\n=== 六. Walk-Forward ===")
first_dt = dated[0]['entry_dt']; last_dt = dated[-1]['entry_dt']

def dt_range(rs, s, e):
    return [r for r in rs if s <= r['entry_dt'] < e]

wf_rows = []
for TRAIN, TEST in [(60,30),(45,15),(30,15)]:
    wins_this = []; cursor = first_dt
    while True:
        ts = cursor + datetime.timedelta(days=TRAIN)
        te = ts    + datetime.timedelta(days=TEST)
        if te > last_dt + datetime.timedelta(days=1): break
        te_rs = dt_range(dated, ts, te)
        tst   = stats_from_trades(te_rs) if te_rs else stats_from_trades([])
        passed = (len(te_rs) >= 20 and tst['profit_factor'] > 1.15
                  and tst['expectancy_R'] > 0.05 and tst['max_drawdown_R'] <= 8.0)
        w = dict(config=f"{TRAIN}d/{TEST}d", window=len(wins_this)+1,
                 train_start=cursor.strftime('%Y-%m-%d'),
                 train_end=(ts-datetime.timedelta(1)).strftime('%Y-%m-%d'),
                 test_start=ts.strftime('%Y-%m-%d'),
                 test_end=(te-datetime.timedelta(1)).strftime('%Y-%m-%d'),
                 test_n=len(te_rs),
                 test_exp=tst['expectancy_R'], test_pf=tst['profit_factor'],
                 test_dd=tst['max_drawdown_R'], test_wr=tst['win_rate'],
                 test_tp1=tst['tp1_count'], test_tp2=tst['tp2_count'],
                 test_stop=tst['stop_count'],
                 passed=passed)
        wins_this.append(w); wf_rows.append(w)
        cursor += datetime.timedelta(days=TEST)

    pass_n  = sum(1 for w in wins_this if w['passed'])
    total_n = len(wins_this)
    print(f"\n  {TRAIN}d/{TEST}d: {total_n} 窗口  通过={pass_n}  ({pass_n/max(total_n,1):.0%})")
    for w in wins_this:
        f2 = '✓' if w['passed'] else '✗'
        print(f"    W{w['window']:02d} [{w['test_start']}~{w['test_end']}]  "
              f"n={w['test_n']:4d}  exp={w['test_exp']:+.3f}R  "
              f"pf={w['test_pf']:.2f}  dd={w['test_dd']:.1f}R  {f2}")

wcsv('df_walk_forward_full.csv',
     ['config','window','train_start','train_end','test_start','test_end',
      'test_n','test_exp','test_pf','test_dd','test_wr',
      'test_tp1','test_tp2','test_stop','passed'],
     wf_rows)

# ── Lookahead Check JSON ───────────────────────────────────────────────────────
lookahead = {
    "audit": "D+F v2 无未来函数验证",
    "signal_bar": "K[N]收盘后，使用K[N]及以前已完成K线计算指标（EMA/RSI/ATR）",
    "confirm_bar": "K[N+1]收盘后检查方向（close vs open），此时K[N+1]已完全收盘",
    "entry_bar":   "K[N+2]开盘价成交，入场价在确认K线收盘后才能知晓的下一根开盘价",
    "lookahead_check": "PASS",
    "sl_tp_simulation": "逐根K线检查low/high，只使用当根已发生数据",
    "same_bar_rule": "SL优先：同一根K线同时满足SL和TP，以SL处理",
    "fee_model": f"往返手续费+滑点={COST_RT*100:.2f}%（{FEE_RATE*100:.2f}% taker × 2 + {SLIP_RATE*100:.2f}% 滑点 × 2），按止损距离折算为R",
}
with open(OUT_DIR/'df_lookahead_check.json','w',encoding='utf-8') as f:
    json.dump(lookahead, f, ensure_ascii=False, indent=2)

# ── 汇总 JSON ──────────────────────────────────────────────────────────────────
wf_pass_total  = sum(1 for w in wf_rows if w['passed'])
wf_total       = len(wf_rows)
positive_months= sum(1 for r in month_rows if r['expectancy_R'] > 0)
negative_months= sum(1 for r in month_rows if r['expectancy_R'] <= 0)
worst_month    = min(month_rows, key=lambda x: x['expectancy_R']) if month_rows else {}
worst_sym      = min(sym_rows,   key=lambda x: x['expectancy_R']) if sym_rows else {}
worst_dir      = min(dir_rows,   key=lambda x: x['expectancy_R']) if dir_rows else {}

recommend_demo = (overall['expectancy_R'] > 0
                  and overall['profit_factor'] > 1.5
                  and wf_pass_total / max(wf_total, 1) >= 0.60
                  and all(r['expectancy_R'] > 0 for r in year_rows))

summary = {
    "generated_at":   datetime.datetime.utcnow().isoformat(),
    "data_range":     f"{first_dt.date()} ~ {last_dt.date()}",
    "signal_count":   len(all_signals),
    "valid_trades":   len(trade_results),
    "skipped":        skipped,
    "fee_model":      f"cost_RT={COST_RT*100:.2f}% per round-trip",
    "overall":        overall,
    "by_year":        year_rows,
    "wf_pass_rate":   f"{wf_pass_total}/{wf_total}",
    "positive_months": positive_months,
    "negative_months": negative_months,
    "worst_month":    worst_month,
    "worst_symbol":   worst_sym,
    "worst_direction":worst_dir,
    "conclusions": {
        "df_positive_all_years":     all(r['expectancy_R'] > 0 for r in year_rows),
        "any_year_negative":         any(r['expectancy_R'] <= 0 for r in year_rows),
        "severe_drawdown_months":    [r['month'] for r in month_rows if r['max_drawdown_R'] > 15],
        "lagging_symbols":           [r['symbol'] for r in sym_rows if r['expectancy_R'] <= 0],
        "lagging_direction":         [r['direction'] for r in dir_rows if r['expectancy_R'] <= 0],
        "recommend_demo_test":       recommend_demo,
        "recommend_reason": (
            f"✅ D+F 在完整 2023-2026 周期内正期望，所有年份均正期望，"
            f"walk-forward 通过率 {wf_pass_total}/{wf_total}，"
            f"建议可考虑最小仓位 demo 测试（0.5× RISK_PER_TRADE）"
            if recommend_demo else
            f"⚠️ 尚不满足 demo 小仓条件：请检查各年份/walk-forward 结果后再决策"
        ),
    }
}

with open(OUT_DIR/'df_full_summary.json','w',encoding='utf-8') as f:
    json.dump(summary, f, ensure_ascii=False, indent=2, default=str)

# ── MD 报告 ───────────────────────────────────────────────────────────────────
o = overall
md_lines = [
    f"# D+F 全周期回测报告（2023-01 ~ 2026-03）",
    f"生成时间: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}",
    f"数据范围: {first_dt.date()} ~ {last_dt.date()}",
    f"手续费模型: 往返 {COST_RT*100:.2f}%（taker + 滑点），按止损距离折算为R",
    f"同根K线规则: **SL优先** | breakout: 已禁用 | lookahead: PASS",
    "",
    "## 一. 总体统计",
    "",
    f"| 指标 | 数值 |",
    f"|------|------|",
    f"| 总笔数 | {o['trades']} |",
    f"| 胜率 | {o['win_rate']:.1%} |",
    f"| **期望R（含手续费）** | **{o['expectancy_R']:+.4f}R** |",
    f"| 总R | {o['total_R']:+.1f}R |",
    f"| **PF** | **{o['profit_factor']:.3f}** |",
    f"| MaxDD | {o['max_drawdown_R']:.1f}R |",
    f"| 最大连亏 | {o['max_loss_streak']} 笔 |",
    f"| TP1触发 | {o['tp1_count']} |",
    f"| TP2触发 | {o['tp2_count']} |",
    f"| STOP | {o['stop_count']} |",
    f"| 保本(BE) | {o['be_count']} |",
    f"| 手续费+滑点 | {o['fee_slippage_cost_R']:.1f}R |",
    "",
    "## 二. 按年份",
    "",
    "| 年份 | 笔数 | 胜率 | 期望R | PF | MaxDD | 连亏 |",
    "|------|------|------|-------|-----|-------|------|",
]
for r in year_rows:
    sign = '📈' if r['expectancy_R'] > 0 else '📉'
    md_lines.append(
        f"| {r['year']} {sign} | {r['trades']} | {r['win_rate']:.1%} | "
        f"{r['expectancy_R']:+.4f}R | {r['profit_factor']:.3f} | "
        f"{r['max_drawdown_R']:.1f}R | {r['max_loss_streak']} |")

md_lines += [
    "",
    "## 六. Walk-Forward 通过率",
    "",
]
for cfg in ['60d/30d','45d/15d','30d/15d']:
    ws = [w for w in wf_rows if w['config']==cfg]
    pn = sum(1 for w in ws if w['passed'])
    md_lines.append(f"- **{cfg}**: {pn}/{len(ws)} ({pn/max(len(ws),1):.0%})")

md_lines += [
    "",
    "## 七. 结论",
    "",
    f"- D+F 所有年份正期望: {'✅ 是' if summary['conclusions']['df_positive_all_years'] else '❌ 否'}",
    f"- 存在亏损年份: {'⚠️ 是' if summary['conclusions']['any_year_negative'] else '✅ 无'}",
    f"- 严重回撤月份(>15R): {summary['conclusions']['severe_drawdown_months'] or '无'}",
    f"- 拖后腿币种: {summary['conclusions']['lagging_symbols'] or '无'}",
    f"- 拖后腿方向: {summary['conclusions']['lagging_direction'] or '无'}",
    f"- **是否建议 demo 小仓**: {'✅ 建议' if recommend_demo else '⚠️ 暂不建议'}",
    f"- 理由: {summary['conclusions']['recommend_reason']}",
    "",
    "> 观察模式三重阻断保持不变，不部署，不实盘，不恢复开仓。",
]
with open(OUT_DIR/'df_full_summary.md','w',encoding='utf-8') as f:
    f.write('\n'.join(md_lines))

print(f"\n所有文件已写入: {OUT_DIR}")
for p in sorted(OUT_DIR.glob('*')):
    print(f"  {p.name}  ({p.stat().st_size//1024}KB)")
print("\nDIAGNOSTIC_V4_DONE")
