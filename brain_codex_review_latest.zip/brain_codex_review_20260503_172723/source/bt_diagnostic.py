#!/usr/bin/env python3
"""
回测过滤链路诊断脚本
输出每层拦截统计 + 5组对照测试
"""
import sys, os, json, datetime, time
sys.path.insert(0, '/root/brain')
os.chdir('/root/brain')

# Load env
env_vars = {}
with open('/root/brain/.demo.env') as f:
    for line in f:
        l = line.strip().replace('export ', '')
        if '=' in l and not l.startswith('#'):
            k, v = l.split('=', 1)
            env_vars[k.strip()] = v.strip().strip('"')
for k, v in env_vars.items():
    os.environ.setdefault(k, v)

# Override for paper/backtest
os.environ['TRADING_MODE'] = 'paper'
os.environ['BRAIN_WS'] = '/tmp/bt_diag_ws'
os.environ['LOCAL_KLINE_DIR'] = '/root/brain/binance_history'
os.environ['PREFER_LOCAL_KLINES'] = '1'
os.environ['EXCHANGE_INFO_CACHE'] = '/root/brain/exchange_info_cache.json'
os.environ['BACKTEST_START'] = '2025-09-01'
os.environ['BACKTEST_END'] = '2026-03-31'
os.environ['BACKTEST_LIMIT'] = '30000'
os.environ['FEE_BPS'] = '4.0'
os.environ['SLIPPAGE_BPS'] = '2.0'
os.environ['V11_REQUIRE_EDGE_FOR_EXCHANGE'] = '0'
os.environ['V11_MIN_EDGE_TRADES'] = '0'

os.makedirs('/tmp/bt_diag_ws', exist_ok=True)

from brain_v11_1_aipro import (
    Settings, BinanceFuturesClient, load_local_klines,
    iso_to_ms, slice_until_close, env_bool, env_float, env_int, env_str,
    TradeSignal, Candle, safe_float, clamp,
    StrategyEngine, BacktestTrade
)
import importlib
brain_mod = importlib.import_module('brain_v11_1_aipro')
StrategyEngineV10 = getattr(brain_mod, 'StrategyEngineV10', StrategyEngine)

SYMBOLS = [
    'BTCUSDT','ETHUSDT','BNBUSDT','XRPUSDT','AVAXUSDT',
    'SOLUSDT','DOGEUSDT','ADAUSDT','LINKUSDT','NEARUSDT'
]

DIAG_CONFIGS = {
    'A': dict(
        ENABLE_CONFIRM_V2='1', MIN_ATR_PCT='0.10',
        SETUP_WHITELIST='pullback', SCORE_THRESHOLD='60',
        V11_ALT_MIN_SCORE='66', ENABLE_TREND_SETUP='0',
        ENABLE_BREAKOUT_SETUP='0',
    ),
    'B': dict(
        ENABLE_CONFIRM_V2='0', MIN_ATR_PCT='0.10',
        SETUP_WHITELIST='pullback', SCORE_THRESHOLD='60',
        V11_ALT_MIN_SCORE='66', ENABLE_TREND_SETUP='0',
        ENABLE_BREAKOUT_SETUP='0',
    ),
    'C': dict(
        ENABLE_CONFIRM_V2='1', MIN_ATR_PCT='0.03',
        SETUP_WHITELIST='pullback', SCORE_THRESHOLD='60',
        V11_ALT_MIN_SCORE='66', ENABLE_TREND_SETUP='0',
        ENABLE_BREAKOUT_SETUP='0',
    ),
    'D': dict(
        ENABLE_CONFIRM_V2='1', MIN_ATR_PCT='0.10',
        SETUP_WHITELIST='pullback,trend,breakout', SCORE_THRESHOLD='60',
        V11_ALT_MIN_SCORE='66', ENABLE_TREND_SETUP='1',
        ENABLE_BREAKOUT_SETUP='1',
    ),
    'E': dict(
        ENABLE_CONFIRM_V2='0', MIN_ATR_PCT='0.03',
        SETUP_WHITELIST='pullback,trend,breakout', SCORE_THRESHOLD='50',
        V11_ALT_MIN_SCORE='50', ENABLE_TREND_SETUP='1',
        ENABLE_BREAKOUT_SETUP='1',
    ),
}

def apply_config(cfg):
    for k, v in cfg.items():
        os.environ[k] = v

def make_settings():
    return Settings.from_env()

def load_klines_for(client, symbol, settings):
    start_ms = iso_to_ms(settings.backtest_start) if settings.backtest_start else None
    end_ms = iso_to_ms(settings.backtest_end) if settings.backtest_end else None
    entry = client.historical_klines(symbol, settings.entry_interval, start_ms, end_ms, settings.backtest_limit)
    trend = client.historical_klines(symbol, settings.trend_interval, start_ms, end_ms, max(500, settings.backtest_limit // 4 + 300))
    btc4 = client.historical_klines('BTCUSDT', settings.regime_interval, start_ms, end_ms, max(500, settings.backtest_limit // 16 + 300))
    btc1 = client.historical_klines('BTCUSDT', settings.trend_interval, start_ms, end_ms, max(500, settings.backtest_limit // 4 + 300))
    return entry, trend, btc4, btc1

def diagnose_symbol(symbol, entry, trend, btc4, btc1, engine, settings, confirm_v2):
    """Run full filter chain and count at each layer."""
    counters = dict(
        raw_bars=len(entry),
        raw_signals=0,
        has_direction=0,
        by_setup={'pullback':0,'breakout':0,'trend':0,'other':0},
        blocked_atr=0,
        blocked_setup_whitelist=0,
        blocked_score=0,
        blocked_regime=0,
        blocked_structure=0,
        blocked_other=0,
        blocked_confirm_v2=0,
        passed=0,
        trades=0,
    )
    open_until = -1
    for i in range(220, len(entry) - 2):
        if i <= open_until:
            continue
        signal_entry = entry[:i+1]
        now_t = entry[i].close_time
        trend_slice = slice_until_close(trend, now_t)
        btc4_slice = slice_until_close(btc4, now_t)
        btc1_slice = slice_until_close(btc1, now_t)
        if len(trend_slice) < 100 or len(btc4_slice) < 80:
            continue

        regime = engine.analyze_regime_from_candles(btc4_slice, btc1_slice)
        sig = engine.analyze_symbol_from_candles(symbol, signal_entry, trend_slice, regime, 0.0, 0.0)

        counters['raw_signals'] += 1
        if sig.direction in ('LONG','SHORT'):
            counters['has_direction'] += 1

        setup = sig.setup or 'other'
        counters['by_setup'][setup if setup in counters['by_setup'] else 'other'] += 1

        if sig.blockers:
            for b in sig.blockers:
                bl = b.lower()
                if 'atr%' in bl:
                    counters['blocked_atr'] += 1; break
                elif 'setup' in bl or 'whitelist' in bl:
                    counters['blocked_setup_whitelist'] += 1; break
                elif '评分' in bl or 'score' in bl or 'alt' in bl:
                    counters['blocked_score'] += 1; break
                elif 'btc' in bl or '环境' in bl or '逆' in bl:
                    counters['blocked_regime'] += 1; break
                elif '结构' in bl or 'pullback' in bl or '入场' in bl:
                    counters['blocked_structure'] += 1; break
                else:
                    counters['blocked_other'] += 1; break
            continue

        # passed allow check
        entry_i = i + 1 + max(0, settings.entry_delay_bars)

        # confirm_v2 check
        if confirm_v2:
            confirm_i = max(i+1, entry_i-1)
            if confirm_i >= len(entry):
                counters['blocked_confirm_v2'] += 1
                continue
            c = entry[confirm_i]
            if sig.direction == 'LONG' and c.close <= c.open:
                counters['blocked_confirm_v2'] += 1
                continue
            if sig.direction == 'SHORT' and c.close >= c.open:
                counters['blocked_confirm_v2'] += 1
                continue

        counters['passed'] += 1
        open_until = min(entry_i + 50, len(entry) - 1)  # approximate

    return counters

def run_full_backtest(cfg_name, cfg):
    """Run actual backtest and return metrics."""
    print(f"\n  Running group {cfg_name}...", flush=True)
    apply_config(cfg)
    settings = make_settings()
    client = BinanceFuturesClient(settings)
    
    confirm_v2 = cfg.get('ENABLE_CONFIRM_V2','0') == '1'
    
    all_trades = []
    symbol_results = {}
    
    for sym in SYMBOLS:
        try:
            entry, trend, btc4, btc1 = load_klines_for(client, sym, settings)
            if len(entry) < 250:
                symbol_results[sym] = {'error': f'insufficient data: {len(entry)} bars'}
                continue
            
            engine_cls = StrategyEngineV10
            engine = engine_cls(settings, client=None)
            
            # Diagnosis counts
            diag = diagnose_symbol(sym, entry, trend, btc4, btc1, engine, settings, confirm_v2)
            
            # Actual backtest via Backtester
            from brain_v11_1_aipro import Backtester
            bt = Backtester(settings, client)
            trades = bt.backtest_symbol(sym, 0.0)
            
            diag['trades'] = len(trades)
            symbol_results[sym] = diag
            all_trades.extend(trades)
            print(f"    {sym}: bars={diag['raw_bars']} signals={diag['raw_signals']} passed={diag['passed']} cv2_blocked={diag['blocked_confirm_v2']} trades={len(trades)}", flush=True)
        except Exception as e:
            symbol_results[sym] = {'error': str(e)}
            print(f"    {sym}: ERROR {e}", flush=True)
    
    # Aggregate metrics
    from brain_v11_1_aipro import compute_metrics
    metrics = compute_metrics(all_trades)
    
    # Count exit types
    tp1_count = sum(1 for t in all_trades if getattr(t,'tp1_hit',False))
    tp2_count = sum(1 for t in all_trades if t.reason and 'TP2' in t.reason)
    stop_count = sum(1 for t in all_trades if t.reason and 'STOP' in t.reason.upper())
    be_count = sum(1 for t in all_trades if t.reason and 'BE' in t.reason.upper())
    
    return {
        'config': cfg_name,
        'params': cfg,
        'total_trades': len(all_trades),
        'win_rate': round(metrics.get('win_rate',0)*100, 1),
        'expectancy_R': round(metrics.get('expectancy_R',0), 4),
        'profit_factor': round(metrics.get('profit_factor',0), 3),
        'max_dd_R': round(metrics.get('max_drawdown_R',0), 2),
        'exits': {'TP1': tp1_count, 'TP2': tp2_count, 'STOP': stop_count, 'BE': be_count},
        'by_symbol': symbol_results,
    }

# === MAIN ===
print("=== 回测过滤链路诊断 ===", flush=True)
print(f"Period: 2025-09-01 ~ 2026-03-31 | Symbols: {len(SYMBOLS)} | BACKTEST_LIMIT: 30000", flush=True)
print(f"Started: {datetime.datetime.utcnow().isoformat()}", flush=True)

results = {}
for cfg_name, cfg in DIAG_CONFIGS.items():
    t0 = time.time()
    r = run_full_backtest(cfg_name, cfg)
    r['elapsed_sec'] = round(time.time() - t0, 1)
    results[cfg_name] = r
    print(f"  Group {cfg_name}: trades={r['total_trades']} win={r['win_rate']}% expR={r['expectancy_R']} PF={r['profit_factor']} [{r['elapsed_sec']}s]", flush=True)

# === OUTPUT REPORT ===
lines = []
lines.append("# 回测过滤链路诊断报告")
lines.append(f"\n生成时间: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
lines.append(f"回测期间: 2025-09-01 ~ 2026-03-31 (6个月)")
lines.append(f"币种: {', '.join(SYMBOLS)}")
lines.append(f"BACKTEST_LIMIT: 30000")
lines.append("")

lines.append("## 一、五组对照结果汇总")
lines.append("")
lines.append("| 组别 | CONFIRM_V2 | MIN_ATR | SETUP | SCORE | trades | win% | expR | PF | MaxDD_R | TP1 | TP2 | STOP | BE |")
lines.append("|------|-----------|--------|-------|-------|--------|------|------|----|---------|-----|-----|------|-----|")
for cfg_name, r in results.items():
    cfg = r['params']
    exits = r['exits']
    lines.append(
        f"| {cfg_name} | {cfg['ENABLE_CONFIRM_V2']} | {cfg['MIN_ATR_PCT']} | {cfg['SETUP_WHITELIST'][:10]} | {cfg['SCORE_THRESHOLD']} | "
        f"**{r['total_trades']}** | {r['win_rate']}% | {r['expectancy_R']} | {r['profit_factor']} | {r['max_dd_R']} | "
        f"{exits['TP1']} | {exits['TP2']} | {exits['STOP']} | {exits['BE']} |"
    )

lines.append("")
lines.append("## 二、A组（当前参数）各币种过滤链路详情")
lines.append("")
a_result = results.get('A', {})
lines.append("| 币种 | 原始K线 | 信号总数 | pullback | trend | breakout | 被ATR拦 | 被whitelist拦 | 被score拦 | 被regime拦 | 被结构拦 | 被confirmV2拦 | 通过 | 成交 |")
lines.append("|------|--------|---------|---------|-------|---------|--------|-------------|---------|----------|---------|------------|------|------|")
for sym in SYMBOLS:
    d = a_result.get('by_symbol', {}).get(sym, {})
    if 'error' in d:
        lines.append(f"| {sym} | ERROR: {d['error']} | | | | | | | | | | | | |")
    else:
        bs = d.get('by_setup', {})
        lines.append(
            f"| {sym} | {d.get('raw_bars',0)} | {d.get('raw_signals',0)} | {bs.get('pullback',0)} | {bs.get('trend',0)} | {bs.get('breakout',0)} | "
            f"{d.get('blocked_atr',0)} | {d.get('blocked_setup_whitelist',0)} | {d.get('blocked_score',0)} | {d.get('blocked_regime',0)} | "
            f"{d.get('blocked_structure',0)} | {d.get('blocked_confirm_v2',0)} | {d.get('passed',0)} | {d.get('trades',0)} |"
        )

lines.append("")
lines.append("## 三、最大拦截层分析")
lines.append("")
# Aggregate A group blockers
totals = {}
for sym in SYMBOLS:
    d = a_result.get('by_symbol', {}).get(sym, {})
    for key in ['blocked_atr','blocked_setup_whitelist','blocked_score','blocked_regime','blocked_structure','blocked_confirm_v2']:
        totals[key] = totals.get(key, 0) + d.get(key, 0)
sorted_blockers = sorted(totals.items(), key=lambda x: -x[1])
for k, v in sorted_blockers:
    lines.append(f"- **{k}**: {v} 次")

lines.append("")
lines.append("## 四、各组完整by_symbol")
lines.append("")
for cfg_name, r in results.items():
    lines.append(f"### 组别 {cfg_name} (trades={r['total_trades']})")
    lines.append("")
    lines.append("| 币种 | 通过 | confirmV2拦 | 最终trades |")
    lines.append("|------|------|------------|-----------|")
    for sym in SYMBOLS:
        d = r.get('by_symbol', {}).get(sym, {})
        lines.append(f"| {sym} | {d.get('passed',0)} | {d.get('blocked_confirm_v2',0)} | {d.get('trades',0)} |")
    lines.append("")

lines.append("## 五、结论")
lines.append("")
a_trades = results.get('A',{}).get('total_trades', 0)
e_trades = results.get('E',{}).get('total_trades', 0)
if e_trades > 0 and a_trades == 0:
    lines.append("- E组有单({}笔)，A组无单 → 当前参数过严，不是代码bug".format(e_trades))
    top_blocker = sorted_blockers[0][0] if sorted_blockers else "unknown"
    lines.append(f"- 最大拦截层: **{top_blocker}** ({sorted_blockers[0][1] if sorted_blockers else 0}次)")
    lines.append("- 建议：结合回测数据决定是否放宽该层，不要直接修改模拟盘参数")
elif e_trades == 0:
    lines.append("- E组仍然0笔 → 回测信号生成路径可能存在bug，或历史数据不够/不匹配")
else:
    lines.append(f"- A组已有{a_trades}笔交易")

report = '\n'.join(lines)
with open('/root/brain/backtest_filter_diagnostic.md', 'w', encoding='utf-8') as f:
    f.write(report)

# Also save raw JSON
with open('/root/brain/backtest_filter_diagnostic.json', 'w', encoding='utf-8') as f:
    # strip non-serializable
    clean = {}
    for k, v in results.items():
        clean[k] = {
            'config': v['config'],
            'total_trades': v['total_trades'],
            'win_rate': v['win_rate'],
            'expectancy_R': v['expectancy_R'],
            'profit_factor': v['profit_factor'],
            'max_dd_R': v['max_dd_R'],
            'exits': v['exits'],
            'elapsed_sec': v['elapsed_sec'],
            'by_symbol_summary': {
                sym: {
                    'raw_signals': d.get('raw_signals',0),
                    'passed': d.get('passed',0),
                    'blocked_confirm_v2': d.get('blocked_confirm_v2',0),
                    'trades': d.get('trades',0),
                    'blocked_atr': d.get('blocked_atr',0),
                    'blocked_structure': d.get('blocked_structure',0),
                }
                for sym, d in v.get('by_symbol',{}).items()
            }
        }
    json.dump(clean, f, ensure_ascii=False, indent=2)

print("\n=== DONE ===", flush=True)
print(f"Report: /root/brain/backtest_filter_diagnostic.md", flush=True)
print("\n--- SUMMARY ---", flush=True)
for cfg_name, r in results.items():
    print(f"Group {cfg_name}: trades={r['total_trades']} win={r['win_rate']}% expR={r['expectancy_R']} PF={r['profit_factor']}", flush=True)
