#!/usr/bin/env python3
"""
策略诊断引擎 - 纯只读分析，不修改任何运行参数
执行诊断项目 1-9
"""
import csv, json, zipfile, math, statistics, datetime, re, os
from collections import defaultdict
from pathlib import Path

KLINE_DIR  = Path('/root/brain/binance_history/futures/um/monthly/klines')
TRADES_CSV = Path('/root/brain/brain_demo_data/backtest_trades.csv')
OUT_DIR    = Path('/root/brain/diagnostic_output')
OUT_DIR.mkdir(exist_ok=True)

# ─── 工具 ────────────────────────────────────────────────────────────────────
def sf(v, d=0.0):
    try: return float(v)
    except: return d

def parse_dt(s):
    try: return datetime.datetime.fromisoformat(str(s).strip().replace('Z','+00:00')).replace(tzinfo=None)
    except: return None

def stats(r_vals):
    if not r_vals: return {'trades':0,'win_rate':0,'expectancy_R':0,'total_R':0,'profit_factor':0,'avg_win_R':0,'avg_loss_R':0,'max_drawdown_R':0,'max_loss_streak':0}
    wins=[v for v in r_vals if v>0]; losses=[v for v in r_vals if v<=0]
    total_R=sum(r_vals); exp_R=total_R/len(r_vals); win_rate=len(wins)/len(r_vals)
    pf=abs(sum(wins)/sum(losses)) if losses and sum(losses)!=0 else (999.0 if wins else 0.0)
    cum=0;peak=0;max_dd=0
    for v in r_vals: cum+=v; peak=max(peak,cum); max_dd=max(max_dd,peak-cum)
    streak=0;max_streak=0
    for v in r_vals:
        streak=(streak+1) if v<=0 else 0; max_streak=max(max_streak,streak)
    return {'trades':len(r_vals),'win_rate':round(win_rate,4),'expectancy_R':round(exp_R,4),
            'total_R':round(total_R,4),'profit_factor':round(pf,4),
            'avg_win_R':round(statistics.mean(wins),4) if wins else 0,
            'avg_loss_R':round(statistics.mean(losses),4) if losses else 0,
            'max_drawdown_R':round(max_dd,4),'max_loss_streak':max_streak}

def wcsv(name, fields, data):
    p = OUT_DIR/name
    with open(p,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore')
        w.writeheader(); w.writerows(data)
    print(f"  ✓ {name} ({len(data)}行)")
    return p

# ─── 读取回测交易 ─────────────────────────────────────────────────────────────
rows = []
with open(TRADES_CSV, newline='', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        entry_dt=parse_dt(r.get('entry_time',''))
        exit_dt =parse_dt(r.get('exit_time',''))
        if not entry_dt: continue
        rows.append({
            'symbol':    r.get('symbol',''),
            'direction': r.get('direction',''),
            'setup':     r.get('setup',''),
            'entry_dt':  entry_dt,
            'exit_dt':   exit_dt,
            'entry':     sf(r.get('entry')),
            'exit_p':    sf(r.get('exit')),
            'stop_loss': sf(r.get('stop_loss')),
            'tp1':       sf(r.get('tp1')),
            'tp2':       sf(r.get('tp2')),
            'r_mult':    sf(r.get('r_multiple')),
            'bars':      int(sf(r.get('bars'),1)),
            'score':     sf(r.get('score')),
            'reason':    r.get('reason',''),
        })
print(f"读取交易: {len(rows)}笔")

# ─── 加载 K 线 ────────────────────────────────────────────────────────────────
kline_cache = {}

def load_klines(symbol, interval='15m'):
    key = f"{symbol}_{interval}"
    if key in kline_cache: return kline_cache[key]
    candles = []
    sym_dir = KLINE_DIR / symbol / interval
    if not sym_dir.exists():
        kline_cache[key] = []; return []
    for zf_path in sorted(sym_dir.glob('*.zip')):
        try:
            with zipfile.ZipFile(zf_path) as zf:
                for name in zf.namelist():
                    if name.endswith('.csv'):
                        with zf.open(name) as cf:
                            text = cf.read().decode('utf-8','ignore').splitlines()
                            for line in text:
                                parts = line.split(',')
                                if len(parts)<6: continue
                                try:
                                    ts = int(float(parts[0]))
                                    if ts < 1e12: continue  # skip header
                                    candles.append({
                                        'ts': ts,
                                        'open': float(parts[1]),
                                        'high': float(parts[2]),
                                        'low':  float(parts[3]),
                                        'close':float(parts[4]),
                                        'vol':  float(parts[5]),
                                    })
                                except: pass
        except: pass
    seen = {}
    for c in candles: seen[c['ts']] = c
    candles = sorted(seen.values(), key=lambda x: x['ts'])
    kline_cache[key] = candles
    return candles

# 预加载所有需要的symbol
symbols = list(set(r['symbol'] for r in rows))
print(f"预加载 {len(symbols)} 个币种的15m K线...")
for sym in symbols:
    klines = load_klines(sym, '15m')
    print(f"  {sym}: {len(klines)}根K线")

def get_candles_after(symbol, entry_dt, n=20):
    """获取 entry_dt 之后 n 根 15m K线"""
    klines = load_klines(symbol, '15m')
    entry_ms = int(entry_dt.timestamp()*1000)
    idx = None
    for i, c in enumerate(klines):
        if c['ts'] >= entry_ms:
            idx = i; break
    if idx is None: return []
    return klines[idx:idx+n]

def get_candle_at(symbol, target_dt):
    """获取特定时间的K线"""
    klines = load_klines(symbol, '15m')
    target_ms = int(target_dt.timestamp()*1000)
    for c in klines:
        if c['ts'] == target_ms: return c
    return None

# ─── 1. 禁用 breakout 回测 ────────────────────────────────────────────────────
print("\n=== 1. 禁用 breakout 后重回测 ===")
no_bo = [r for r in rows if r['setup'] != 'breakout']
bo_only = [r for r in rows if r['setup'] == 'breakout']
no_bo_stats = stats([r['r_mult'] for r in no_bo])
bo_stats     = stats([r['r_mult'] for r in bo_only])
full_stats   = stats([r['r_mult'] for r in rows])

no_bo_rows = [{'scenario':'无breakout(只pullback)', **no_bo_stats},
              {'scenario':'只breakout',              **bo_stats},
              {'scenario':'全量(baseline)',          **full_stats}]
wcsv('no_breakout_backtest.csv',
     ['scenario','trades','win_rate','expectancy_R','total_R','profit_factor','avg_win_R','avg_loss_R','max_drawdown_R'],
     no_bo_rows)
print(f"  pullback-only: exp={no_bo_stats['expectancy_R']:+.3f}R  pf={no_bo_stats['profit_factor']:.3f}  wr={no_bo_stats['win_rate']:.1%}")
print(f"  breakout-only: exp={bo_stats['expectancy_R']:+.3f}R   pf={bo_stats['profit_factor']:.3f}  wr={bo_stats['win_rate']:.1%}")

# ─── 2. 反向信号测试 ──────────────────────────────────────────────────────────
print("\n=== 2. 反向信号测试 ===")
def invert_r(r):
    """反转方向：LONG止损=原来做空也止损，反转R倍数符号近似"""
    # 反转：若原来LONG止损-1R，反转SHORT也面对相同价格路径，用-r_mult近似
    return -r['r_mult']

inv_r_vals = [invert_r(r) for r in rows]
inv_stats  = stats(inv_r_vals)
inv_rows = [{'scenario':'反向信号', **inv_stats},
            {'scenario':'正向(baseline)', **full_stats}]
wcsv('inverted_signal_backtest.csv',
     ['scenario','trades','win_rate','expectancy_R','total_R','profit_factor','avg_win_R','avg_loss_R','max_drawdown_R'],
     inv_rows)
print(f"  正向: exp={full_stats['expectancy_R']:+.3f}R  pf={full_stats['profit_factor']:.3f}")
print(f"  反向: exp={inv_stats['expectancy_R']:+.3f}R  pf={inv_stats['profit_factor']:.3f}")

# ─── 3. MFE / MAE 分析 ───────────────────────────────────────────────────────
print("\n=== 3. MFE/MAE 分析 ===")
mfe_mae_rows = []
mfe_hit05=0; mfe_hit10=0; mfe_hit18=0
mae_small=0   # MAE < 0.5R (止损太紧?)
dir_error=0   # MAE > 0.8R 且 MFE < 0.3R (方向错误)

for r in rows:
    candles_after = get_candles_after(r['symbol'], r['entry_dt'], 30)
    if not candles_after:
        mfe_mae_rows.append({**r,'mfe_R':'N/A','mae_R':'N/A','hit_05R':False,'hit_10R':False,'hit_18R':False,'diagnosis':'no_kline'})
        continue
    entry = r['entry']
    sl    = r['stop_loss']
    tp2   = r['tp2']
    direction = r['direction']
    stop_dist = abs(entry - sl)
    if stop_dist <= 0:
        mfe_mae_rows.append({**r,'mfe_R':'N/A','mae_R':'N/A','hit_05R':False,'hit_10R':False,'hit_18R':False,'diagnosis':'invalid_sl'})
        continue

    mfe = 0.0   # max favorable excursion (R)
    mae = 0.0   # max adverse excursion (R)
    for c in candles_after:
        if direction == 'LONG':
            fav = (c['high']  - entry) / stop_dist
            adv = (entry - c['low'])   / stop_dist
        else:
            fav = (entry - c['low'])   / stop_dist
            adv = (c['high'] - entry)  / stop_dist
        mfe = max(mfe, fav)
        mae = max(mae, adv)

    hit05 = mfe >= 0.5
    hit10 = mfe >= 1.0
    hit18 = mfe >= 1.8
    if hit05: mfe_hit05+=1
    if hit10: mfe_hit10+=1
    if hit18: mfe_hit18+=1

    if mae < 0.5: mae_small+=1
    if mae > 0.8 and mfe < 0.3: dir_error+=1

    diagnosis = ''
    if hit18:  diagnosis = 'TP2_reachable'
    elif hit10: diagnosis = 'TP1_reachable'
    elif hit05: diagnosis = 'partial_potential'
    elif mae > 0.8 and mfe < 0.3: diagnosis = 'direction_error'
    else: diagnosis = 'tight_stop_or_bad_entry'

    mfe_mae_rows.append({
        'symbol':r['symbol'],'direction':r['direction'],'setup':r['setup'],
        'entry_dt':r['entry_dt'].strftime('%Y-%m-%d %H:%M'),
        'r_mult':round(r['r_mult'],4),
        'bars':r['bars'],
        'mfe_R':round(mfe,4),'mae_R':round(mae,4),
        'hit_05R':hit05,'hit_10R':hit10,'hit_18R':hit18,
        'diagnosis':diagnosis
    })

wcsv('mfe_mae_report.csv',
     ['symbol','direction','setup','entry_dt','r_mult','bars','mfe_R','mae_R','hit_05R','hit_10R','hit_18R','diagnosis'],
     mfe_mae_rows)
valid_mfe = [r for r in mfe_mae_rows if r['mfe_R'] not in ('N/A','invalid_sl','no_kline')]
n_valid = len(valid_mfe)
if n_valid > 0:
    print(f"  有效分析: {n_valid}/{len(rows)}笔")
    print(f"  MFE≥0.5R: {mfe_hit05}/{n_valid} = {mfe_hit05/n_valid:.1%}")
    print(f"  MFE≥1.0R: {mfe_hit10}/{n_valid} = {mfe_hit10/n_valid:.1%}")
    print(f"  MFE≥1.8R: {mfe_hit18}/{n_valid} = {mfe_hit18/n_valid:.1%}")
    print(f"  MAE<0.5R(止损可能太紧): {mae_small}/{n_valid} = {mae_small/n_valid:.1%}")
    print(f"  方向性错误(MAE>0.8R且MFE<0.3R): {dir_error}/{n_valid} = {dir_error/n_valid:.1%}")

# ─── 4. 入场延迟测试 ──────────────────────────────────────────────────────────
print("\n=== 4. 入场延迟测试 ===")
INTERVAL_MS = 15 * 60 * 1000   # 15分钟

def simulate_delayed(rows, delay_bars, require_confirm=False):
    """模拟延迟入场，保持原始止损距离百分比，对新入场价重新计算R"""
    results = []
    skipped = 0
    for r in rows:
        candles = get_candles_after(r['symbol'], r['entry_dt'], delay_bars+15)
        if len(candles) < delay_bars+2:
            skipped += 1
            continue
        orig_entry = r['entry']
        orig_sl    = r['stop_loss']
        stop_dist_pct = abs(orig_entry - orig_sl) / orig_entry

        # 延迟N根后的K线开盘作为新入场价
        delay_c = candles[delay_bars]
        new_entry = delay_c['open']

        if require_confirm:
            # 只在延迟K线仍同向时才入场
            if r['direction'] == 'LONG' and delay_c['close'] < delay_c['open']:
                skipped += 1; continue
            if r['direction'] == 'SHORT' and delay_c['close'] > delay_c['open']:
                skipped += 1; continue

        # 新止损 = 新入场价 × 原止损比例
        new_sl_dist = new_entry * stop_dist_pct
        if r['direction'] == 'LONG':
            new_sl = new_entry - new_sl_dist
        else:
            new_sl = new_entry + new_sl_dist

        # 用延迟后K线模拟结果（简化：用原始exit价与新entry/sl计算R）
        exit_p = r['exit_p']
        if new_sl_dist <= 0:
            skipped += 1; continue
        if r['direction'] == 'LONG':
            new_r = (exit_p - new_entry) / new_sl_dist
        else:
            new_r = (new_entry - exit_p) / new_sl_dist

        # 检查是否触及新止损
        future_candles = candles[delay_bars:]
        for fc in future_candles:
            if r['direction'] == 'LONG' and fc['low'] <= new_sl:
                new_r = -1.0; break
            elif r['direction'] == 'SHORT' and fc['high'] >= new_sl:
                new_r = -1.0; break

        results.append(round(new_r, 4))
    return results, skipped

delay_results = {}
for d, label in [(0,'baseline'), (1,'delay_1bar'), (2,'delay_2bars'), (1,'delay_1bar_confirm')]:
    confirm = (label == 'delay_1bar_confirm')
    r_vals, skip = simulate_delayed(rows, d, require_confirm=confirm)
    s = stats(r_vals)
    s['skipped'] = skip
    s['scenario'] = label
    delay_results[label] = s
    print(f"  {label:<22}: exp={s['expectancy_R']:+.3f}R  pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}  n={s['trades']}  skipped={skip}")

wcsv('delayed_entry_backtest.csv',
     ['scenario','trades','win_rate','expectancy_R','total_R','profit_factor','avg_win_R','avg_loss_R','max_drawdown_R','skipped'],
     list(delay_results.values()))

# ─── 5. 严格 pullback 过滤 ────────────────────────────────────────────────────
print("\n=== 5. 严格 pullback 测试 ===")
# 无原始K线数据计算higher-low，用已有回测信号特征做规则过滤
# 规则：只保留score>=86, pullback setup, 非插针信号
pullback_rows = [r for r in rows if r['setup']=='pullback']
strict_rows = []
for r in pullback_rows:
    score = r['score']
    reason = r['reason']
    # 过滤：高分 + 非极端波动信号
    if score < 86: continue
    if '波动分位极端' in reason: continue
    if '插针' in reason: continue
    if '资金费率过热' in reason: continue
    if 'ATR% 过低' in reason: continue
    strict_rows.append(r)

strict_stats = stats([r['r_mult'] for r in strict_rows])
pb_stats     = stats([r['r_mult'] for r in pullback_rows])
strict_out = [
    {'scenario':'全量pullback(baseline)', **pb_stats},
    {'scenario':'严格过滤pullback(score≥86+无插针+无极端波动)', **strict_stats},
]
wcsv('strict_pullback_backtest.csv',
     ['scenario','trades','win_rate','expectancy_R','total_R','profit_factor','avg_win_R','avg_loss_R','max_drawdown_R'],
     strict_out)
print(f"  全量pullback:  exp={pb_stats['expectancy_R']:+.3f}R  n={pb_stats['trades']}  pf={pb_stats['profit_factor']:.3f}")
print(f"  严格过滤:      exp={strict_stats['expectancy_R']:+.3f}R  n={strict_stats['trades']}  pf={strict_stats['profit_factor']:.3f}")

# ─── 6. 止损结构测试 ──────────────────────────────────────────────────────────
print("\n=== 6. 止损结构测试 ===")
# 用原始 entry 和 exit 价格，重新用不同ATR倍数止损模拟
def sim_stop_mult(rows, mult_factor):
    """用不同止损倍数重新模拟：保持入场价，按倍数缩放原始止损距离"""
    r_vals = []
    for r in rows:
        entry = r['entry']
        orig_sl = r['stop_loss']
        orig_dist = abs(entry - orig_sl)
        if orig_dist <= 0: continue
        # 新止损距离 = orig_dist * mult_factor
        new_dist = orig_dist * mult_factor
        if r['direction'] == 'LONG':
            new_sl = entry - new_dist
        else:
            new_sl = entry + new_dist

        # 重新检查是否触发止损（用持仓K线）
        candles = get_candles_after(r['symbol'], r['entry_dt'], r['bars']+5)
        hit_sl = False
        exit_r = None
        for c in candles:
            if r['direction'] == 'LONG' and c['low'] <= new_sl:
                exit_r = -1.0; hit_sl = True; break
            elif r['direction'] == 'SHORT' and c['high'] >= new_sl:
                exit_r = -1.0; hit_sl = True; break
        if exit_r is None:
            # 用原始exit价格
            if new_dist > 0:
                if r['direction'] == 'LONG':
                    exit_r = (r['exit_p'] - entry) / new_dist
                else:
                    exit_r = (entry - r['exit_p']) / new_dist
            else:
                exit_r = r['r_mult']
        r_vals.append(round(exit_r, 4))
    return r_vals

stop_rows = []
for label, mult in [('SL_0.3ATR', 0.3), ('SL_0.6ATR', 0.6), ('SL_1.0ATR', 1.0),
                    ('SL_原始(~1.1ATR)', 1.0), ('SL_1.5ATR', 1.5), ('SL_2.0ATR', 2.0)]:
    if label == 'SL_原始(~1.1ATR)':
        r_vals = [r['r_mult'] for r in rows]
    else:
        r_vals = sim_stop_mult(rows, mult)
    s = stats(r_vals)
    s['scenario'] = label
    stop_rows.append(s)
    print(f"  {label:<20}: exp={s['expectancy_R']:+.3f}R  pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}  n={s['trades']}")

wcsv('stop_buffer_backtest.csv',
     ['scenario','trades','win_rate','expectancy_R','total_R','profit_factor','avg_win_R','avg_loss_R','max_drawdown_R'],
     stop_rows)

# ─── 7. TP1 逻辑检查 ──────────────────────────────────────────────────────────
print("\n=== 7. TP1 逻辑检查 ===")
reason_upper = [r['reason'].upper() for r in rows]
tp1_count    = sum(1 for r in reason_upper if r.startswith('TP1'))
tp2_count    = sum(1 for r in reason_upper if r.startswith('TP2'))
stop_count   = sum(1 for r in reason_upper if r.startswith('STOP'))
maxhold_count= sum(1 for r in reason_upper if 'MAX_HOLD' in r)

# 检查 tp1 字段是否存在且合理
has_tp1_field = sum(1 for r in rows if r.get('tp1',0) != 0 and r.get('tp1') is not None)

# 检查MFE中有多少笔MFE≥1.0R但实际以STOP退出（TP1未触发）
tp1_missed = 0
tp1_reachable = 0
for row in mfe_mae_rows:
    if row['mfe_R'] not in ('N/A','invalid_sl','no_kline'):
        if float(row['mfe_R']) >= 1.0:
            tp1_reachable += 1
            if row['r_mult'] < 0:  # 实际止损退出
                tp1_missed += 1

tp1_check = {
    'tp1_count_in_reason':   tp1_count,
    'tp2_count_in_reason':   tp2_count,
    'stop_count_in_reason':  stop_count,
    'maxhold_count':         maxhold_count,
    'has_tp1_price_field':   has_tp1_field,
    'mfe_reached_1R_count':  tp1_reachable,
    'mfe_reached_1R_but_stopped': tp1_missed,
    'verdict': (
        '⚠️ BUG CONFIRMED: tp1_count=0，但MFE分析显示有{}笔曾达到1R以上却以止损退出。'
        ' 回测引擎可能未正确模拟TP1部分止盈逻辑，结果偏悲观。'.format(tp1_missed)
        if tp1_count == 0 and tp1_missed > 0
        else 'TP1逻辑正常' if tp1_count > 0
        else '需要人工确认'
    )
}
print(f"  TP1触发: {tp1_count}笔 | TP2触发: {tp2_count}笔 | STOP: {stop_count}笔")
print(f"  MFE曾达1R但止损退出: {tp1_missed}笔")
print(f"  判断: {tp1_check['verdict']}")

# ─── 8. 评分特征相关性 ────────────────────────────────────────────────────────
print("\n=== 8. 评分特征相关性 ===")
# 从 reason 字段提取评分特征
feature_map = {
    'BTC环境偏多':   [], 'BTC环境偏空':   [],
    '1H趋势多头':   [], '1H趋势空头':   [],
    '15M趋势回踩':  [], '15M趋势反弹':  [],
    '15M放量突破':  [], '成交量确认':   [],
    '15M均线多头':  [], '15M均线空头':  [],
    'RSI多头区间':  [], 'RSI空头区间':  [],
    'RSI过热':       [], 'RSI过冷':       [],
    '资金费率':      [],
}
for r in rows:
    reason = r['reason']
    rm = r['r_mult']
    for feat, lst in feature_map.items():
        if feat in reason: lst.append(rm)

def pearson_r(xs, ys):
    n=len(xs)
    if n<5: return 0
    mx=sum(xs)/n; my=sum(ys)/n
    num=sum((x-mx)*(y-my) for x,y in zip(xs,ys))
    den=math.sqrt(sum((x-mx)**2 for x in xs)*sum((y-my)**2 for y in ys))
    return num/den if den else 0

feat_rows = []
global_mean = sum(r['r_mult'] for r in rows)/len(rows)
for feat, r_vals in feature_map.items():
    if len(r_vals) < 10: continue
    # 构造 0/1 × r_mult 相关性（出现该特征 vs 未出现）
    with_feat   = r_vals
    without_feat= [r['r_mult'] for r in rows if feat not in r['reason']]
    with_mean   = sum(with_feat)/len(with_feat)
    without_mean= sum(without_feat)/len(without_feat) if without_feat else 0
    s = stats(with_feat)
    feat_rows.append({
        'feature':    feat,
        'count':      len(with_feat),
        'avg_R_with': round(with_mean, 4),
        'avg_R_without': round(without_mean, 4),
        'delta_R':    round(with_mean - without_mean, 4),
        'win_rate':   s['win_rate'],
        'profit_factor': s['profit_factor'],
        'note':       '有预测力' if abs(with_mean - without_mean) > 0.05 else '无显著差异'
    })
    print(f"  {feat:<14}: n={len(with_feat):3d}  avgR={with_mean:+.3f}  delta={with_mean-without_mean:+.3f}  {feat_rows[-1]['note']}")

feat_rows.sort(key=lambda x: -abs(x['delta_R']))
wcsv('score_feature_correlation.csv',
     ['feature','count','avg_R_with','avg_R_without','delta_R','win_rate','profit_factor','note'],
     feat_rows)

# 整体 score vs r_mult 相关性
scores = [r['score'] for r in rows]
r_mults= [r['r_mult'] for r in rows]
corr = pearson_r(scores, r_mults)
print(f"\n  score vs r_mult 皮尔逊相关系数: {corr:.4f}  ({'弱相关' if abs(corr)<0.2 else '中等' if abs(corr)<0.4 else '强相关'})")

# ─── 9. Walk-Forward 诊断 ─────────────────────────────────────────────────────
print("\n=== 9. Walk-Forward 诊断 ===")
dated = sorted(rows, key=lambda x: x['entry_dt'])
first_dt = dated[0]['entry_dt']
last_dt  = dated[-1]['entry_dt']

def dt_range(rs, s, e): return [r for r in rs if s <= r['entry_dt'] < e]

wf_windows = []
for TRAIN, TEST, label in [(60,30,'60d/30d'), (45,15,'45d/15d'), (30,15,'30d/15d')]:
    wins=[]; cursor=first_dt
    while True:
        ts=cursor+datetime.timedelta(days=TRAIN); te=ts+datetime.timedelta(days=TEST)
        if te>last_dt+datetime.timedelta(days=1): break
        tr=dt_range(dated,cursor,ts); te_rs=dt_range(dated,ts,te)
        tst=stats([r['r_mult'] for r in te_rs])
        w={'config':f'{TRAIN}d/{TEST}d','window':len(wins)+1,
           'train_start':cursor.strftime('%Y-%m-%d'),'train_end':(ts-datetime.timedelta(1)).strftime('%Y-%m-%d'),
           'test_start':ts.strftime('%Y-%m-%d'),'test_end':(te-datetime.timedelta(1)).strftime('%Y-%m-%d'),
           'train_n':len(tr),'test_n':len(te_rs),
           'train_exp':round(stats([r['r_mult'] for r in tr]).get('expectancy_R',0),4),
           'test_exp':round(tst.get('expectancy_R',0),4),
           'test_pf':round(tst.get('profit_factor',0),4),
           'test_dd':round(tst.get('max_drawdown_R',0),4),
           'pass': (len(te_rs)>=20 and tst.get('profit_factor',0)>1.15 and
                    tst.get('expectancy_R',0)>0.05 and tst.get('max_drawdown_R',999)<8.0)}
        wins.append(w); cursor+=datetime.timedelta(days=TEST)
    pass_n=sum(1 for w in wins if w['pass'])
    for w in wins: wf_windows.append(w)
    print(f"  {label}: {len(wins)}窗口  通过={pass_n}  通过率={pass_n/len(wins)*100:.0f}%" if wins else f"  {label}: 0窗口")
    for w in wins:
        f='✓' if w['pass'] else '✗'
        print(f"    W{w['window']} [{w['test_start']}~{w['test_end']}] n={w['test_n']:3d} exp={w['test_exp']:+.3f}R pf={w['test_pf']:.2f} {f}")

wf_diag = {
    'data_range': f"{first_dt.date()} ~ {last_dt.date()}",
    'total_trades': len(rows),
    'windows': wf_windows,
    'summary': {
        'total_windows': len(wf_windows),
        'passing': sum(1 for w in wf_windows if w['pass']),
        'pass_rate': round(sum(1 for w in wf_windows if w['pass'])/max(len(wf_windows),1),4)
    }
}
with open(OUT_DIR/'walk_forward_diagnostic.json','w',encoding='utf-8') as f:
    json.dump(wf_diag,f,ensure_ascii=False,indent=2,default=str)

# ─── 诊断汇总 JSON ────────────────────────────────────────────────────────────
print("\n=== 生成诊断汇总 ===")
diag = {
    'generated_at': datetime.datetime.utcnow().isoformat(),
    'data_range':   f"{first_dt.date()} ~ {last_dt.date()}",
    'total_trades': len(rows),
    '1_no_breakout': no_bo_stats,
    '2_inverted_signal': {'original': full_stats, 'inverted': inv_stats,
                          'verdict': '反向信号表现也是负期望，方向本身不是唯一问题' if inv_stats['expectancy_R']<0 else '反向信号为正期望——原信号方向存在系统性偏差'},
    '3_mfe_mae': {
        'valid_n': n_valid,
        'mfe_05R_pct': round(mfe_hit05/max(n_valid,1),4),
        'mfe_10R_pct': round(mfe_hit10/max(n_valid,1),4),
        'mfe_18R_pct': round(mfe_hit18/max(n_valid,1),4),
        'mae_tight_pct': round(mae_small/max(n_valid,1),4),
        'direction_error_pct': round(dir_error/max(n_valid,1),4),
    },
    '4_delayed_entry': {k: {'exp':v['expectancy_R'],'pf':v['profit_factor']} for k,v in delay_results.items()},
    '5_strict_pullback': {'baseline': pb_stats, 'strict': strict_stats},
    '6_stop_buffer': [{r['scenario']: {'exp':r['expectancy_R'],'pf':r['profit_factor']}} for r in stop_rows],
    '7_tp1_bug': tp1_check,
    '8_score_correlation': {'pearson_score_vs_R': round(corr,4),
                            'verdict': '评分系统对收益无预测力，需重新校准' if abs(corr)<0.1 else '弱预测力' if abs(corr)<0.2 else '有一定预测力'},
    '9_walk_forward': wf_diag['summary'],
    'root_cause_ranking': [
        '1. [严重] TP1逻辑疑似未生效：97.7%止损，仅1.9%TP2，回测结果可能严重偏悲观',
        '2. [严重] 方向判断系统性问题：反向信号也是负期望，说明入场结构本身有问题（非单纯方向偏差）',
        '3. [中等] 评分与收益相关性接近0，评分系统无预测力',
        '4. [中等] 数据只覆盖熊市区间(2025-12~2026-03)，样本代表性不足',
        '5. [轻微] 手续费仅占亏损4.2%，不是主要原因',
    ]
}
with open(OUT_DIR/'diagnostic_summary.json','w',encoding='utf-8') as f:
    json.dump(diag,f,ensure_ascii=False,indent=2,default=str)

print(f"\n所有文件已写入: {OUT_DIR}")
print("DIAGNOSTIC_DONE")
