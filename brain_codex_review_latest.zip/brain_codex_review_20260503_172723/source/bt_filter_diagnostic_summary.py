#!/usr/bin/env python3
"""Summarize backtest filter diagnostics produced by ChatGPT V3 hotfix."""
from __future__ import annotations
import json, sys
from pathlib import Path
roots = [Path('/root/brain/backtest_full_ws'), Path('/root/brain/backtest_bt2_ws')]
for root in roots:
    p = root / 'backtest_filter_diagnostic.json'
    print('\n===', root, '===')
    if not p.exists():
        print('no diagnostic file:', p)
        continue
    d = json.loads(p.read_text())
    totals = {}
    for sym, row in d.get('symbols', {}).items():
        for k, v in row.items():
            if isinstance(v, (int, float)):
                totals[k] = totals.get(k, 0) + v
    print(json.dumps(totals, ensure_ascii=False, indent=2))
    # top reject reasons
    rr = {}
    for row in d.get('symbols', {}).values():
        for k, v in (row.get('reject_reasons') or {}).items():
            rr[k] = rr.get(k, 0) + v
    print('reject_reasons:', json.dumps(dict(sorted(rr.items(), key=lambda kv: -kv[1])[:20]), ensure_ascii=False, indent=2))
