#!/usr/bin/env bash
set -euo pipefail
cd /root/brain
source .demo.env || true
export TRADING_MODE=paper
export BACKTEST_OFFLINE_ONLY=1
export NO_API_FALLBACK=1
export BACKTEST_START=${BACKTEST_START:-2025-01-01}
export BACKTEST_END=${BACKTEST_END:-2025-01-31}
export BACKTEST_LIMIT=${BACKTEST_SMOKE_LIMIT:-5000}
mkdir -p /root/brain/backtest_v6_diag_ws

declare -A CASES
CASES[A]=""
CASES[B]="ENABLE_CONFIRM_V2=0"
CASES[C]="MIN_ATR_PCT=0.03"
CASES[D]="SETUP_WHITELIST=pullback,trend,breakout ENABLE_TREND_SETUP=1"
CASES[E]="ENABLE_CONFIRM_V2=0 MIN_ATR_PCT=0.03 SCORE_THRESHOLD=50 SETUP_WHITELIST=pullback,trend,breakout ENABLE_TREND_SETUP=1"

for c in A B C D E; do
  echo "### V6 DIAG CASE $c ${CASES[$c]}"
  (
    eval "export ${CASES[$c]}"
    python3 bt_analyze.py
  ) > "/root/brain/backtest_v6_diag_ws/case_${c}.log" 2>&1 || true
  tail -n 40 "/root/brain/backtest_v6_diag_ws/case_${c}.log" || true
done
python3 - <<'PYBT'
from pathlib import Path
import json, re
base=Path('/root/brain/backtest_v6_diag_ws')
summary={}
for p in sorted(base.glob('case_*.log')):
    txt=p.read_text(errors='ignore')
    trades=None
    for pat in [r'trades\s*[:=]\s*(\d+)', r'final_trades\s*[:=]\s*(\d+)']:
        m=re.search(pat, txt, re.I)
        if m: trades=int(m.group(1))
    summary[p.stem]= {'bytes': p.stat().st_size, 'trades_hint': trades, 'tail': txt[-800:]}
(base/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(summary, ensure_ascii=False, indent=2)[:4000])
PYBT
