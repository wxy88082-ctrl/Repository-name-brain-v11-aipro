#!/usr/bin/env bash
set -euo pipefail
cd /root/brain
source .demo.env || true
export TRADING_MODE=paper
export BACKTEST_OFFLINE_ONLY=1
export NO_API_FALLBACK=1
export BACKTEST_START=${BACKTEST_START:-2025-01-01}
export BACKTEST_END=${BACKTEST_END:-2025-01-31}
export BACKTEST_LIMIT=${BACKTEST_SMOKE_LIMIT:-5000}
export V6_BACKTEST_SMOKE=1
mkdir -p /root/brain/backtest_v6_smoke_ws
python3 bt_analyze.py 2>&1 | tee /root/brain/backtest_v6_smoke_ws/bt_v6_smoke.log
