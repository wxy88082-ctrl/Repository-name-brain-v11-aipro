
# -*- coding: utf-8 -*-
"""V6 dashboard helpers for compact trade/history rendering and realized-PnL de-dup."""
from __future__ import annotations

import html
import json
import os
from pathlib import Path
from datetime import datetime, timezone, timedelta
from collections import OrderedDict

ROOT = Path(os.environ.get("BRAIN_ROOT", "/root/brain"))
DATA_DIR = ROOT / "brain_demo_data"


def _load_json(name, default):
    p = DATA_DIR / name
    try:
        if not p.exists() or p.stat().st_size == 0:
            return default
        return json.loads(p.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return default


def _as_list(x):
    if isinstance(x, list):
        return x
    if isinstance(x, dict):
        for k in ("items", "rows", "trades", "data", "recent_trades", "closed_trades", "history", "records"):
            v = x.get(k)
            if isinstance(v, list):
                return v
        out = []
        for v in x.values():
            if isinstance(v, list):
                out.extend(v)
            elif isinstance(v, dict):
                out.append(v)
        return out
    return []


def _first(d, names, default=""):
    if not isinstance(d, dict):
        return default
    for n in names:
        if n in d and d.get(n) not in (None, ""):
            return d.get(n)
    lower = {str(k).lower(): k for k in d.keys()}
    for n in names:
        k = lower.get(str(n).lower())
        if k is not None and d.get(k) not in (None, ""):
            return d.get(k)
    return default


def _num(v, default=0.0):
    try:
        if v in (None, "", "-"):
            return default
        return float(str(v).replace(",", ""))
    except Exception:
        return default


def _ts_ms(v):
    if v in (None, ""):
        return 0
    try:
        f = float(v)
        if f > 1e12:
            return int(f)
        if f > 1e9:
            return int(f * 1000)
        return int(f)
    except Exception:
        pass
    s = str(v)
    try:
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp() * 1000)
    except Exception:
        return 0


def fmt_time(v):
    ms = _ts_ms(v)
    if not ms:
        return "—"
    dt = datetime.fromtimestamp(ms / 1000, timezone.utc) + timedelta(hours=8)
    return dt.strftime("%m-%d %H:%M CST")


def fmt_num(v, signed=False):
    f = _num(v, None)
    if f is None:
        return "—"
    if abs(f) >= 1000:
        s = f"{f:,.2f}"
    elif abs(f) >= 1:
        s = f"{f:.4f}".rstrip("0").rstrip(".")
    else:
        s = f"{f:.8f}".rstrip("0").rstrip(".")
    if signed and f > 0:
        s = "+" + s
    return s


def _trade_rows_raw():
    return _as_list(_load_json("exchange_trade_history.json", []))


def _income_rows_raw():
    return _as_list(_load_json("exchange_income_history.json", []))


def _event_type(row):
    val = str(_first(row, ["event", "type", "event_type", "side_effect", "incomeType"], "")).upper()
    if "REALIZED" in val or "CLOSE" in val or "平仓" in val or "结算" in val:
        return "平仓/结算"
    if "OPEN" in val or "开仓" in val:
        return "开仓"
    if "TRADE" in val or "成交" in val:
        return "成交"
    return val or "成交"


def compact_recent_trades(limit=30):
    out = []
    seen = set()
    for r in _trade_rows_raw():
        if not isinstance(r, dict):
            continue
        symbol = str(_first(r, ["symbol", "s"], "—"))
        t = _first(r, ["time", "ts", "timestamp", "updateTime", "T"], "")
        order_id = str(_first(r, ["orderId", "order_id", "orderID", "i"], ""))
        trade_id = str(_first(r, ["tradeId", "id", "trade_id", "t"], ""))
        key = (symbol, order_id, trade_id, _ts_ms(t), _event_type(r))
        if key in seen:
            continue
        seen.add(key)
        out.append({
            "time_fmt": fmt_time(t),
            "event": _event_type(r),
            "symbol": symbol,
            "side": str(_first(r, ["side", "direction", "positionSide", "S"], "")),
            "price": _first(r, ["price", "avgPrice", "p"], ""),
            "qty": _first(r, ["qty", "quantity", "executedQty", "q"], ""),
            "realized_pnl": _first(r, ["realizedPnl", "realized_pnl", "rp", "income", "pnl"], ""),
            "commission": _first(r, ["commission", "fee", "commissionAmount"], ""),
            "wallet": _first(r, ["walletBalance", "wallet_balance", "balance", "钱包余额"], ""),
            "equity": _first(r, ["equity", "marginBalance", "total_equity", "总权益"], ""),
            "order_id": order_id,
            "sort_ts": _ts_ms(t),
        })
    out.sort(key=lambda x: x.get("sort_ts") or 0, reverse=True)
    return out[:limit]


def dedup_closed_pnl(limit=24):
    income_rows = []
    for r in _income_rows_raw():
        if not isinstance(r, dict):
            continue
        typ = str(_first(r, ["incomeType", "type", "event"], "")).upper()
        pnl = _num(_first(r, ["income", "realizedPnl", "realized_pnl", "pnl"], ""), 0.0)
        if "REALIZED" not in typ and abs(pnl) < 1e-12:
            continue
        symbol = str(_first(r, ["symbol", "asset"], "—"))
        t = _first(r, ["time", "ts", "timestamp", "tranTime"], "")
        order_id = str(_first(r, ["orderId", "order_id", "tranId", "id"], ""))
        sec = _ts_ms(t) // 1000 if _ts_ms(t) else 0
        key = ("income", symbol, order_id or sec, round(pnl, 10))
        income_rows.append((key, {
            "time_fmt": fmt_time(t),
            "symbol": symbol,
            "direction": str(_first(r, ["side", "direction", "positionSide"], "")),
            "realized_pnl": pnl,
            "commission": _first(r, ["commission", "fee", "commissionAmount"], ""),
            "wallet": _first(r, ["walletBalance", "wallet_balance", "balance", "钱包余额"], ""),
            "equity": _first(r, ["equity", "marginBalance", "total_equity", "总权益"], ""),
            "order_id": order_id,
            "source": "income",
            "sort_ts": _ts_ms(t),
        }))

    ordered = OrderedDict()
    for key, rec in sorted(income_rows, key=lambda x: x[1].get("sort_ts") or 0, reverse=True):
        if key not in ordered:
            ordered[key] = rec

    if not ordered:
        for r in _trade_rows_raw():
            if not isinstance(r, dict):
                continue
            pnl = _num(_first(r, ["realizedPnl", "realized_pnl", "rp", "pnl"], ""), 0.0)
            if abs(pnl) < 1e-12:
                continue
            symbol = str(_first(r, ["symbol", "s"], "—"))
            t = _first(r, ["time", "ts", "timestamp", "T"], "")
            order_id = str(_first(r, ["orderId", "order_id", "i"], ""))
            trade_id = str(_first(r, ["tradeId", "id", "t"], ""))
            key = ("trade", symbol, order_id, trade_id, round(pnl, 10))
            if key in ordered:
                continue
            ordered[key] = {
                "time_fmt": fmt_time(t),
                "symbol": symbol,
                "direction": str(_first(r, ["side", "direction", "positionSide", "S"], "")),
                "realized_pnl": pnl,
                "commission": _first(r, ["commission", "fee", "commissionAmount"], ""),
                "wallet": _first(r, ["walletBalance", "wallet_balance", "balance"], ""),
                "equity": _first(r, ["equity", "marginBalance", "total_equity"], ""),
                "order_id": order_id,
                "source": "trade_fallback",
                "sort_ts": _ts_ms(t),
            }

    records = list(ordered.values())
    records.sort(key=lambda x: x.get("sort_ts") or 0, reverse=True)
    return records[:limit]


def _esc(x):
    return html.escape(str(x if x is not None else ""))


def _pnl_class(v):
    return "good" if _num(v, 0.0) >= 0 else "bad"


def render_recent_trades_html(limit_preview=5, limit_full=30):
    rows = compact_recent_trades(limit_full)
    if not rows:
        return '<div class="card"><h2>📋 最近成交</h2><div class="muted">暂无成交记录</div></div>'

    def tr(r):
        return ("<tr>"
                f"<td>{_esc(r['time_fmt'])}</td>"
                f"<td>{_esc(r['event'])}</td>"
                f"<td><b>{_esc(r['symbol'])}</b></td>"
                f"<td>{_esc(r['side'])}</td>"
                f"<td>{_esc(fmt_num(r['price']))}</td>"
                f"<td>{_esc(fmt_num(r['qty']))}</td>"
                f"<td class='{_pnl_class(r['realized_pnl'])}'>{_esc(fmt_num(r['realized_pnl'], signed=True))}</td>"
                f"<td>{_esc(fmt_num(r['commission']))}</td>"
                f"<td>{_esc(fmt_num(r['wallet']))}</td>"
                f"<td>{_esc(fmt_num(r['equity']))}</td>"
                "</tr>")

    preview = "".join(tr(r) for r in rows[:limit_preview])
    full = "".join(tr(r) for r in rows[limit_preview:])
    extra = ""
    if full:
        extra = f"<details class='v6-details'><summary>展开更多成交（{len(rows)-limit_preview} 条）</summary><table><tbody>{full}</tbody></table></details>"
    return f"""
    <div class="card v6-card">
      <h2>📋 最近成交</h2>
      <div class="muted">默认显示最近 {min(limit_preview, len(rows))} 条，展开查看更多。</div>
      <div class="table-wrap"><table>
        <thead><tr><th>时间</th><th>事件</th><th>币对</th><th>方向</th><th>价格</th><th>数量</th><th>已实现盈亏</th><th>手续费</th><th>钱包余额</th><th>总权益</th></tr></thead>
        <tbody>{preview}</tbody>
      </table></div>
      {extra}
    </div>
    """


def render_position_history_html(limit_preview=5, limit_full=24):
    rows = dedup_closed_pnl(limit_full)
    total = sum(_num(r.get("realized_pnl"), 0.0) for r in rows)
    total_cls = "good" if total >= 0 else "bad"
    if not rows:
        return '<div class="card"><h2>📚 持仓历史 / 平仓盈亏</h2><div class="muted">暂无去重后的平仓盈亏记录</div></div>'

    def tr(r):
        return ("<tr>"
                f"<td>{_esc(r['time_fmt'])}</td>"
                f"<td><b>{_esc(r['symbol'])}</b></td>"
                f"<td>{_esc(r.get('direction',''))}</td>"
                f"<td class='{_pnl_class(r['realized_pnl'])}'>{_esc(fmt_num(r['realized_pnl'], signed=True))}</td>"
                f"<td>{_esc(fmt_num(r.get('commission')))}</td>"
                f"<td>{_esc(fmt_num(r.get('wallet')))}</td>"
                f"<td>{_esc(fmt_num(r.get('equity')))}</td>"
                f"<td>{_esc(r.get('order_id',''))}</td>"
                "</tr>")

    preview = "".join(tr(r) for r in rows[:limit_preview])
    full = "".join(tr(r) for r in rows[limit_preview:])
    extra = ""
    if full:
        extra = f"<details class='v6-details'><summary>展开更多平仓记录（{len(rows)-limit_preview} 条）</summary><table><tbody>{full}</tbody></table></details>"
    return f"""
    <div class="card v6-card">
      <h2>📚 持仓历史 / 平仓盈亏</h2>
      <div class="muted">去重后最近 {len(rows)} 条平仓/结算记录；合计已实现盈亏：<span class="{total_cls}">{fmt_num(total, signed=True)} USDT</span></div>
      <div class="table-wrap"><table>
        <thead><tr><th>时间</th><th>币对</th><th>方向</th><th>已实现盈亏</th><th>手续费</th><th>钱包余额</th><th>总权益</th><th>订单ID</th></tr></thead>
        <tbody>{preview}</tbody>
      </table></div>
      {extra}
    </div>
    """


def write_dedup_snapshot():
    rows = dedup_closed_pnl(500)
    out = DATA_DIR / "exchange_position_history_v6_dedup.json"
    try:
        out.write_text(json.dumps({"records": rows, "total_realized_pnl": sum(_num(r.get("realized_pnl"),0) for r in rows)}, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass
    return rows

if __name__ == "__main__":
    rows = write_dedup_snapshot()
    print(json.dumps({"dedup_closed_count": len(rows), "total_realized_pnl": sum(_num(r.get("realized_pnl"),0) for r in rows)}, ensure_ascii=False, indent=2))
