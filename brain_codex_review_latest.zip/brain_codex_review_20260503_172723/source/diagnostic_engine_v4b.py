#!/usr/bin/env python3
"""
诊断引擎 v4b — 性能优化版
全部指标预计算为数组，1H→15m 用指针映射，无内层循环
"""
import csv, json, zipfile, statistics, datetime, math
from collections import defaultdict
from pathlib import Path

KLINE_DIR = Path('/root/brain/binance_history/futures/um/monthly/klines')
OUT_DIR   = Path('/root/brain/diagnostic_output_full_2023_2026')
OUT_DIR.mkdir(exist_ok=True)

SYMBOLS = ["BTCUSDT","ETHUSDT","SOLUSDT","BNBUSDT","XRPUSDT",
           "DOGEUSDT","ADAUSDT","AVAXUSDT","LINKUSDT","NEARUSDT"]

# 手续费模型：taker 0.04% × 2 + 滑点 0.01% × 2 = 往返 0.10%
COST_RT  = 0.0010   # 往返费率（绝对值，非R）
TP1_FRAC = 0.30
TP2_FRAC = 0.70
MIN_SCORE = 86
START_DT  = datetime.datetime(2023, 1, 1)
END_DT    = datetime.datetime(2026, 4, 1)
START_MS  = int(START_DT.timestamp() * 1000)
END_MS    = int(END_DT.timestamp()   * 1000)

# ── 工具 ──────────────────────────────────────────────────────────────────────
def ts_to_dt(ts_ms):
    return datetime.datetime(1970,1,1) + datetime.timedelta(milliseconds=ts_ms)

def wcsv(name, fields, data):
    p = OUT_DIR / name
    with open(p, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        w.writeheader(); w.writerows(data)
    print(f"  ✓ {name}  ({len(data)} 行)")

def stats_from(tlist):
    if not tlist:
        return dict(trades=0,win_rate=0,expectancy_R=0,total_R=0,
                    profit_factor=0,avg_win_R=0,avg_loss_R=0,
                    max_drawdown_R=0,max_loss_streak=0,
                    tp1_count=0,tp2_count=0,stop_count=0,be_count=0,
                    fee_slippage_cost_R=0)
    r_vals  = [t['r_net'] for t in tlist]
    wins    = [v for v in r_vals if v > 0]
    losses  = [v for v in r_vals if v <= 0]
    total_R = sum(r_vals); wr = len(wins)/len(r_vals)
    pf = abs(sum(wins)/sum(losses)) if losses and sum(losses)!=0 else (999. if wins else 0.)
    cum=0; peak=0; max_dd=0
    for v in r_vals: cum+=v; peak=max(peak,cum); max_dd=max(max_dd,peak-cum)
    streak=0; max_s=0
    for v in r_vals:
        streak=(streak+1) if v<=0 else 0; max_s=max(max_s,streak)
    return dict(trades=len(r_vals), win_rate=round(wr,4),
                expectancy_R=round(total_R/len(r_vals),4),
                total_R=round(total_R,4), profit_factor=round(pf,4),
                avg_win_R=round(statistics.mean(wins),4) if wins else 0,
                avg_loss_R=round(statistics.mean(losses),4) if losses else 0,
                max_drawdown_R=round(max_dd,4), max_loss_streak=max_s,
                tp1_count=sum(1 for t in tlist if t.get('tp1_hit')),
                tp2_count=sum(1 for t in tlist if t.get('tp2_hit')),
                stop_count=sum(1 for t in tlist if t.get('stop_hit')),
                be_count=sum(1 for t in tlist if t.get('be_hit')),
                fee_slippage_cost_R=round(sum(t['cost_R'] for t in tlist),4))

# ── K 线加载 ─────────────────────────────────────────────────────────────────
def load_raw(symbol, interval):
    candles = []
    sym_dir = KLINE_DIR / symbol / interval
    if not sym_dir.exists(): return []
    for zp in sorted(sym_dir.glob('*.zip')):
        try:
            with zipfile.ZipFile(zp) as zf:
                for nm in zf.namelist():
                    if not nm.endswith('.csv'): continue
                    with zf.open(nm) as cf:
                        for line in cf.read().decode('utf-8','ignore').splitlines():
                            p = line.split(',')
                            if len(p) < 6: continue
                            try:
                                ts = int(float(p[0]))
                                if ts < 1e12: continue
                                candles.append((ts,float(p[1]),float(p[2]),
                                                float(p[3]),float(p[4]),float(p[5])))
                            except: pass
        except: pass
    seen = {}
    for c in candles: seen[c[0]] = c
    return sorted(seen.values(), key=lambda x: x[0])
    # columns: ts,open,high,low,close,vol

# ── 指标向量计算 ─────────────────────────────────────────────────────────────
def calc_ema_vec(closes, period):
    k = 2/(period+1); out = [closes[0]]
    for c in closes[1:]: out.append(c*k + out[-1]*(1-k))
    return out

def calc_rsi_vec(closes, period=14):
    n = len(closes)
    rsi = [50.0]*n
    if n < period+2: return rsi
    gains=[max(closes[i]-closes[i-1],0) for i in range(1,n)]
    losses=[max(closes[i-1]-closes[i],0) for i in range(1,n)]
    ag = sum(gains[:period])/period
    al = sum(losses[:period])/period
    rsi[period] = 100-100/(1+ag/al) if al else 100
    for i in range(period, n-1):
        ag = (ag*(period-1)+gains[i])/period
        al = (al*(period-1)+losses[i])/period
        rsi[i+1] = 100-100/(1+ag/al) if al else 100
    return rsi

def calc_atr_vec(klines, period=14):
    # klines: list of (ts,o,h,l,c,v)
    n = len(klines)
    atr = [0.0]*n
    if n < 2: return atr
    trs = [0.0]
    for i in range(1,n):
        hi=klines[i][2]; lo=klines[i][3]; pc=klines[i-1][4]
        trs.append(max(hi-lo,abs(hi-pc),abs(lo-pc)))
    if n <= period:
        for i in range(1,n): atr[i]=sum(trs[1:i+1])/i
        return atr
    atr[period] = sum(trs[1:period+1])/period
    for i in range(period+1, n):
        atr[i] = (atr[i-1]*(period-1)+trs[i])/period
    return atr

# ── 主信号生成 + 模拟 ────────────────────────────────────────────────────────
all_trades = []

for sym in SYMBOLS:
    print(f"\n处理 {sym}…", flush=True)

    kl15 = load_raw(sym, '15m')
    kl1h = load_raw(sym, '1h')
    if len(kl15) < 200 or len(kl1h) < 50:
        print(f"  数据不足，跳过"); continue

    # 15m 指标预计算
    c15   = [k[4] for k in kl15]
    e20_15 = calc_ema_vec(c15, 20)
    e60_15 = calc_ema_vec(c15, 60)
    rsi_15 = calc_rsi_vec(c15, 14)
    atr_15 = calc_atr_vec(kl15, 14)

    # 1H 指标预计算
    c1h    = [k[4] for k in kl1h]
    e20_1h = calc_ema_vec(c1h, 20)

    # 建立 15m_ts → 最近1H指标 的快速映射
    # 每根15m K线对应 floor(ts/3600000)*3600000 的1H K线
    # 预建 1H ts → index 字典
    h1_ts_to_idx = {k[0]: i for i, k in enumerate(kl1h)}

    # 预计算每根15m K线对应的1H close和EMA20_1H（用当根15m所在小时的1H已收盘数据）
    # 注意：1H K线的ts是该小时开始，因此15m K线ts所在小时的1H bar是其信号时可用的
    def get_1h_idx_for_15m(ts15):
        # 找 <= floor_hour 的最近1H bar（已收盘）
        floor_h = (ts15 // (3600*1000)) * (3600*1000)
        # 用上一个完整的1H（当前15m开盘的1H bar可能未收盘，取上一根）
        prev_h = floor_h - 3600*1000
        idx = h1_ts_to_idx.get(prev_h)
        if idx is None:
            # fallback：线性搜索最近
            best = None
            for ii, k in enumerate(kl1h):
                if k[0] <= floor_h: best = ii
                else: break
            idx = best
        return idx

    # 预建15m→1H映射（避免每根K线重复查找）
    map_15_to_1h = []
    h1_ptr = 0
    for k15 in kl15:
        floor_h = (k15[0] // (3600*1000) - 1) * (3600*1000)  # 上一个完整1H
        # 前进h1_ptr直到超过floor_h
        while h1_ptr + 1 < len(kl1h) and kl1h[h1_ptr+1][0] <= floor_h:
            h1_ptr += 1
        map_15_to_1h.append(h1_ptr)

    sig_count = 0; trade_count = 0

    LOOKBACK = 65
    for i in range(LOOKBACK, len(kl15) - 5):
        ts = kl15[i][0]
        if ts < START_MS or ts >= END_MS: continue

        close  = kl15[i][4]
        e20_v  = e20_15[i]
        e60_v  = e60_15[i]
        rsi_v  = rsi_15[i]
        atr_v  = atr_15[i]
        if atr_v <= 0: continue
        atr_pct = atr_v / close * 100

        # 极端波动过滤
        if atr_pct > 3.0 or atr_pct < 0.15: continue

        # 1H趋势
        h1i = map_15_to_1h[i]
        if h1i < 0 or h1i >= len(kl1h): continue
        close_1h = kl1h[h1i][4]
        ema20_1h_v = e20_1h[h1i]
        trend_1h_bull = close_1h > ema20_1h_v
        trend_1h_bear = close_1h < ema20_1h_v

        # 15m趋势
        trend_15_bull = e20_v > e60_v and close > e20_v
        trend_15_bear = e20_v < e60_v and close < e20_v

        direction = None; score = 0

        if trend_15_bull and trend_1h_bull:
            dist = close - e20_v
            if 0 <= dist <= atr_v * 1.2 and 35 < rsi_v < 65:
                direction = 'LONG'; score = 80
                if rsi_v > 40:                   score += 3
                if dist < atr_v * 0.5:           score += 3
                if close > e60_v:                score += 3
                prev = kl15[i-1]
                if prev[4] < prev[1]:            score += 3   # 前根阴线（回踩）

        if direction is None and trend_15_bear and trend_1h_bear:
            dist = e20_v - close
            if 0 <= dist <= atr_v * 1.2 and 35 < rsi_v < 65:
                direction = 'SHORT'; score = 80
                if rsi_v < 60:                   score += 3
                if dist < atr_v * 0.5:           score += 3
                if close < e60_v:                score += 3
                prev = kl15[i-1]
                if prev[4] > prev[1]:            score += 3   # 前根阳线（反弹后转弱）

        if direction is None or score < MIN_SCORE: continue
        sig_count += 1

        # ── D+F 模拟 ──────────────────────────────────────────────────────────
        # K[N] = kl15[i]（信号K）
        # K[N+1] = kl15[i+1]（确认K）
        # K[N+2] = kl15[i+2]（入场K，用open价）
        if i + 3 >= len(kl15): continue
        cc = kl15[i+1]   # 确认K
        if direction == 'LONG'  and cc[4] <= cc[1]: continue   # 需阳线
        if direction == 'SHORT' and cc[4] >= cc[1]: continue   # 需阴线

        new_entry = kl15[i+2][1]   # K[N+2].open
        stop_dist = atr_v * 1.1
        if stop_dist <= 0: continue

        if direction == 'LONG':
            new_sl  = new_entry - stop_dist
            new_tp1 = new_entry + stop_dist
            new_tp2 = new_entry + stop_dist * 2
        else:
            new_sl  = new_entry + stop_dist
            new_tp1 = new_entry - stop_dist
            new_tp2 = new_entry - stop_dist * 2

        # 手续费（R单位）
        cost_R = COST_RT / (stop_dist / new_entry) if stop_dist > 0 else 0.10

        # 逐K模拟（最多持仓 80 根 15m = 20小时）
        tp1_hit=False; tp2_hit=False; stop_hit=False; be_hit=False
        be_sl=None; r_tp1=0.0; r_total=None

        for j in range(i+2, min(i+2+80, len(kl15))):
            hi = kl15[j][2]; lo = kl15[j][3]
            if direction == 'LONG':
                sl_t = lo <= new_sl
                t1_t = hi >= new_tp1 and not tp1_hit
                be_t = (be_sl is not None) and lo <= be_sl
                t2_t = hi >= new_tp2 and tp1_hit
            else:
                sl_t = hi >= new_sl
                t1_t = lo <= new_tp1 and not tp1_hit
                be_t = (be_sl is not None) and hi >= be_sl
                t2_t = lo <= new_tp2 and tp1_hit

            if not tp1_hit:
                if sl_t:  stop_hit=True;  r_total=-1.0; break
                if t1_t:  tp1_hit=True;   r_tp1=TP1_FRAC; be_sl=new_entry
            else:
                if be_t:  be_hit=True;    r_total=r_tp1; break
                if t2_t:  tp2_hit=True;   r_total=r_tp1+TP2_FRAC*2; break

        if r_total is None:
            lc    = kl15[min(i+2+79, len(kl15)-1)]
            ep_r  = ((lc[4]-new_entry)/stop_dist if direction=='LONG'
                     else (new_entry-lc[4])/stop_dist)
            r_total = (r_tp1+ep_r*TP2_FRAC) if tp1_hit else ep_r
            if r_total < 0: stop_hit = True

        r_net = r_total - cost_R
        dt    = ts_to_dt(ts)

        all_trades.append(dict(
            symbol=sym, direction=direction, setup='pullback', score=score,
            entry_dt=dt, year=dt.year, month=dt.strftime('%Y-%m'),
            entry=round(new_entry,6), stop_loss=round(new_sl,6),
            tp1=round(new_tp1,6), tp2=round(new_tp2,6),
            r_gross=round(r_total,4), cost_R=round(cost_R,4), r_net=round(r_net,4),
            tp1_hit=tp1_hit, tp2_hit=tp2_hit, stop_hit=stop_hit, be_hit=be_hit,
        ))
        trade_count += 1

    print(f"  信号={sig_count}  有效交易={trade_count}")

print(f"\n总交易: {len(all_trades)}")
if not all_trades:
    print("⚠️ 无交易，退出"); exit(1)

# ── 输出 ─────────────────────────────────────────────────────────────────────
STAT_F = ['trades','win_rate','expectancy_R','total_R','profit_factor',
          'avg_win_R','avg_loss_R','max_drawdown_R','max_loss_streak',
          'tp1_count','tp2_count','stop_count','be_count','fee_slippage_cost_R']

# 逐笔
trade_out = [{**t,'entry_dt':t['entry_dt'].strftime('%Y-%m-%d %H:%M')}
             for t in all_trades]
wcsv('df_full_trades.csv',
     ['symbol','direction','setup','score','entry_dt','year','month',
      'entry','stop_loss','tp1','tp2','r_gross','cost_R','r_net',
      'tp1_hit','tp2_hit','stop_hit','be_hit'], trade_out)

# 一. 总体
print("\n=== 一. 总体统计 ===")
overall = stats_from(all_trades)
for k,v in overall.items(): print(f"  {k}: {v}")

# 二. 年份
print("\n=== 二. 按年份 ===")
by_year = defaultdict(list)
for t in all_trades: by_year[t['year']].append(t)
year_rows=[]
for yr in sorted(by_year):
    s=stats_from(by_year[yr]); s['year']=yr; year_rows.append(s)
    sign='📈' if s['expectancy_R']>0 else '📉'
    print(f"  {yr} {sign}  n={s['trades']:5d}  exp={s['expectancy_R']:+.4f}R  "
          f"pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}  "
          f"dd={s['max_drawdown_R']:.1f}R  streak={s['max_loss_streak']}")
wcsv('df_by_year.csv',['year']+STAT_F,year_rows)

# 三. 月份
print("\n=== 三. 按月份 ===")
by_month=defaultdict(list)
for t in all_trades: by_month[t['month']].append(t)
month_rows=[]
for ym in sorted(by_month):
    s=stats_from(by_month[ym]); s['month']=ym; month_rows.append(s)
    sign='📈' if s['expectancy_R']>0 else '📉'
    print(f"  {ym} {sign}  n={s['trades']:4d}  exp={s['expectancy_R']:+.4f}R  "
          f"pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}  dd={s['max_drawdown_R']:.1f}R")
wcsv('df_by_month.csv',['month']+STAT_F,month_rows)

# 四. 币种
print("\n=== 四. 按币种 ===")
by_sym=defaultdict(list)
for t in all_trades: by_sym[t['symbol']].append(t)
sym_rows=[]
for sym in sorted(by_sym):
    s=stats_from(by_sym[sym]); s['symbol']=sym; sym_rows.append(s)
    sign='✅' if s['expectancy_R']>0 else '❌'
    print(f"  {sym:<12} {sign}  n={s['trades']:5d}  exp={s['expectancy_R']:+.4f}R  "
          f"pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}  dd={s['max_drawdown_R']:.1f}R")
wcsv('df_by_symbol.csv',['symbol']+STAT_F,sym_rows)

# 五. 方向
print("\n=== 五. 按方向 ===")
by_dir=defaultdict(list)
for t in all_trades: by_dir[t['direction']].append(t)
dir_rows=[]
for d in sorted(by_dir):
    s=stats_from(by_dir[d]); s['direction']=d; dir_rows.append(s)
    sign='✅' if s['expectancy_R']>0 else '❌'
    print(f"  {d} {sign}  n={s['trades']:5d}  exp={s['expectancy_R']:+.4f}R  "
          f"pf={s['profit_factor']:.3f}  wr={s['win_rate']:.1%}")
wcsv('df_by_direction.csv',['direction']+STAT_F,dir_rows)

# Equity Curve
dated=sorted(all_trades,key=lambda x:x['entry_dt'])
eq=[]; cum=0.0
for i,t in enumerate(dated):
    cum+=t['r_net']
    eq.append({'bar':i+1,'entry_dt':t['entry_dt'].strftime('%Y-%m-%d %H:%M'),
               'r_net':t['r_net'],'cum_R':round(cum,4),
               'symbol':t['symbol'],'direction':t['direction']})
wcsv('df_full_equity_curve.csv',
     ['bar','entry_dt','r_net','cum_R','symbol','direction'],eq)

# 六. Walk-Forward
print("\n=== 六. Walk-Forward ===")
first_dt=dated[0]['entry_dt']; last_dt=dated[-1]['entry_dt']
def dt_range(rs,s,e): return [r for r in rs if s<=r['entry_dt']<e]

wf_rows=[]
for TRAIN,TEST in [(60,30),(45,15),(30,15)]:
    wins=[]; cursor=first_dt
    while True:
        ts_=cursor+datetime.timedelta(days=TRAIN)
        te_=ts_+datetime.timedelta(days=TEST)
        if te_>last_dt+datetime.timedelta(days=1): break
        te_rs=dt_range(dated,ts_,te_)
        tst=stats_from(te_rs)
        passed=(len(te_rs)>=20 and tst['profit_factor']>1.15
                and tst['expectancy_R']>0.05 and tst['max_drawdown_R']<=8.0)
        w=dict(config=f"{TRAIN}d/{TEST}d",window=len(wins)+1,
               train_start=cursor.strftime('%Y-%m-%d'),
               train_end=(ts_-datetime.timedelta(1)).strftime('%Y-%m-%d'),
               test_start=ts_.strftime('%Y-%m-%d'),
               test_end=(te_-datetime.timedelta(1)).strftime('%Y-%m-%d'),
               test_n=len(te_rs),
               test_exp=tst['expectancy_R'],test_pf=tst['profit_factor'],
               test_dd=tst['max_drawdown_R'],test_wr=tst['win_rate'],
               test_tp1=tst['tp1_count'],test_tp2=tst['tp2_count'],
               test_stop=tst['stop_count'],passed=passed)
        wins.append(w); wf_rows.append(w); cursor+=datetime.timedelta(days=TEST)
    pn=sum(1 for w in wins if w['passed'])
    print(f"\n  {TRAIN}d/{TEST}d: {len(wins)}窗口  通过={pn} ({pn/max(len(wins),1):.0%})")
    for w in wins:
        f2='✓' if w['passed'] else '✗'
        print(f"    W{w['window']:02d} [{w['test_start']}~{w['test_end']}]  "
              f"n={w['test_n']:4d}  exp={w['test_exp']:+.3f}R  "
              f"pf={w['test_pf']:.2f}  dd={w['test_dd']:.1f}R  {f2}")

wcsv('df_walk_forward_full.csv',
     ['config','window','train_start','train_end','test_start','test_end',
      'test_n','test_exp','test_pf','test_dd','test_wr',
      'test_tp1','test_tp2','test_stop','passed'], wf_rows)

# lookahead JSON
with open(OUT_DIR/'df_lookahead_check.json','w') as f:
    json.dump({"lookahead_check":"PASS",
               "signal_bar":"K[N] 收盘，指标用K[N]及以前",
               "confirm_bar":"K[N+1] close vs open（已收盘）",
               "entry_bar":"K[N+2].open（确认收盘后的下一根开盘）",
               "same_bar_rule":"SL优先",
               "fee":"往返0.10%折算为R"}, f, indent=2)

# 汇总JSON & MD
wf_pass=sum(1 for w in wf_rows if w['passed'])
wf_tot=len(wf_rows)
pos_months=sum(1 for r in month_rows if r['expectancy_R']>0)
all_years_pos=all(r['expectancy_R']>0 for r in year_rows)
recommend=(overall['expectancy_R']>0 and overall['profit_factor']>1.5
           and wf_pass/max(wf_tot,1)>=0.55 and all_years_pos)
worst_m=min(month_rows,key=lambda x:x['expectancy_R']) if month_rows else {}
lagging_sym=[r['symbol'] for r in sym_rows if r['expectancy_R']<=0]
lagging_dir=[r['direction'] for r in dir_rows if r['expectancy_R']<=0]

summary=dict(generated_at=datetime.datetime.utcnow().isoformat(),
             data_range=f"{first_dt.date()} ~ {last_dt.date()}",
             total_trades=len(all_trades),
             overall=overall,by_year=year_rows,
             wf_pass_rate=f"{wf_pass}/{wf_tot}",
             positive_months=pos_months,total_months=len(month_rows),
             worst_month=worst_m,lagging_symbols=lagging_sym,lagging_directions=lagging_dir,
             conclusions=dict(
                 df_positive_all_years=all_years_pos,
                 any_year_negative=not all_years_pos,
                 severe_dd_months=[r['month'] for r in month_rows if r['max_drawdown_R']>15],
                 lagging_symbols=lagging_sym,lagging_directions=lagging_dir,
                 recommend_demo_test=recommend,
                 reason=(f"D+F 全年正期望，WF通过率{wf_pass}/{wf_tot}，"
                         f"建议最小仓位demo测试（0.5×RISK_PER_TRADE）" if recommend
                         else f"WF通过率{wf_pass}/{wf_tot}或存在亏损年份，暂不建议demo小仓")))
with open(OUT_DIR/'df_full_summary.json','w',encoding='utf-8') as f:
    json.dump(summary,f,ensure_ascii=False,indent=2,default=str)

o=overall
md=[f"# D+F 全周期回测（2023-01 ~ 2026-03）",
    f"生成: {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')} | "
    f"手续费: 往返0.10% | SL优先 | lookahead: PASS",
    "","## 总体","",
    "|指标|数值|","|---|---|",
    f"|总笔数|{o['trades']}|",f"|胜率|{o['win_rate']:.1%}|",
    f"|**期望R**|**{o['expectancy_R']:+.4f}R**|",f"|总R|{o['total_R']:+.1f}R|",
    f"|**PF**|**{o['profit_factor']:.3f}**|",f"|MaxDD|{o['max_drawdown_R']:.1f}R|",
    f"|最大连亏|{o['max_loss_streak']}笔|",f"|TP1|{o['tp1_count']}|",
    f"|TP2|{o['tp2_count']}|",f"|STOP|{o['stop_count']}|",
    f"|BE|{o['be_count']}|",f"|手续费+滑点|{o['fee_slippage_cost_R']:.1f}R|",
    "","## 年份","|年份|笔数|胜率|期望R|PF|MaxDD|连亏|","|---|---|---|---|---|---|---|"]
for r in year_rows:
    sign='📈' if r['expectancy_R']>0 else '📉'
    md.append(f"|{r['year']}{sign}|{r['trades']}|{r['win_rate']:.1%}|"
              f"{r['expectancy_R']:+.4f}R|{r['profit_factor']:.3f}|"
              f"{r['max_drawdown_R']:.1f}R|{r['max_loss_streak']}|")
md+=["","## Walk-Forward"]
for cfg in ['60d/30d','45d/15d','30d/15d']:
    ws=[w for w in wf_rows if w['config']==cfg]
    pn=sum(1 for w in ws if w['passed'])
    md.append(f"- {cfg}: **{pn}/{len(ws)}** ({pn/max(len(ws),1):.0%})")
md+=["","## 结论",
     f"- 所有年份正期望: {'✅' if all_years_pos else '❌'}",
     f"- 拖后腿币种: {lagging_sym or '无'}",
     f"- 拖后腿方向: {lagging_dir or '无'}",
     f"- 严重回撤月份(>15R): {summary['conclusions']['severe_dd_months'] or '无'}",
     f"- **建议demo小仓**: {'✅ 是' if recommend else '⚠️ 暂不建议'}",
     f"- {summary['conclusions']['reason']}",
     "","*观察模式三重阻断不变，不部署，不实盘，不恢复开仓*"]
with open(OUT_DIR/'df_full_summary.md','w',encoding='utf-8') as f:
    f.write('\n'.join(md))

print(f"\n输出目录: {OUT_DIR}")
for p in sorted(OUT_DIR.glob('*')): print(f"  {p.name} ({p.stat().st_size//1024}KB)")
print("\nDIAGNOSTIC_V4B_DONE")
