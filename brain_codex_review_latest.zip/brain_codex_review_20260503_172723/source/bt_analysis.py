
import csv, math, json
from collections import defaultdict
from pathlib import Path

# ── 读取数据 ──────────────────────────────────────────────────────────────────
rows = []
for p in ['/root/brain/backtest_full_ws/backtest_trades.csv',
          '/root/brain/backtest_bt2_ws/backtest_trades.csv']:
    with open(p) as f:
        for r in csv.DictReader(f):
            r['r'] = float(r['r_multiple'])
            rows.append(r)

print(f"总笔数: {len(rows)}")

# ── 工具函数 ──────────────────────────────────────────────────────────────────
def stats(rs, label=""):
    if not rs:
        return
    n = len(rs)
    wins = [v for v in rs if v > 0]
    losses = [v for v in rs if v <= 0]
    win_rate = len(wins)/n*100
    exp = sum(rs)/n
    gross_p = sum(wins) if wins else 0
    gross_l = abs(sum(losses)) if losses else 0
    pf = gross_p/gross_l if gross_l > 0 else 999.0

    # MaxDD
    equity, peak, mdd = 0.0, 0.0, 0.0
    for v in rs:
        equity += v
        peak = max(peak, equity)
        mdd = max(mdd, peak - equity)

    # 最大连亏
    max_consec_loss, cur = 0, 0
    for v in rs:
        if v <= 0:
            cur += 1
            max_consec_loss = max(max_consec_loss, cur)
        else:
            cur = 0

    print(f"\n{'='*60}")
    print(f"  {label}  ({n}笔)")
    print(f"{'='*60}")
    print(f"  胜率:      {win_rate:.1f}%")
    print(f"  期望值:    {exp:+.4f}R")
    print(f"  PF:        {pf:.3f}")
    print(f"  MaxDD:     {mdd:.2f}R")
    print(f"  最大连亏:   {max_consec_loss}笔")
    return {"n":n,"wr":win_rate,"exp":exp,"pf":pf,"mdd":mdd,"max_loss_streak":max_consec_loss}

def exit_counts(subset):
    tp1 = sum(1 for r in subset if 'TP1' in r['reason'])
    tp2 = sum(1 for r in subset if 'TP2' in r['reason'])
    stop = sum(1 for r in subset if 'STOP' in r['reason'])
    be = sum(1 for r in subset if 'BE' in r['reason'] or 'breakeven' in r['reason'].lower())
    other = len(subset) - tp1 - tp2 - stop - be
    print(f"  TP1触发:  {tp1}  TP2触发: {tp2}  STOP: {stop}  BE: {be}  其他: {other}")

# ── 1. 按 setup 拆分 ─────────────────────────────────────────────────────────
print("\n" + "="*60)
print("  【1. 按 SETUP 拆分】")
for setup in ['pullback','trend','breakout']:
    subset = [r for r in rows if r['setup'] == setup]
    if not subset:
        print(f"\n  {setup}: 0笔")
        continue
    stats([r['r'] for r in subset], f"SETUP={setup}")
    exit_counts(subset)

# ── 2. pullback 详细分析 ─────────────────────────────────────────────────────
pb = [r for r in rows if r['setup'] == 'pullback']
pb_r = [r['r'] for r in pb]

print("\n\n" + "="*60)
print("  【2. PULLBACK 详细分析 (2665笔)】")
stats(pb_r, "PULLBACK 总体")
exit_counts(pb)

# 按币种
print("\n  -- 按币种 --")
sym_data = defaultdict(list)
for r in pb:
    sym_data[r['symbol']].append(r['r'])
for sym in sorted(sym_data, key=lambda s: sum(sym_data[s])/len(sym_data[s])):
    vals = sym_data[sym]
    exp = sum(vals)/len(vals)
    wr = sum(1 for v in vals if v>0)/len(vals)*100
    gp = sum(v for v in vals if v>0)
    gl = abs(sum(v for v in vals if v<0))
    pf = gp/gl if gl else 999
    print(f"  {sym:15s} {len(vals):4d}笔  期望={exp:+.4f}R  胜率={wr:.1f}%  PF={pf:.3f}")

# 按方向
print("\n  -- 按方向 --")
for direction in ['LONG','SHORT']:
    subset = [r for r in pb if r['direction'] == direction]
    if subset:
        vals = [r['r'] for r in subset]
        exp = sum(vals)/len(vals)
        wr = sum(1 for v in vals if v>0)/len(vals)*100
        gp = sum(v for v in vals if v>0)
        gl = abs(sum(v for v in vals if v<0))
        pf = gp/gl if gl else 999
        print(f"  {direction:6s}  {len(vals):4d}笔  期望={exp:+.4f}R  胜率={wr:.1f}%  PF={pf:.3f}")

# 按年份
print("\n  -- 按年份 --")
year_data = defaultdict(list)
for r in pb:
    try:
        # entry_time 是毫秒时间戳
        ts = int(r['entry_time'])
        import datetime
        year = datetime.datetime.utcfromtimestamp(ts/1000).year
        year_data[year].append(r['r'])
    except:
        year_data['unknown'].append(r['r'])
for yr in sorted(year_data):
    vals = year_data[yr]
    exp = sum(vals)/len(vals)
    wr = sum(1 for v in vals if v>0)/len(vals)*100
    print(f"  {yr}  {len(vals):4d}笔  期望={exp:+.4f}R  胜率={wr:.1f}%")

# 按月度（walk-forward 概览）
print("\n  -- 按月度 (walk-forward) --")
month_data = defaultdict(list)
for r in pb:
    try:
        ts = int(r['entry_time'])
        import datetime
        dt = datetime.datetime.utcfromtimestamp(ts/1000)
        month_data[f"{dt.year}-{dt.month:02d}"].append(r['r'])
    except:
        pass
cum = 0.0
for ym in sorted(month_data):
    vals = month_data[ym]
    mo_exp = sum(vals)/len(vals)
    mo_total = sum(vals)
    cum += mo_total
    wr = sum(1 for v in vals if v>0)/len(vals)*100
    print(f"  {ym}  {len(vals):3d}笔  月期望={mo_exp:+.4f}R  月总={mo_total:+.2f}R  累计={cum:+.2f}R  胜率={wr:.1f}%")

# ── 3. trend 单独分析 ────────────────────────────────────────────────────────
trend_rows = [r for r in rows if r['setup'] == 'trend']
trend_r = [r['r'] for r in trend_rows]
print("\n\n" + "="*60)
print("  【3. TREND 单独分析】")
stats(trend_r, "TREND 总体")
exit_counts(trend_rows)
# 量化 trend 对总结果的污染
all_r = [r['r'] for r in rows]
only_pb_bk = [r['r'] for r in rows if r['setup'] != 'trend']
print(f"\n  全量期望: {sum(all_r)/len(all_r):+.4f}R")
print(f"  去掉trend后期望: {sum(only_pb_bk)/len(only_pb_bk):+.4f}R")

# ── 4. breakout 分析 ────────────────────────────────────────────────────────
bk_rows = [r for r in rows if r['setup'] == 'breakout']
bk_r = [r['r'] for r in bk_rows]
print("\n\n" + "="*60)
print("  【4. BREAKOUT 分析】")
stats(bk_r, "BREAKOUT 总体")
exit_counts(bk_rows)

# ── 5. TP1修复验证 ───────────────────────────────────────────────────────────
print("\n\n" + "="*60)
print("  【5. TP1 修复验证】")
exit_counts(rows)

# MFE≥1R 但最终STOP（关键指标）
# 用 tp1/tp2/entry/stop 字段推算
mfe_1r_but_stop = 0
for r in rows:
    if 'STOP' not in r['reason']:
        continue
    try:
        entry = float(r['entry'])
        stop = float(r['stop_loss'])
        tp1 = float(r['tp1'])
        direction = r['direction']
        risk = abs(entry - stop)
        if risk <= 0:
            continue
        # 如果 tp1 在入场和止损之间的1R位置，且最终是STOP
        # 这意味着价格曾到达TP1（MFE≥1R）但没有触发
        if direction == 'LONG':
            mfe_1r_price = entry + risk
            tp1_should_be = entry + risk  # tp1_r=1.0
        else:
            mfe_1r_price = entry - risk
            tp1_should_be = entry - risk
        # 间接判断：tp1字段是否在 1R 附近
        tp1_r_ratio = abs(tp1 - entry) / risk if risk > 0 else 0
        # 如果tp1_r_ratio≈1.0（TP1在1R处），且最终STOP，说明策略没走到TP1就被止损
        # 实际上这里没有 MFE 字段，只能统计"STOP且方向上TP1≈1R"
        if 0.8 < tp1_r_ratio < 1.2:
            mfe_1r_but_stop += 1
    except:
        pass

total_stop = sum(1 for r in rows if 'STOP' in r['reason'])
tp1_hits = sum(1 for r in rows if 'TP1' in r['reason'])
tp2_hits = sum(1 for r in rows if 'TP2' in r['reason'])
be_hits = sum(1 for r in rows if 'BE' in r['reason'])

print(f"\n  全量:")
print(f"  TP1触发: {tp1_hits}  TP2触发: {tp2_hits}  STOP: {total_stop}  BE: {be_hits}")
print(f"  STOP中TP1≈1R位置的笔数: {mfe_1r_but_stop} (可能是TP1逻辑未生效)")
if tp1_hits == 0:
    print("\n  ⚠️  警告: TP1 触发次数=0! TP1修复未在回测中生效!")
elif tp1_hits < total_stop * 0.1:
    print(f"\n  ⚠️  警告: TP1触发极少({tp1_hits})，占STOP的{tp1_hits/total_stop:.1%}，修复效果存疑")
else:
    print(f"\n  ✅ TP1触发{tp1_hits}次，占总笔数{tp1_hits/len(rows):.1%}")

# ── 6. 检查回测实际配置 ──────────────────────────────────────────────────────
print("\n\n" + "="*60)
print("  【6. 回测实际使用配置】")
script_path = '/root/brain/run_bt_fixed1.sh'
try:
    content = open(script_path).read()
    print(f"\n  run_bt_fixed1.sh 内容:")
    print(content)
except:
    print("  无法读取 run_bt_fixed1.sh")

# 读metrics
for ws in ['/root/brain/backtest_full_ws', '/root/brain/backtest_bt2_ws']:
    mf = Path(ws) / 'metrics.json'
    if mf.exists():
        m = json.loads(mf.read_text())
        print(f"\n  {ws}/metrics.json 关键字段:")
        for k in ['trades','expectancy_R','profit_factor','win_rate','max_drawdown_R']:
            print(f"    {k}: {m.get(k)}")
