#!/usr/bin/env bash
set -eo pipefail
cd /root/brain

if [ -f venv/bin/activate ]; then source venv/bin/activate; fi
if [ -f .demo.env ]; then set -a; source .demo.env || true; set +a; fi

RUN_ID="${V7_RUN_ID:-$(date -u +%Y%m%d_%H%M%S)}"
OUT_BASE="/root/brain/backtest_results_v7"
OUT_ROOT="$OUT_BASE/diag_$RUN_ID"
export OUT_ROOT
mkdir -p "$OUT_ROOT"
ln -sfn "$OUT_ROOT" "$OUT_BASE/latest_diag"

echo "### Brain V7 diagnostic run_id=$RUN_ID out=$OUT_ROOT"

base_env() {
  export TRADING_MODE=paper
  export BACKTEST_OFFLINE_ONLY=1
  export NO_API_FALLBACK=1
  export PREFER_LOCAL_KLINES=1
  export LOCAL_KLINE_DIR="${LOCAL_KLINE_DIR:-/root/brain/binance_history}"
  export EXCHANGE_INFO_CACHE="${EXCHANGE_INFO_CACHE:-/root/brain/exchange_info_cache.json}"
  export BACKTEST_START="${BACKTEST_START:-2025-01-01}"
  export BACKTEST_END="${BACKTEST_END:-2025-01-31}"
  export BACKTEST_LIMIT="${BACKTEST_LIMIT:-5000}"
  export ENTRY_DELAY_BARS="${ENTRY_DELAY_BARS:-1}"
  export FEE_BPS="${FEE_BPS:-4.0}"
  export SLIPPAGE_BPS="${SLIPPAGE_BPS:-2.0}"
  export REQUEST_TIMEOUT="${REQUEST_TIMEOUT:-10}"
  export V11_REQUIRE_EDGE_FOR_EXCHANGE=0
  export V11_MIN_EDGE_TRADES=0
}

apply_case_env() {
  local case_name="$1"
  # Reset all tunable flags first so .demo.env cannot hide the case.
  export ENABLE_CONFIRM_V2=1
  export SCORE_THRESHOLD=60
  export V11_MIN_EXEC_SCORE=60
  export V11_ALT_MIN_SCORE=66
  export ENABLE_TREND_SETUP=0
  export ENABLE_BREAKOUT_SETUP=0
  export SETUP_WHITELIST=pullback
  export V11_SETUP_WHITELIST=pullback
  export BLOCK_COUNTER_HTF=1
  export MIN_ATR_PCT=0.10
  case "$case_name" in
    A) ;;
    B) export ENABLE_CONFIRM_V2=0 ;;
    C) export MIN_ATR_PCT=0.03 ;;
    D) export SETUP_WHITELIST=pullback,trend,breakout; export V11_SETUP_WHITELIST=pullback,trend,breakout; export ENABLE_TREND_SETUP=1; export ENABLE_BREAKOUT_SETUP=1 ;;
    E) export ENABLE_CONFIRM_V2=0; export MIN_ATR_PCT=0.03; export SCORE_THRESHOLD=50; export V11_MIN_EXEC_SCORE=50; export V11_ALT_MIN_SCORE=50; export SETUP_WHITELIST=pullback,trend,breakout; export V11_SETUP_WHITELIST=pullback,trend,breakout; export ENABLE_TREND_SETUP=1; export ENABLE_BREAKOUT_SETUP=1; export BLOCK_COUNTER_HTF=0 ;;
    *) echo "unknown case $case_name" >&2; exit 2 ;;
  esac
}

run_group() {
  local case_name="$1"
  local tag="$2"
  local symbols="$3"
  local case_dir="$OUT_ROOT/case_${case_name}"
  local ws="/root/brain/backtest_v7_diag_${RUN_ID}_${case_name}_${tag}_ws"
  mkdir -p "$case_dir"
  rm -rf "$ws"
  mkdir -p "$ws"
  (
    base_env
    apply_case_env "$case_name"
    export BRAIN_WS="$ws"
    export SYMBOLS="$symbols"
    echo "### RUN case=$case_name tag=$tag symbols=$symbols ws=$ws" | tee "$case_dir/${tag}.log"
    env | grep -E '^(BACKTEST_|SYMBOLS=|ENABLE_|MIN_ATR|SCORE|SETUP_|V11_|BLOCK_COUNTER|BRAIN_WS|LOCAL_KLINE)' | sort | tee -a "$case_dir/${tag}.log"
    python3 brain_v11_1_aipro.py --backtest 2>&1 | tee -a "$case_dir/${tag}.log"
  )
  test -s "$ws/backtest_trades.csv"
  cp -v "$ws/backtest_trades.csv" "$case_dir/${case_name}_${tag}_trades.csv"
  cp -v "$ws/metrics.json" "$case_dir/${case_name}_${tag}_metrics.json" 2>/dev/null || true
  cp -v "$ws/backtest_filter_diagnostic.json" "$case_dir/${case_name}_${tag}_filter_diagnostic.json" 2>/dev/null || true
  cp -v "$ws/backtest_filter_diagnostic.md" "$case_dir/${case_name}_${tag}_filter_diagnostic.md" 2>/dev/null || true
}

for case_name in A B C D E; do
  echo "### CASE $case_name"
  run_group "$case_name" "bt1" "BTCUSDT,ETHUSDT,BNBUSDT,XRPUSDT,AVAXUSDT"
  run_group "$case_name" "bt2" "SOLUSDT,DOGEUSDT,ADAUSDT,LINKUSDT,NEARUSDT"
  python3 bt_analyze.py --results-dir "$OUT_ROOT/case_${case_name}" --strict-schema --label "V7 diag case $case_name" 2>&1 | tee "$OUT_ROOT/case_${case_name}/analyze.log"
done

python3 - <<'PY'
import json
from pathlib import Path
root = Path(__import__('os').environ['OUT_ROOT']) if 'OUT_ROOT' in __import__('os').environ else Path('/root/brain/backtest_results_v7/latest_diag')
rows = []
for p in sorted(root.glob('case_*/combined_report_v7.json')):
    obj = json.loads(p.read_text(encoding='utf-8'))
    o = obj.get('overall', {})
    rows.append({
        'case': p.parent.name.replace('case_', ''),
        'trades': o.get('trades'),
        'win_rate': o.get('win_rate'),
        'expectancy_R': o.get('expectancy_R'),
        'profit_factor': o.get('profit_factor'),
        'max_drawdown_R': o.get('max_drawdown_R'),
        'tp2_hits': o.get('tp2_hits'),
        'stop_hits': o.get('stop_hits'),
        'mfe_ge_1R': (o.get('mfe_thresholds') or {}).get('mfe_ge_1R'),
    })
(root / 'diag_summary_v7.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
lines = ['case,trades,win_rate,expectancy_R,profit_factor,max_drawdown_R,tp2_hits,stop_hits,mfe_ge_1R']
for r in rows:
    lines.append(','.join(str(r.get(k,'')) for k in ['case','trades','win_rate','expectancy_R','profit_factor','max_drawdown_R','tp2_hits','stop_hits','mfe_ge_1R']))
(root / 'diag_summary_v7.csv').write_text('\n'.join(lines), encoding='utf-8')
print(json.dumps(rows, ensure_ascii=False, indent=2))
PY

echo "### V7 diag finished"
find "$OUT_ROOT" -maxdepth 3 -type f -printf "%TY-%Tm-%Td %TH:%TM:%TS %s %p\n" | sort | tail -120
