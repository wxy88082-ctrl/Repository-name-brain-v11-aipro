#!/usr/bin/env bash
set -eo pipefail
cd /root/brain

# Optional virtualenv / env file. Do not fail if absent.
if [ -f venv/bin/activate ]; then source venv/bin/activate; fi
if [ -f .demo.env ]; then set -a; source .demo.env || true; set +a; fi

RUN_ID="${V7_RUN_ID:-$(date -u +%Y%m%d_%H%M%S)}"
OUT_BASE="/root/brain/backtest_results_v7"
OUT_DIR="$OUT_BASE/$RUN_ID"
mkdir -p "$OUT_DIR"
ln -sfn "$OUT_DIR" "$OUT_BASE/latest"

echo "### Brain V7 smoke run_id=$RUN_ID out=$OUT_DIR"

default_env() {
  export TRADING_MODE=paper
  export BACKTEST_OFFLINE_ONLY=1
  export NO_API_FALLBACK=1
  export PREFER_LOCAL_KLINES=1
  export LOCAL_KLINE_DIR="${LOCAL_KLINE_DIR:-/root/brain/binance_history}"
  export EXCHANGE_INFO_CACHE="${EXCHANGE_INFO_CACHE:-/root/brain/exchange_info_cache.json}"
  export BACKTEST_START="${BACKTEST_START:-2025-01-01}"
  export BACKTEST_END="${BACKTEST_END:-2025-01-31}"
  export BACKTEST_LIMIT="${BACKTEST_LIMIT:-5000}"
  export ENTRY_DELAY_BARS="${ENTRY_DELAY_BARS:-1}"
  export ENABLE_CONFIRM_V2="${ENABLE_CONFIRM_V2:-1}"
  export SCORE_THRESHOLD="${SCORE_THRESHOLD:-60}"
  export V11_MIN_EXEC_SCORE="${V11_MIN_EXEC_SCORE:-60}"
  export V11_ALT_MIN_SCORE="${V11_ALT_MIN_SCORE:-66}"
  export ENABLE_TREND_SETUP="${ENABLE_TREND_SETUP:-0}"
  export ENABLE_BREAKOUT_SETUP="${ENABLE_BREAKOUT_SETUP:-0}"
  export SETUP_WHITELIST="${SETUP_WHITELIST:-pullback}"
  export V11_SETUP_WHITELIST="${V11_SETUP_WHITELIST:-pullback}"
  export BLOCK_COUNTER_HTF="${BLOCK_COUNTER_HTF:-1}"
  export MIN_ATR_PCT="${MIN_ATR_PCT:-0.10}"
  export FEE_BPS="${FEE_BPS:-4.0}"
  export SLIPPAGE_BPS="${SLIPPAGE_BPS:-2.0}"
  export REQUEST_TIMEOUT="${REQUEST_TIMEOUT:-10}"
  export V11_REQUIRE_EDGE_FOR_EXCHANGE=0
  export V11_MIN_EDGE_TRADES=0
}

run_group() {
  local tag="$1"
  local symbols="$2"
  local ws="/root/brain/backtest_v7_${RUN_ID}_${tag}_ws"
  rm -rf "$ws"
  mkdir -p "$ws"
  (
    default_env
    export BRAIN_WS="$ws"
    export SYMBOLS="$symbols"
    echo "### RUN $tag symbols=$symbols ws=$ws" | tee "$OUT_DIR/${tag}.log"
    python3 brain_v11_1_aipro.py --backtest 2>&1 | tee -a "$OUT_DIR/${tag}.log"
  )
  test -s "$ws/backtest_trades.csv"
  cp -v "$ws/backtest_trades.csv" "$OUT_DIR/${tag}_trades.csv"
  cp -v "$ws/metrics.json" "$OUT_DIR/${tag}_metrics.json" 2>/dev/null || true
  cp -v "$ws/backtest_filter_diagnostic.json" "$OUT_DIR/${tag}_filter_diagnostic.json" 2>/dev/null || true
  cp -v "$ws/backtest_filter_diagnostic.md" "$OUT_DIR/${tag}_filter_diagnostic.md" 2>/dev/null || true
}

run_group "bt1" "BTCUSDT,ETHUSDT,BNBUSDT,XRPUSDT,AVAXUSDT"
run_group "bt2" "SOLUSDT,DOGEUSDT,ADAUSDT,LINKUSDT,NEARUSDT"

python3 bt_analyze.py --results-dir "$OUT_DIR" --strict-schema --label "V7 smoke $RUN_ID" 2>&1 | tee "$OUT_DIR/analyze.log"

echo "### V7 smoke finished"
find "$OUT_DIR" -maxdepth 1 -type f -printf "%TY-%Tm-%Td %TH:%TM:%TS %s %p\n" | sort
