#!/usr/bin/env python3
"""
Brain V7 trustworthy backtest analyzer.

Purpose:
- Analyze only CSV files explicitly produced by the current V7 runner/workspace.
- Never silently reuse old /root/brain/backtest_results/bt1_*.csv or mixed metrics.
- Validate schema before calculating strategy quality.
- Treat metrics.json as audit metadata only; all headline metrics are recomputed from CSV rows.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

DEFAULT_RESULTS_DIR = Path(os.environ.get("BT_RESULTS_DIR", "/root/brain/backtest_results_v7/latest"))

CORE_FIELDS = {
    "symbol", "direction", "setup", "entry_time", "exit_time", "entry", "exit",
    "stop_loss", "tp1", "tp2", "r_multiple", "pnl_pct", "bars", "score",
}
V7_FIELDS = {"exit_reason", "mfe_r", "mae_r", "entry_time_ms", "exit_time_ms"}
EXIT_ALIASES = {
    "": "UNKNOWN", "NONE": "UNKNOWN", "NAN": "UNKNOWN",
    "STOP_LOSS": "STOP", "SL": "STOP", "STOPLOSS": "STOP",
    "TAKE_PROFIT": "TP2", "TAKE_PROFIT_2": "TP2", "TP": "TP2",
    "BREAKEVEN": "BE", "BREAK_EVEN": "BE", "TIMEOUT": "MAX_HOLD", "MAXHOLD": "MAX_HOLD",
}


def safe_float(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        x = float(str(v).strip())
        if math.isnan(x) or math.isinf(x):
            return default
        return x
    except Exception:
        return default


def safe_int(v: Any, default: int = 0) -> int:
    try:
        return int(float(str(v).strip()))
    except Exception:
        return default


def parse_dt(value: Any) -> Optional[datetime]:
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    # Numeric milliseconds or seconds.
    if re.fullmatch(r"\d+(?:\.0+)?", s):
        n = int(float(s))
        if n > 10_000_000_000:
            return datetime.fromtimestamp(n / 1000, tz=timezone.utc)
        return datetime.fromtimestamp(n, tz=timezone.utc)
    # Python ISO, Binance ISO, legacy no tz.
    for candidate in (s, s.replace("Z", "+00:00")):
        try:
            dt = datetime.fromisoformat(candidate)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)
        except Exception:
            pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(s, fmt).replace(tzinfo=timezone.utc)
        except Exception:
            pass
    return None


def normalize_exit_reason(row: Dict[str, Any]) -> str:
    raw = str(row.get("exit_reason") or "").strip()
    if not raw:
        reason = str(row.get("reason") or "").strip()
        raw = reason.split("|")[0].strip() if reason else "UNKNOWN"
    key = raw.upper().replace(" ", "_")
    return EXIT_ALIASES.get(key, key or "UNKNOWN")


def parse_mfe_from_reason(reason: str) -> Optional[float]:
    m = re.search(r"\bMFE\s*=\s*([-+]?\d+(?:\.\d+)?)\s*R\b", str(reason), re.I)
    return float(m.group(1)) if m else None


def load_csv(path: Path) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fieldnames = list(reader.fieldnames or [])
        rows = list(reader)
    meta = {"path": str(path), "name": path.name, "rows": len(rows), "fields": fieldnames}
    for row in rows:
        row["_source_file"] = path.name
        row["exit_reason"] = normalize_exit_reason(row)
        if "mfe_r" not in row or str(row.get("mfe_r", "")).strip() == "":
            parsed = parse_mfe_from_reason(str(row.get("reason", "")))
            if parsed is not None:
                row["mfe_r"] = parsed
        if "mae_r" not in row or str(row.get("mae_r", "")).strip() == "":
            m = re.search(r"\bMAE\s*=\s*([-+]?\d+(?:\.\d+)?)\s*R\b", str(row.get("reason", "")), re.I)
            if m:
                row["mae_r"] = float(m.group(1))
    return rows, meta


def discover_csvs(results_dir: Path) -> List[Path]:
    patterns = ["**/*_trades.csv", "**/bt*_*.csv", "**/case_*_bt*_*.csv"]
    found: List[Path] = []
    for pat in patterns:
        found.extend(results_dir.glob(pat))
    out = []
    for p in sorted(set(found)):
        name = p.name.lower()
        if "combined" in name or "report" in name or "summary" in name:
            continue
        out.append(p)
    return out


def validate_schema(metas: Sequence[Dict[str, Any]], strict_v7: bool) -> Dict[str, Any]:
    issues: List[str] = []
    warnings: List[str] = []
    for m in metas:
        fields = set(m.get("fields") or [])
        missing_core = sorted(CORE_FIELDS - fields)
        missing_v7 = sorted(V7_FIELDS - fields)
        if missing_core:
            issues.append(f"{m['name']} missing core columns: {missing_core}")
        if missing_v7:
            msg = f"{m['name']} missing V7 columns: {missing_v7}"
            (issues if strict_v7 else warnings).append(msg)
    return {"passed": not issues, "issues": issues, "warnings": warnings}


def compute_stats(rows: Sequence[Dict[str, Any]], label: str = "") -> Dict[str, Any]:
    if not rows:
        return {"label": label, "trades": 0}
    rs = [safe_float(r.get("r_multiple"), 0.0) for r in rows]
    n = len(rs)
    wins = [x for x in rs if x > 0]
    losses = [x for x in rs if x <= 0]
    gross_profit = sum(wins)
    gross_loss = abs(sum(losses))
    pf = gross_profit / gross_loss if gross_loss else (999.0 if gross_profit > 0 else 0.0)
    expectancy = sum(rs) / n if n else 0.0
    cum = 0.0
    peak = 0.0
    max_dd = 0.0
    max_consec_loss = 0
    cur_loss = 0
    max_consec_win = 0
    cur_win = 0
    equity_curve = []
    for x in rs:
        cum += x
        equity_curve.append(cum)
        peak = max(peak, cum)
        max_dd = max(max_dd, peak - cum)
        if x <= 0:
            cur_loss += 1
            max_consec_loss = max(max_consec_loss, cur_loss)
            cur_win = 0
        else:
            cur_win += 1
            max_consec_win = max(max_consec_win, cur_win)
            cur_loss = 0
    std = math.sqrt(sum((x - expectancy) ** 2 for x in rs) / (n - 1)) if n > 1 else 0.0
    reasons: Dict[str, int] = defaultdict(int)
    by_source: Dict[str, int] = defaultdict(int)
    tp1_hits = 0
    for r in rows:
        reasons[normalize_exit_reason(r)] += 1
        by_source[str(r.get("_source_file", "unknown"))] += 1
        if str(r.get("tp1_hit", "")).lower() in {"1", "true", "yes", "y"} or "TP1_HIT" in str(r.get("reason", "")).upper():
            tp1_hits += 1
    mfe_values = [safe_float(r.get("mfe_r"), 0.0) for r in rows]
    mae_values = [safe_float(r.get("mae_r"), 0.0) for r in rows]
    mfe_thresholds = {f"mfe_ge_{thr:g}R": sum(1 for x in mfe_values if x >= thr) for thr in (0.5, 0.8, 1.0, 1.5, 2.0)}
    return {
        "label": label,
        "trades": n,
        "win_rate": round(len(wins) / n, 4),
        "expectancy_R": round(expectancy, 6),
        "profit_factor": round(pf, 6),
        "avg_win_R": round(sum(wins) / len(wins), 6) if wins else 0.0,
        "avg_loss_R": round(sum(losses) / len(losses), 6) if losses else 0.0,
        "total_R": round(sum(rs), 6),
        "max_drawdown_R": round(max_dd, 6),
        "max_consec_loss": max_consec_loss,
        "max_consec_win": max_consec_win,
        "sharpe_per_trade": round(expectancy / std, 6) if std else 0.0,
        "median_R": round(sorted(rs)[n // 2], 6),
        "exit_reasons": dict(sorted(reasons.items(), key=lambda kv: (-kv[1], kv[0]))),
        "tp1_hits": tp1_hits,
        "tp2_hits": reasons.get("TP2", 0),
        "stop_hits": reasons.get("STOP", 0),
        "be_hits": reasons.get("BE", 0),
        "max_hold_hits": reasons.get("MAX_HOLD", 0),
        "mfe_thresholds": mfe_thresholds,
        "avg_mfe_R": round(sum(mfe_values) / n, 6) if n else 0.0,
        "avg_mae_R": round(sum(mae_values) / n, 6) if n else 0.0,
        "mfe_ge_1r_then_stop": sum(1 for r, mfe in zip(rows, mfe_values) if mfe >= 1.0 and normalize_exit_reason(r) == "STOP"),
        "by_source_file": dict(by_source),
    }


def group_by(rows: Sequence[Dict[str, Any]], key_fn: Callable[[Dict[str, Any]], str]) -> Dict[str, Dict[str, Any]]:
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[str(key_fn(row))].append(row)
    return {k: compute_stats(v, k) for k, v in sorted(groups.items())}


def quality_warnings(overall: Dict[str, Any], schema: Dict[str, Any], metas: Sequence[Dict[str, Any]]) -> List[str]:
    warnings = list(schema.get("warnings") or [])
    if not schema.get("passed"):
        warnings.extend(schema.get("issues") or [])
    if overall.get("trades", 0) <= 0:
        warnings.append("No trades in CSV; report cannot evaluate strategy.")
    if overall.get("mfe_thresholds", {}).get("mfe_ge_1R", 0) == 0 and overall.get("tp2_hits", 0) > 0:
        warnings.append("TP2 hits exist while MFE>=1R is zero; check MFE field generation.")
    # Detect mixed old/new batch by comparing mtimes and schema fields.
    row_counts = [m.get("rows", 0) for m in metas]
    if row_counts and any(x == 0 for x in row_counts):
        warnings.append("One or more CSV files have zero rows.")
    return warnings


def fmt_pct(x: float) -> str:
    return f"{x * 100:.1f}%"


def fmt_stats(s: Dict[str, Any], indent: str = "  ") -> str:
    if not s or s.get("trades", 0) == 0:
        return f"{indent}无交易数据"
    exits = ", ".join(f"{k}:{v}" for k, v in s.get("exit_reasons", {}).items())
    mfe = s.get("mfe_thresholds", {})
    return "\n".join([
        f"{indent}交易笔数: {s['trades']}",
        f"{indent}胜率: {fmt_pct(s.get('win_rate', 0.0))}",
        f"{indent}期望R: {s.get('expectancy_R', 0.0):+.4f}",
        f"{indent}PF: {s.get('profit_factor', 0.0):.3f}",
        f"{indent}均盈/均亏: {s.get('avg_win_R', 0.0):+.3f}R / {s.get('avg_loss_R', 0.0):+.3f}R",
        f"{indent}总R/最大回撤: {s.get('total_R', 0.0):+.2f}R / {s.get('max_drawdown_R', 0.0):.2f}R",
        f"{indent}最大连亏/连盈: {s.get('max_consec_loss', 0)} / {s.get('max_consec_win', 0)}",
        f"{indent}Sharpe/笔: {s.get('sharpe_per_trade', 0.0):+.4f}",
        f"{indent}TP1/TP2/STOP/BE/MAX_HOLD: {s.get('tp1_hits',0)} / {s.get('tp2_hits',0)} / {s.get('stop_hits',0)} / {s.get('be_hits',0)} / {s.get('max_hold_hits',0)}",
        f"{indent}MFE>=1R/1.5R/2R: {mfe.get('mfe_ge_1R', 0)} / {mfe.get('mfe_ge_1.5R', 0)} / {mfe.get('mfe_ge_2R', 0)}",
        f"{indent}出场原因: {exits or '{}'}",
    ])


def load_metrics_jsons(results_dir: Path) -> List[Dict[str, Any]]:
    out = []
    for p in sorted(results_dir.glob("**/*metrics*.json")):
        try:
            obj = json.loads(p.read_text(encoding="utf-8"))
            out.append({"path": str(p), "trades": obj.get("trades"), "expectancy_R": obj.get("expectancy_R"), "profit_factor": obj.get("profit_factor")})
        except Exception:
            pass
    return out


def main(argv: Optional[Sequence[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Brain V7 trustworthy backtest analyzer")
    ap.add_argument("--results-dir", default=str(DEFAULT_RESULTS_DIR), help="Directory containing current-run V7 CSV files")
    ap.add_argument("--csv", action="append", default=[], help="Explicit CSV file, can be repeated")
    ap.add_argument("--strict-schema", action="store_true", help="Fail when V7 columns are missing")
    ap.add_argument("--label", default=os.environ.get("BT_ANALYZE_LABEL", "V7 combined"))
    args = ap.parse_args(argv)

    results_dir = Path(args.results_dir).expanduser().resolve()
    results_dir.mkdir(parents=True, exist_ok=True)
    csvs = [Path(x).expanduser().resolve() for x in args.csv] if args.csv else discover_csvs(results_dir)
    if not csvs:
        print(f"[ERROR] No CSV files found under {results_dir}", file=sys.stderr)
        return 2

    all_rows: List[Dict[str, Any]] = []
    metas: List[Dict[str, Any]] = []
    for p in csvs:
        rows, meta = load_csv(p)
        metas.append(meta)
        all_rows.extend(rows)

    schema = validate_schema(metas, strict_v7=args.strict_schema)
    overall = compute_stats(all_rows, args.label)
    by_year = group_by(all_rows, lambda r: (parse_dt(r.get("entry_time")) or datetime(1970, 1, 1, tzinfo=timezone.utc)).strftime("%Y"))
    by_month = group_by(all_rows, lambda r: (parse_dt(r.get("entry_time")) or datetime(1970, 1, 1, tzinfo=timezone.utc)).strftime("%Y-%m"))
    by_symbol = group_by(all_rows, lambda r: str(r.get("symbol") or "UNKNOWN"))
    by_direction = group_by(all_rows, lambda r: str(r.get("direction") or "UNKNOWN").upper())
    by_setup = group_by(all_rows, lambda r: str(r.get("setup") or "UNKNOWN"))
    warnings = quality_warnings(overall, schema, metas)
    metrics_jsons = load_metrics_jsons(results_dir)

    report = {
        "schema_version": "v7_analysis_report",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "label": args.label,
        "results_dir": str(results_dir),
        "csv_files": metas,
        "schema_validation": schema,
        "warnings": warnings,
        "overall": overall,
        "by_year": by_year,
        "by_month": by_month,
        "by_symbol": by_symbol,
        "by_direction": by_direction,
        "by_setup": by_setup,
        "metrics_json_audit_only": metrics_jsons,
        "note": "Headline metrics are recomputed from CSV rows only. metrics.json is audit metadata only.",
    }

    out_json = results_dir / "combined_report_v7.json"
    out_txt = results_dir / "combined_report_v7.txt"
    out_json.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    lines: List[str] = []
    lines.append("=" * 70)
    lines.append("Brain V7 可信回测报告")
    lines.append(f"生成时间: {report['generated_at']}")
    lines.append(f"结果目录: {results_dir}")
    lines.append("=" * 70)
    lines.append("\n一、Schema 校验")
    lines.append(f"  passed: {schema['passed']}")
    for issue in schema.get("issues", []):
        lines.append(f"  ERROR: {issue}")
    for warning in schema.get("warnings", []):
        lines.append(f"  WARN: {warning}")
    lines.append("\n二、总体")
    lines.append(fmt_stats(overall))
    lines.append("\n三、按币种")
    for k, s in sorted(by_symbol.items()):
        lines.append(f"\n  [{k}]")
        lines.append(fmt_stats(s, "    "))
    lines.append("\n四、按月份（期望R / PF / 笔数）")
    for k, s in sorted(by_month.items()):
        lines.append(f"  {k}: exp={s.get('expectancy_R',0):+.4f} PF={s.get('profit_factor',0):.3f} n={s.get('trades',0)}")
    lines.append("\n五、质量警告")
    if warnings:
        for w in warnings:
            lines.append(f"  - {w}")
    else:
        lines.append("  无")
    lines.append("\n六、输入文件")
    for m in metas:
        lines.append(f"  - {m['name']}: rows={m['rows']} fields={','.join(m['fields'])}")
    lines.append("\nJSON: " + str(out_json))
    out_txt.write_text("\n".join(lines), encoding="utf-8")

    print("\n".join(lines))
    print(f"\n✅ JSON 报告: {out_json}")
    print(f"✅ 文本报告: {out_txt}")
    if args.strict_schema and not schema.get("passed"):
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
