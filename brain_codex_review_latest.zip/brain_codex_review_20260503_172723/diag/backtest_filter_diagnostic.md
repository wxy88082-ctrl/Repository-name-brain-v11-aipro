# Backtest Filter Diagnostic

time: 2026-05-03T09:12:43.176473+00:00

## BTCUSDT
- raw_market_bars: 2500
- raw_setups_total: 2277
- after_setup_whitelist: 511
- after_trend_disabled: 511
- after_breakout_disabled: 511
- after_min_atr: 511
- after_score_threshold: 0
- after_confirm_v2: 0
- after_cost_filter: 0
- after_rr_filter: 0
- final_trades: 0
- setup_counts: {'trend': 1733, 'pullback': 511, 'breakout': 33}
- reject_reasons: {'SETUP_NOT_ALLOWED': 1766, 'COST_FILTER': 185, 'NO_TRADE_BLOCKERS': 319, 'MIN_ATR_FILTERED': 1, 'SCORE_TOO_LOW': 6}
