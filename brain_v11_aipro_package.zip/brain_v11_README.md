# Brain V11 / Institutional AI Quant Final OS

这是给 Binance Ai Pro / 模拟盘验证准备的最终候选版。

## 目标

V11 不是“保证盈利机器人”，而是一个更接近机构流程的 AI 量化框架：

1. 量化引擎负责扫描、特征、评分、入场/止损/止盈/仓位。
2. AI/Ai Pro 只做候选排序和风险解释。
3. RiskGovernorV11 拥有最终否决权。
4. demo/live 默认需要真实回测、压力测试和质量门通过。

## 推荐先跑 paper

```bash
export TRADING_MODE=paper
export BRAIN_WS=./brain_v11_data
export AI_DECISION_MODE=rule
export SYMBOLS=BTCUSDT,ETHUSDT,SOLUSDT
export SCORE_THRESHOLD=80
export V11_MIN_EXEC_SCORE=84
export RISK_PER_TRADE=0.003
export MAX_POSITIONS=1
export MAX_NEW_ENTRIES_PER_CYCLE=1
python3 brain_v11_aipro.py --scan
python3 brain_v11_aipro.py --final-audit
python3 brain_v11_aipro.py --once
```

## 重要命令

```bash
python3 brain_v11_aipro.py --show-config
python3 brain_v11_aipro.py --scan
python3 brain_v11_aipro.py --backtest
python3 brain_v11_aipro.py --stress-test
python3 brain_v11_aipro.py --parameter-report
python3 brain_v11_aipro.py --final-audit
python3 brain_v11_aipro.py --model-card
python3 brain_v11_aipro.py --loop
```

## Ai Pro 使用

把这些文件给 Ai Pro：

- `brain_v11_aipro.py`
- `aipro_deployment_prompt_v11.md`
- `brain_v11.env.example`

运行后 Ai Pro 重点读取：

- `ai_candidates.json`
- `aipro_prompt.md`
- `v11_final_audit.json`
- `v11_model_card.md`

## live 禁止直接开

live 需要至少：

```bash
export TRADING_MODE=live
export LIVE_TRADING_CONFIRM=YES
export V11_LIVE_FINAL_CONFIRM=YES
export USE_EXCHANGE_PROTECTION=1
export LIVE_ALLOWED_SYMBOLS=BTCUSDT,ETHUSDT,SOLUSDT
export LIVE_MAX_ORDER_NOTIONAL=50
```

但强烈建议先 paper/demo 有足够交易记录后再考虑。
