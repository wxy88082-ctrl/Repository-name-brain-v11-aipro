Brain V11 Hotfix V5 MERGED
===========================
This zip contains one self-contained patch script:
  brain_v11_hotfix_v5_merged_guard_ui_backtest_history.py

It applies both previous fixes in one run:
- V3 guard/UI/backtest fix
- V4 trade-history/Dashboard fix

Run:
  cd /root/brain
  python3 brain_v11_hotfix_v5_merged_guard_ui_backtest_history.py

Then validate:
  python3 -m py_compile brain_v11_1_aipro.py dashboard.py bt_analyze.py
  source .demo.env
  python3 brain_v11_1_aipro.py --show-config
  python3 brain_v11_1_aipro.py --healthcheck
  python3 brain_v11_1_aipro.py --scan

Safe behavior:
- backs up modified files
- does not cancel protection orders
- does not close positions
- does not switch to live trading
