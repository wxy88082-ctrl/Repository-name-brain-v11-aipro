#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="/root/brain"
TS="$(date -u +%Y%m%d_%H%M%S)"
BACKUP="$TARGET/backup_before_v7_$TS"

cd "$TARGET"
mkdir -p "$BACKUP"
for f in brain_v11_1_aipro.py bt_analyze.py run_bt_v7_smoke.sh run_bt_v7_diag.sh run_bt_v6_smoke.sh run_bt_v6_diag.sh; do
  if [ -f "$TARGET/$f" ]; then cp -av "$TARGET/$f" "$BACKUP/"; fi
done

cp -av "$PKG_DIR/brain_v11_1_aipro.py" "$TARGET/brain_v11_1_aipro.py"
cp -av "$PKG_DIR/bt_analyze.py" "$TARGET/bt_analyze.py"
cp -av "$PKG_DIR/run_bt_v7_smoke.sh" "$TARGET/run_bt_v7_smoke.sh"
cp -av "$PKG_DIR/run_bt_v7_diag.sh" "$TARGET/run_bt_v7_diag.sh"
chmod +x "$TARGET/run_bt_v7_smoke.sh" "$TARGET/run_bt_v7_diag.sh"

python3 -m py_compile "$TARGET/brain_v11_1_aipro.py" "$TARGET/bt_analyze.py"

echo "V7 patch installed. Backup: $BACKUP"
echo "Next smoke test: cd /root/brain && bash run_bt_v7_smoke.sh"
echo "Next diagnostic: cd /root/brain && bash run_bt_v7_diag.sh"
