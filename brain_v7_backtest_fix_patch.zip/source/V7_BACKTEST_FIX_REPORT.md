# Brain V7 Backtest Trust Fix

## Fixed problems

1. `bt_analyze.py` no longer silently reuses old `/root/brain/backtest_results/bt1_*.csv` files. It analyzes only the result directory passed by the V7 runner.
2. `brain_v11_1_aipro.py` now writes a stable V7 CSV schema:
   - `exit_reason`
   - `mfe_r`
   - `mae_r`
   - `entry_time_ms`
   - `exit_time_ms`
   - `schema_version`
3. `bt_analyze.py` recomputes all headline metrics from CSV rows only. `metrics.json` is audit-only and cannot override CSV results.
4. Date parsing supports ISO strings with timezone, legacy ISO strings, and epoch timestamps.
5. `run_bt_v7_smoke.sh` and `run_bt_v7_diag.sh` rerun the actual backtest engine in isolated workspaces before analysis, so A/B/C/D/E parameter changes take effect.
6. `pending_notify.txt` is no longer required by the analyzer, so missing notification directories do not break reports.

## Install

```bash
cd /root/brain_v7_patch/source
bash install_v7_patch.sh
```

## Smoke test

```bash
cd /root/brain
bash run_bt_v7_smoke.sh
```

## Diagnostic test

```bash
cd /root/brain
bash run_bt_v7_diag.sh
```

## Important safety note

This patch only fixes backtest credibility. It does not approve real trading and does not change current demo/live positions or protection orders.
